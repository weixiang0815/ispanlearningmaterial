package advance;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AdvanceMain {
	
	public static void main(String[] args) throws IOException {
		printMenu();
		Scanner in = new Scanner(System.in);
		while(true) {
			System.out.println("請輸入功能代號：");
			String input = in.nextLine().trim();
			if(input.equalsIgnoreCase("q")) {
				System.out.println("感謝使用❤❤❤");
		        break;
			}
			switch(input) {
			case "1":	// 下載資料
				getDownload();
				break;
			case "2":	// 檔案存入資料庫
				CreateTable.createTable();
				break;
			case "3":	// 讀取所有資料
				QueryAllProducts.queryAllProducts();
				break;
			case "4":	// 讀取指定資料
				queryProduct();
				break;
			case "5":	// 讀取指定資料並建立檔案
				method5();
				break;
			case "6":	// 依特定欄位搜尋資料
				method6();
				break;
			case "7":	// 刪除指定資料
				method7();
				break;
			case "8":	// 刪除所有資料
				method8();
				break;
			case "9":	// 新增指定資料
				InsertTable.insertTable();
				break;
			case "10":	// 修改指定資料
				method10();
				break;
			case "11":	// 圖片存入資料庫
				method11();
				break;
			case "12":	// 讀取圖片並建立檔案
				method12();
				break;
			case "13":	// 顯示功能選單
				printMenu();
				break;
			default:	// 亂打一通
				System.out.println("無效指令，請重新輸入");
				break;
			}
		}
		in.close();
		System.out.println("程式已結束");
	}
	
	// 下載資料
	public static void getDownload() throws IOException {
		Scanner in = new Scanner(System.in);
		System.out.println("請問下載的是JSON還是CSV？ 1.JSON 2.CSV");
		in.
		if(in.nextLine().trim().contentEquals("1")) {					
			System.out.print("請輸入下載檔案的網址：");
			GetJSONDownload.getJSONDownload(in.nextLine().trim());
		}
		else if(in.nextLine().trim().contentEquals("2")) {					
			System.out.print("請輸入下載檔案的網址：");
			GetCSVDownload.getCSVDownload(in.nextLine().trim());
		}
		else {
			System.out.println("無效指令，已退回主選單");
		}
		in.close();
	}
	
	public static void method2() {
	}
	
	public static void method3() {
	}
	
	// 讀取指定資料
	public static void queryProduct() {
		Scanner in = new Scanner(System.in);
		try {
			System.out.print("請輸入想要的讀取的資料ID：");
			QueryProductByKey.queryProductByKey(in.nextInt());
		} catch(InputMismatchException e) {
			System.out.println("無效ID，已退回主選單");
		} finally {
			in.close();
		}
	}
	
	public static void method5() {
	}
	
	public static void method6() {
	}
	
	public static void method7() {
	}
	
	public static void method8() {
	}
	
	public static void method9() {
	}
	
	public static void method10() {
	}
	
	public static void method11() {
	}
	
	public static void method12() {
	}
	
	public static void printMenu() {
		// 共46個字元長
		for(int i = 0; i < 17 ; i ++) {
			System.out.print("=");
		}
		System.out.print("歡迎使用功能選單");
		for(int i = 0; i < 17 ; i ++) {
			System.out.print("=");
		}
		System.out.println();
		
		System.out.println("| (1)\t下載資料\t\t\t\t     |");
		System.out.println("| (2)\t檔案存入資料庫\t\t\t     |");
		System.out.println("| (3)\t讀取所有資料\t\t\t     |");
		System.out.println("| (4)\t讀取指定資料\t\t\t     |");
		System.out.println("| (5)\t讀取指定資料並建立檔案\t\t     |");
		System.out.println("| (6)\t依特定欄位搜尋資料\t\t\t     |");
		System.out.println("| (7)\t刪除指定資料\t\t\t     |");
		System.out.println("| (8)\t刪除所有資料\t\t\t     |");
		System.out.println("| (9)\t新增指定資料\t\t\t     |");
		System.out.println("| (10)\t修改指定資料\t\t\t     |");
		System.out.println("| (11)\t圖片存入資料庫\t\t\t     |");
		System.out.println("| (12)\t讀取圖片並建立檔案\t\t\t     |");
		System.out.println("| (13)\t顯示功能選單\t\t\t     |");
		System.out.println("| (q)\t結束程式\t\t\t\t     |");
		
		for(int i = 0; i < 46; i ++) {
			System.out.print("=");
		}
		System.out.println();
	}
	

}
