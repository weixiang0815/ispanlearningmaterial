package tw.ispan.action;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import tw.ispan.model.LightBean;

public class Demo9PropertiesFileAction {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		LightBean light = context.getBean("light", LightBean.class);
		System.out.println("紅燈 " + light.getRed() + " 秒");
		System.out.println("綠燈 " + light.getGreen() + " 秒");
		System.out.println("黃燈 " + light.getYellow() + " 秒");
		
		context.close();
	}

}
