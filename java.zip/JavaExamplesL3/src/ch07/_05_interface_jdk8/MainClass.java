package ch07._05_interface_jdk8;

public class MainClass {
	public static void main(String[] args) {
		InterfaceJDK8.staticMethod();
		IParent.staticMethod(); 
		SubclassA.staticMethod();
	}
}
