package com.iSpan.springbootdemo2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iSpan.springbootdemo2.model.GoodPhoto;
import com.iSpan.springbootdemo2.service.GoodPhotoService;

@Controller
public class GoodPhotoController {

	@Autowired
	private GoodPhotoService gService;

	@GetMapping("/goodphoto/uploadPage")
	public String uploadPage() {
		return "goodphoto/uploadPage";
	}

	@GetMapping("/goodphoto/uploadPageAjax")
	public String uploadPageAjax() {
		return "goodphoto/uploadPageAjax";
	}

	@ResponseBody
	@PostMapping("/goodphoto/postAjax")
	public String postAjaxUpload(@RequestParam("photoName") String fileName,
			@RequestParam("photoFile") MultipartFile file) {
		try {
			GoodPhoto gp = new GoodPhoto();
			gp.setPhotoName(fileName);
			gp.setPhotoFile(file.getBytes());
			gService.insertPhoto(gp);
			return "上傳成功"; // 到首頁
		} catch (Exception e) {
			e.printStackTrace();
			return "失敗：" + e.getMessage(); // 到原本那頁
		}
	}

	@PostMapping("/goodphoto/post")
	public String uploadPagePost(@RequestParam("photoName") String fileName,
			@RequestParam("photoFile") MultipartFile file, RedirectAttributes redirectAttributes) {
		try {
			GoodPhoto gp = new GoodPhoto();
			gp.setPhotoName(fileName);
			gp.setPhotoFile(file.getBytes());
			gService.insertPhoto(gp);
			return "redirect:/"; // 到首頁
		} catch (Exception e) {
			e.printStackTrace();
			redirectAttributes.addFlashAttribute("errorMsg", "請重新上傳");
			return "redirect:/goodphoto/uploadPage"; // 到原本那頁
		}
	}

	@GetMapping("/goodphoto/all")
	public ModelAndView getAllPhoto(ModelAndView mav) {
		List<GoodPhoto> list = gService.findAllPhoto();
		mav.setViewName("goodphoto/allphoto");
		mav.getModel().put("list", list);
		return mav;
	}

	// get one photo contentType 要注意
	@GetMapping("/goodphoto/id")
	public ResponseEntity<byte[]> getPhotoById(@RequestParam("id") Integer id) {
		byte[] photofile = gService.getPhotoById(id).getPhotoFile();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_JPEG);
		// 資料, headers, 回應的 http status
		// ResponseEntity 內建 @ResponseBody
		return new ResponseEntity<byte[]>(photofile, headers, HttpStatus.OK);
	}

}