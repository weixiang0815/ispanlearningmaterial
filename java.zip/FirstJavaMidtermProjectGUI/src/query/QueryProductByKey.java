package query;

import model.ProductBean;
import model.ProductDaoImpl;

public class QueryProductByKey {
	public static String queryProductByKey(int pk) {
		try {
			ProductBean productBean = new ProductDaoImpl().findById(pk);
			if (productBean == null){
				return "查無此資料:Key = " + pk;
			} else {
				return "查得資料: " +  productBean + "\n查詢記錄完畢";
			}
		} catch (Exception ex) {
			return "查詢記錄時發生例外: " + ex.getMessage();
		}
	}
}