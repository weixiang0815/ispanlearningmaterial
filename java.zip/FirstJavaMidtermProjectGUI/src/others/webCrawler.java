package others;

import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class webCrawler {

	public static Elements crawl(String keyword, int i) {
		Elements imgs = null;
		try {
			String url_prefix = "https://www.google.com.tw/search?q=";
			String url_suffix = "&source=lnms&tbm=isch";
			keyword = url_prefix + keyword.trim() + url_suffix;
			Document doc = Jsoup.connect(keyword).userAgent("Mozilla/5.0").referrer("https://www.google.com")
					.timeout(1000).followRedirects(true).get();
			imgs = doc.select("img");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return imgs;
	}

}
