package crm.service;

import java.util.List;

import crm.model.Hobby;

public interface HobbyService {
	
	List<Hobby> findAll();

	Hobby findById(Integer id);

}
