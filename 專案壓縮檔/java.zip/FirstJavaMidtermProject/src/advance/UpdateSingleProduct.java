package advance;

import java.sql.SQLException;

import sqlActions.ProductNotFoundException;

public class UpdateSingleProduct {
	public static void updateSingleProduct(ProductBean bean, int Id) {
		ProductDao productDao = new ProductDaoImpl();

		try {
			productDao.update(bean);
			System.out.println("修改記錄:Key=" + Id + " " + "成功");
		} catch (ProductNotFoundException e) {
			e.setProductID(Id);
			System.err.println("該筆紀錄不存在，無法修改，key=" + e.getProductID());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}