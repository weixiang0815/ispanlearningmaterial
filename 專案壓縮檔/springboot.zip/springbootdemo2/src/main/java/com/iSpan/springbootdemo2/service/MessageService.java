package com.iSpan.springbootdemo2.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.iSpan.springbootdemo2.model.Message;
import com.iSpan.springbootdemo2.model.MessageRepository;

@Service
@Transactional
public class MessageService {

	@Autowired
	private MessageRepository msgDao;

	public void insert(Message msg) {
		msgDao.save(msg);
	}

	public Message findById(Integer id) {
		Optional<Message> optional = msgDao.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		System.out.println("沒找到 id 為 " + id + " 的資料");
		return null;
	}

	public void deleteById(Integer id) {
		msgDao.deleteById(id);
	}

	public void deleteByEntity(Message msg) {
		msgDao.delete(msg);
	}

	public Message getLatestMessage() {
		return msgDao.findFirstByOrderByAddedDesc();
	}
	
	public Page<Message> getMessageByPage(Integer pageNumber) {
		Pageable pgb = PageRequest.of(pageNumber - 1, 3, Sort.Direction.DESC, "added");
		return msgDao.findAll(pgb);
	}

}