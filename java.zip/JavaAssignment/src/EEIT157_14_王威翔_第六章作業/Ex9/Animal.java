package EEIT157_14_王威翔_第六章作業.Ex9;

public class Animal {

}
