IF (OBJECT_ID('dbo.FKC_Member_Category', 'F') IS NOT NULL)
BEGIN
    ALTER TABLE dbo.Member_CRUD DROP CONSTRAINT FKC_Member_Category
END

DROP TABLE IF EXISTS Category;

IF NOT EXISTS (SELECT * FROM sysobjects WHERE Name='Category' and xtype='U')
BEGIN
   CREATE TABLE Category (
       id INTEGER NOT NULL,
       Name VARCHAR(255),
       shortName VARCHAR(255),
       PRIMARY KEY (id)
   );
END


-- ===========================================
IF (OBJECT_ID('dbo.FKC_Member_Hobby', 'F') IS NOT NULL)
BEGIN
    ALTER TABLE dbo.Member_CRUD DROP CONSTRAINT FKC_Member_Hobby
END;

DROP TABLE IF EXISTS Hobby;

IF NOT EXISTS (SELECT * FROM sysobjects WHERE Name='Hobby' and xtype='U')    
BEGIN
  CREATE TABLE  Hobby (
      id INTEGER NOT NULL IDENTITY,
      Name VARCHAR(255),
      PRIMARY KEY (id)
  );
END;

DROP TABLE IF EXISTS  Customer;

DROP TABLE IF EXISTS  Member_CRUD;

CREATE TABLE Customer (
       customerId int identity not null,
        birthday date,
        email varchar(255),
        lastPostTime datetime2,
        name varchar(255),
        password varchar(255),
        photo varbinary(MAX),
        registerTime datetime2,
        totalPayment double precision,
        primary key (customerId)
    )
	
CREATE TABLE Member_CRUD (
       id int identity not null,
        account varchar(255),
        admissionTime datetime2,
        birthday date,
        email varchar(255),
        fileName varchar(255),
        gender varchar(255),
        image varbinary(MAX),
        login varchar(255),
        name varchar(255),
        weight double precision,
        category_id int not null,
        hobby_id int not null,
        primary key (id)
    )

ALTER TABLE Member_CRUD 
       add constraint UNIC_Member_Account unique (account);
	   
ALTER TABLE Member_CRUD 
       add constraint FKC_Member_Hobby 
       foreign key (hobby_id) 
       references Hobby;	   
	   
ALTER TABLE Member_CRUD 
       add constraint FKC_Member_Category 
       foreign key (category_id) 
       references Category;	   

INSERT INTO Category (id, Name, shortName) VALUES 
	(101, '有學籍學生', '學'), 
	(111, '公務人員', '公'),	
	(121, '軍職人員', '軍'),
	(131, '自由業', '自'),	
	(141, '家庭主婦', '家');
	
INSERT INTO Hobby (Name) VALUES 
	(  '電腦/手機遊戲'), 
	(  '游泳'),	
	(  '登山'),
	(  '寫程式'),	
	(  '健行'),	
	(  '逛街');	