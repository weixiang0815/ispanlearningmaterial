package com.tw.henry.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.tw.henry.model.bean.Creator;
import com.tw.henry.model.bean.Video;

public class CreatorDao {

	private Connection conn;

	public CreatorDao(Connection conn) {
		this.conn = conn;
	}

	/**
	 * 新增創作者資料
	 */
	public String addNewCreator(Creator crt) {
		String SQL = "INSERT INTO Creator (" + "name, account, password, thumbnail,"
				+ "gender, birthday, uploadCount, country, info,"
				+ "fb_account, google_account, twitter_account, ig_account)"
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, crt.getName());
			stmt.setString(2, crt.getAccount());
			stmt.setString(3, crt.getPassword());
			String image = crt.getThumbnail().substring("data:image/jpeg;base64,".length());
			byte[] decoded_image = Base64.getDecoder().decode(image.getBytes("UTF-8"));
			stmt.setBytes(4, decoded_image);
			stmt.setString(5, crt.getGender());
			stmt.setString(6, crt.getBirthday());
			stmt.setString(7, crt.getUploadCount());
			stmt.setString(8, crt.getCountry());
			stmt.setString(9, crt.getInfo());
			stmt.setString(10, crt.getSocialAccount().get("Facebook"));
			stmt.setString(11, crt.getSocialAccount().get("Google"));
			stmt.setString(12, crt.getSocialAccount().get("Twitter"));
			stmt.setString(13, crt.getSocialAccount().get("Instagram"));
			stmt.executeUpdate();
			result = "會員新增成功";
		} catch (Exception e) {
			e.printStackTrace();
			result = "會員新增失敗：" + e.getMessage();
		}
		return result;
	}

	/**
	 * 透過 Creator ID 更新創作者資料
	 */
	public int updateCreatorByID(Creator crt) {
		String SQL = "UPDATE Creator SET"
				+ "name=?, account=?, password=?, thumbnail=?, gender=?, birthday=?, uploadCount=?,"
				+ "country=?, info=?, fb_account=?, google_account=?, twitter_account=?, ig_account=?" + "WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, crt.getName());
			stmt.setString(2, crt.getAccount());
			stmt.setString(3, crt.getPassword());
			byte[] decoded_image = Base64.getDecoder().decode(new String(crt.getThumbnail()).getBytes("UTF-8"));
			stmt.setBytes(4, decoded_image);
			stmt.setString(5, crt.getGender());
			stmt.setString(6, crt.getBirthday());
			stmt.setString(7, crt.getUploadCount());
			stmt.setString(8, crt.getCountry());
			stmt.setString(9, crt.getInfo());
			stmt.setString(10, crt.getSocialAccount().get("Facebook"));
			stmt.setString(11, crt.getSocialAccount().get("Google"));
			stmt.setString(12, crt.getSocialAccount().get("Twitter"));
			stmt.setString(13, crt.getSocialAccount().get("Instagram"));
			stmt.setString(14, crt.getId());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 透過 Creator ID 更新 uploadCount
	 */
	public int updateUploadCountByID(String id) {
		String SQL = "UPDATE Creator SET uploadCount=? WHERE id=?";
		int result = -1;
		int newCount = getVideoByCreatorID(id).size();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, newCount);
			result = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 透過 Creator ID 刪除創作者資料
	 */
	public String deleteCreatorByID(String id) {
		String SQL = "DELETE * FROM Creator WHERE id = ?";
		String result;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			stmt.executeUpdate();
			result = "刪除成功";
		} catch (Exception e) {
			e.printStackTrace();
			result = "刪除失敗：" + e.getMessage();
		}
		return result;
	}

	/**
	 * 透過 Creator account 刪除創作者資料
	 */
	public String deleteCreatorByAccount(String account) {
		return deleteCreatorByID(getCreatorByAccount(account).getId());
	}

	/**
	 * 刪除所有創作者資料
	 */
	public int deleteAllCreators() {
		String SQL = "TRUNCATE TABLE Creator;";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * 透過 Creator ID 搜尋創作者資料
	 */
	public Creator getCreatorByID(String id) {
		String SQL = "SELECT * FROM Creator WHERE id = ?";
		Creator crt = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					crt = new Creator();
					crt.setId(rs.getString("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getBytes("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getString("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setOneSocialAccount("Facebook", rs.getString("fb_account"));
					crt.setOneSocialAccount("Google", rs.getString("google_account"));
					crt.setOneSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setOneSocialAccount("Instagram", rs.getString("ig_account"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return crt;
	}

	/**
	 * 透過 Creator account 搜尋創作者資料
	 */
	public Creator getCreatorByAccount(String account) {
		String SQL = "SELECT * FROM Creator WHERE account = ?";
		Creator crt = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, account);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					crt = new Creator();
					crt.setId(rs.getString("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getBytes("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getString("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setOneSocialAccount("Facebook", rs.getString("fb_account"));
					crt.setOneSocialAccount("Google", rs.getString("google_account"));
					crt.setOneSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setOneSocialAccount("Instagram", rs.getString("ig_account"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return crt;
	}

	/**
	 * 搜尋所有創作者資料
	 */
	public List<Creator> getAllCreators() {
		String SQL = "SELECT * FROM Creator;";
		List<Creator> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while (rs.next()) {
					Creator crt = new Creator();
					crt.setId(rs.getString("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getBytes("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getString("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setOneSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setOneSocialAccount("Google", rs.getString("google_account"));
					crt.setOneSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setOneSocialAccount("Instagram", rs.getString("ig_account"));
					list.add(crt);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 透過 Creator name 對創作者進行模糊搜尋
	 */
	public List<Creator> getAllCreatorsByName(String name) {
		String SQL = "SELECT * FROM Creator WHERE name LIKE '%" + name + "%'";
		List<Creator> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while (rs.next()) {
					Creator crt = new Creator();
					crt.setId(rs.getString("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getBytes("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getString("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setOneSocialAccount("Facebook", rs.getString("fb_account"));
					crt.setOneSocialAccount("Google", rs.getString("google_account"));
					crt.setOneSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setOneSocialAccount("Instagram", rs.getString("ig_account"));
					list.add(crt);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 透過 Creator ID 搜尋作品資料
	 */
	public List<Video> getVideoByCreatorID(String id) {
		String SQL = "SELECT * FROM Video AS v JOIN creator AS c ON v.creator = c.id AND c.id = ?";
		List<Video> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				Video video = null;
				if (rs.next()) {
					video = new Video();
					video.setId(rs.getString("id"));
					video.setName(rs.getString("name"));
					video.setThumbnail(rs.getBytes("thumbnail"));
					video.setFilename(rs.getString("filename"));
					video.setFiletype(rs.getString("filetype"));
					video.setVideo(rs.getBytes("video"));
					video.setInfo(rs.getString("info"));
					video.setCreatorId(rs.getString("creator"));
					video.setCreatorName(getCreatorByID(id).getName());
					list.add(video);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
