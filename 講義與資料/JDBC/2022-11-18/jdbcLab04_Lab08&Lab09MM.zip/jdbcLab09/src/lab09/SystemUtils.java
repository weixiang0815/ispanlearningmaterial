package lab09;

import java.io.File;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Clob;

public class SystemUtils {
	public static Blob fileToBlob(InputStream is) {
		Blob blob = null;

		return blob;
	}

	public static Blob fileToBlob(String filePath) {
		Blob blob = null;

		return blob;
	}
	public static Clob fileToClob(String textFileName) {
		Clob clob = null;

		return clob;
	}
	public static Clob fileToClob(String textFileName, String encoding) {
		Clob clob = null;

		return clob;

	}
	public char[] clobToCharArray(Clob clob) {
		char [] ca = null;
		
		
		return ca;
	}
	
	public byte[] blobToByteArray(Blob blob) {
		byte [] ba = null;
		
		
		return ba;
	}
	 
	public static void blobToFile(Blob blob, File file) {

	}

	public static void clobToFile(Clob clob, File file) {

	}
}
