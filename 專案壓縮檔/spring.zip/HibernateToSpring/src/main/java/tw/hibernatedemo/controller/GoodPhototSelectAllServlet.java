package tw.hibernatedemo.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import tw.hibernatedemo.model.GoodPhoto;
import tw.hibernatedemo.service.GoodPhotoService;

@WebServlet("/GoodPhototSelectAllServlet.do")
public class GoodPhototSelectAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//	拿全部照片
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		GoodPhotoService gService = context.getBean("goodPhotoService", GoodPhotoService.class);
		List<GoodPhoto> photos = gService.getAllPhoto();
		request.setAttribute("photos", photos);
		
		//	跳到 Allphoto.jsp 顯示
		request.getRequestDispatcher("/page/Allphoto.jsp").forward(request, response);
	}

}
