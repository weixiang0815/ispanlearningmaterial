package main;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import img.CreateImgTable;
import img.InsertImg;
import others.webCrawler;
import system.SystemConstant;

import javax.swing.JRadioButton;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;

public class MainFrame {

	private JFrame frmjava;
	private JTextField textField_圖片搜尋關鍵字;
	private JTextField textField_下載圖片張數;
	private JTextArea textArea_Google圖片爬蟲;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JLabel lblNewLabel_請輸入圖檔位址;
	private JButton btnNewButton_1_上傳圖檔;
	private JTextField textField;
	private JTextArea textArea_圖片存入資料庫;
	private JButton btnNewButton_建立圖片資料庫;
	private JButton btnNewButton_預覽;
	private JButton btnNewButton_匯出;
	private JTextArea textArea_圖片存入資料庫_1;
	private JTextField textField_1;
	private JButton btnNewButton_預覽_1;

	private String imagepath_upload;
	private String imagepath_download;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frmjava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmjava = new JFrame();
		frmjava.setResizable(false);
		frmjava.setTitle("資展Java班157期第一次期中專題");
		frmjava.setBounds(100, 100, 1080, 720);
		frmjava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmjava.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		frmjava.getContentPane().add(tabbedPane);

		JPanel panel_大專校院名冊 = new JPanel();
		tabbedPane.addTab("大專校院名冊", null, panel_大專校院名冊, null);
		panel_大專校院名冊.setLayout(new GridLayout(0, 1, 0, 0));

		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
		panel_大專校院名冊.add(tabbedPane_1);

		JPanel panel_下載資料 = new JPanel();
		tabbedPane_1.addTab("下載資料", null, panel_下載資料, null);
		panel_下載資料.setLayout(null);

		JPanel panel_建立新資料庫 = new JPanel();
		tabbedPane_1.addTab("建立新資料庫", null, panel_建立新資料庫, null);

		JPanel panel_檔案存入資料庫 = new JPanel();
		tabbedPane_1.addTab("檔案存入資料庫", null, panel_檔案存入資料庫, null);

		JPanel panel_讀取所有資料 = new JPanel();
		tabbedPane_1.addTab("讀取所有資料", null, panel_讀取所有資料, null);

		JPanel panel_讀取指定資料 = new JPanel();
		tabbedPane_1.addTab("讀取指定資料", null, panel_讀取指定資料, null);

		JPanel panel_讀取指定資料並建立檔案 = new JPanel();
		tabbedPane_1.addTab("讀取指定資料並建立檔案", null, panel_讀取指定資料並建立檔案, null);

		JPanel panel_依關鍵字搜尋資料 = new JPanel();
		tabbedPane_1.addTab("依關鍵字搜尋資料", null, panel_依關鍵字搜尋資料, null);

		JPanel panel_刪除指定資料 = new JPanel();
		tabbedPane_1.addTab("刪除指定資料", null, panel_刪除指定資料, null);

		JPanel panel_刪除所有資料 = new JPanel();
		tabbedPane_1.addTab("刪除所有資料", null, panel_刪除所有資料, null);

		JPanel panel_新增單筆資料 = new JPanel();
		tabbedPane_1.addTab("新增單筆資料", null, panel_新增單筆資料, null);

		JPanel panel_修改指定資料 = new JPanel();
		tabbedPane_1.addTab("修改指定資料", null, panel_修改指定資料, null);

		JPanel panel_圖片資料庫 = new JPanel();
		tabbedPane.addTab("圖片資料庫", null, panel_圖片資料庫, null);
		panel_圖片資料庫.setLayout(null);

		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_2.setBounds(0, 0, 1061, 618);
		tabbedPane_2.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
		panel_圖片資料庫.add(tabbedPane_2);

		JPanel panel_圖片存入資料庫 = new JPanel();
		tabbedPane_2.addTab("圖片存入資料庫", null, panel_圖片存入資料庫, null);
		panel_圖片存入資料庫.setLayout(null);

		JButton btnNewButton_Google圖片爬蟲_1 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫.setText("");
				textField.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1.setBounds(920, 533, 126, 41);
		panel_圖片存入資料庫.add(btnNewButton_Google圖片爬蟲_1);

		textArea_圖片存入資料庫 = new JTextArea();
		textArea_圖片存入資料庫.setEditable(false);
		textArea_圖片存入資料庫.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_圖片存入資料庫.setBounds(633, 10, 413, 513);
		panel_圖片存入資料庫.add(textArea_圖片存入資料庫);

		JLabel lblNewLabel_2 = new JLabel("1.　建好圖片資料庫了嗎：");
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(30, 149, 221, 41);
		panel_圖片存入資料庫.add(lblNewLabel_2);

		JRadioButton rdbtnNewRadioButton = new JRadioButton("是的");
		rdbtnNewRadioButton.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				lblNewLabel_請輸入圖檔位址.setForeground(new Color(0, 0, 0));
				textField.setEnabled(true);
				btnNewButton_1_上傳圖檔.setEnabled(true);
				btnNewButton_建立圖片資料庫.setEnabled(false);
				btnNewButton_預覽_1.setEnabled(true);
			}
		});
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtnNewRadioButton.setBounds(276, 149, 68, 41);
		panel_圖片存入資料庫.add(rdbtnNewRadioButton);

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("還沒");
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				lblNewLabel_請輸入圖檔位址.setForeground(new Color(192, 192, 192));
				textField.setEnabled(false);
				btnNewButton_1_上傳圖檔.setEnabled(false);
				btnNewButton_建立圖片資料庫.setEnabled(true);
				btnNewButton_預覽_1.setEnabled(false);
			}
		});
		rdbtnNewRadioButton_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtnNewRadioButton_1.setBounds(346, 149, 68, 41);
		panel_圖片存入資料庫.add(rdbtnNewRadioButton_1);

		btnNewButton_建立圖片資料庫 = new JButton("建立圖片資料庫");
		btnNewButton_建立圖片資料庫.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫.setText("");
				textArea_圖片存入資料庫.append(CreateImgTable.createImgTable() + '\n');
				rdbtnNewRadioButton.setSelected(true);
				lblNewLabel_請輸入圖檔位址.setForeground(new Color(0, 0, 0));
				textField.setEnabled(true);
				btnNewButton_1_上傳圖檔.setEnabled(true);
				btnNewButton_建立圖片資料庫.setEnabled(false);
				rdbtnNewRadioButton_1.setSelected(false);
				btnNewButton_預覽_1.setEnabled(true);
			}
		});
		btnNewButton_建立圖片資料庫.setEnabled(false);
		btnNewButton_建立圖片資料庫.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_建立圖片資料庫.setBounds(430, 149, 177, 41);
		panel_圖片存入資料庫.add(btnNewButton_建立圖片資料庫);

		lblNewLabel_請輸入圖檔位址 = new JLabel("2.　請輸入圖檔位址：");
		lblNewLabel_請輸入圖檔位址.setForeground(new Color(192, 192, 192));
		lblNewLabel_請輸入圖檔位址.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_請輸入圖檔位址.setBounds(30, 226, 189, 41);
		panel_圖片存入資料庫.add(lblNewLabel_請輸入圖檔位址);

		textField = new JTextField();
		textField.setForeground(new Color(0, 0, 0));
		textField.setEnabled(false);
		textField.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField.setBounds(30, 277, 577, 41);
		panel_圖片存入資料庫.add(textField);
		textField.setColumns(10);

		btnNewButton_1_上傳圖檔 = new JButton("上傳圖檔");
		btnNewButton_1_上傳圖檔.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫.setText("");
				if (textField.getText().trim().equals("")) {
					textArea_圖片存入資料庫.append("圖片位址不得為空喔！\n");
				} else {
					btnNewButton_預覽.setEnabled(true);
					imagepath_upload = textField.getText().trim();
					textArea_圖片存入資料庫.append("現在開始新增圖檔......\n");
					textArea_圖片存入資料庫.append(InsertImg.insertImg(textField.getText().trim()));
				}
			}
		});
		btnNewButton_1_上傳圖檔.setForeground(new Color(0, 0, 0));
		btnNewButton_1_上傳圖檔.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_1_上傳圖檔.setEnabled(false);
		btnNewButton_1_上傳圖檔.setBounds(448, 328, 159, 41);
		panel_圖片存入資料庫.add(btnNewButton_1_上傳圖檔);

		btnNewButton_預覽_1 = new JButton("預覽");
		btnNewButton_預覽_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					imagepath_upload = textField.getText().trim();
					BufferedImage img = ImageIO.read(new File(imagepath_upload));
					ImageIcon icon = new ImageIcon(img);
					JLabel label = new JLabel(icon);
					JOptionPane.showMessageDialog(null, label);
				} catch (IOException ex) {
					textArea_圖片存入資料庫_1.append("預覽出現錯誤：" + ex.getMessage() + '\n');
				}
			}
		});
		btnNewButton_預覽_1.setEnabled(false);
		btnNewButton_預覽_1.setForeground(Color.BLACK);
		btnNewButton_預覽_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_預覽_1.setBounds(312, 328, 126, 41);
		panel_圖片存入資料庫.add(btnNewButton_預覽_1);

		JPanel panel_讀取圖片並建立檔案 = new JPanel();
		tabbedPane_2.addTab("讀取圖片並建立檔案", null, panel_讀取圖片並建立檔案, null);
		panel_讀取圖片並建立檔案.setLayout(null);

		textArea_圖片存入資料庫_1 = new JTextArea();
		textArea_圖片存入資料庫_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_圖片存入資料庫_1.setEditable(false);
		textArea_圖片存入資料庫_1.setBounds(633, 10, 413, 513);
		panel_讀取圖片並建立檔案.add(textArea_圖片存入資料庫_1);

		JButton btnNewButton_Google圖片爬蟲_1_1 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_1.setText("");
				textField_1.setText("");
				btnNewButton_預覽.setEnabled(false);
			}
		});
		btnNewButton_Google圖片爬蟲_1_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_1.setBounds(920, 533, 126, 41);
		panel_讀取圖片並建立檔案.add(btnNewButton_Google圖片爬蟲_1_1);

		JLabel lblNewLabel_2_1 = new JLabel("請輸入要匯出的圖片代碼：");
		lblNewLabel_2_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_2_1.setBounds(26, 212, 222, 41);
		panel_讀取圖片並建立檔案.add(lblNewLabel_2_1);

		textField_1 = new JTextField();
		textField_1.setForeground(Color.BLACK);
		textField_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_1.setColumns(10);
		textField_1.setBounds(249, 212, 356, 41);
		panel_讀取圖片並建立檔案.add(textField_1);

		btnNewButton_匯出 = new JButton("匯出");
		btnNewButton_匯出.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_1.setText("");
				if (textField_1.getText().trim().equals("")) {
					textArea_圖片存入資料庫_1.append("圖片代碼不得為空喔！\n");
				} else {
					int i = Integer.valueOf(textField_1.getText().trim());
					btnNewButton_預覽.setEnabled(true);
					String path = "C:/Users/Student/Desktop/專題下載檔案";
					File file = new File(path);
					if (!file.exists()) {
						file.mkdir();
					}
					String sql = " SELECT * FROM [圖片] WHERE [代碼] = ?; ";
					String dbURL = SystemConstant.getDbURL();
					String user = SystemConstant.getUser();
					String password = SystemConstant.getPassword();
					try (Connection conn = DriverManager.getConnection(dbURL, user, password);
							PreparedStatement stmt = conn.prepareStatement(sql);) {
						stmt.setInt(1, i);
						textArea_圖片存入資料庫_1.append("正在尋找圖片......\n");
						try (ResultSet rs = stmt.executeQuery();) {
							if(rs.next()) {
								imagepath_download = path + "/" + rs.getString("檔名") + "." + rs.getString("副檔名");
								try(
										FileOutputStream fos = new FileOutputStream(imagepath_download);
										BufferedOutputStream bos = new BufferedOutputStream(fos);
										){
									bos.write(rs.getBytes("圖片"));
								}
							}
						}
						textArea_圖片存入資料庫_1.append("找到圖片囉！\n");
					} catch (Exception ex) {
						textArea_圖片存入資料庫_1.append("查詢記錄時發生例外: " + ex.getMessage() + '\n');
						btnNewButton_預覽.setEnabled(false);
					}
				}
			}
		});
		btnNewButton_匯出.setForeground(Color.BLACK);
		btnNewButton_匯出.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_匯出.setBounds(479, 275, 126, 41);
		panel_讀取圖片並建立檔案.add(btnNewButton_匯出);

		btnNewButton_預覽 = new JButton("預覽");
		btnNewButton_預覽.setEnabled(false);
		btnNewButton_預覽.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_1.setText("");
				try {
					BufferedImage img = ImageIO.read(new File(imagepath_download));
					ImageIcon icon = new ImageIcon(img);
					JLabel label = new JLabel(icon);
					JOptionPane.showMessageDialog(null, label);
				} catch (IOException ex) {
					textArea_圖片存入資料庫_1.append("預覽出現錯誤：" + ex.getMessage() + '\n');
				}
			}
		});
		btnNewButton_預覽.setForeground(Color.BLACK);
		btnNewButton_預覽.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_預覽.setBounds(343, 275, 126, 41);
		panel_讀取圖片並建立檔案.add(btnNewButton_預覽);

		JPanel panel_Google圖片爬蟲 = new JPanel();
		tabbedPane.addTab("Google圖片爬蟲", null, panel_Google圖片爬蟲, null);
		panel_Google圖片爬蟲.setLayout(null);

		JButton btnNewButton_Google圖片爬蟲 = new JButton("清空");
		btnNewButton_Google圖片爬蟲.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_圖片搜尋關鍵字.setText("");
				textField_下載圖片張數.setText("");
				textArea_Google圖片爬蟲.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲.setBounds(911, 555, 140, 53);
		panel_Google圖片爬蟲.add(btnNewButton_Google圖片爬蟲);

		JScrollPane scrollPane_Google圖片爬蟲 = new JScrollPane();
		scrollPane_Google圖片爬蟲.setBounds(522, 10, 529, 535);
		panel_Google圖片爬蟲.add(scrollPane_Google圖片爬蟲);

		textArea_Google圖片爬蟲 = new JTextArea();
		textArea_Google圖片爬蟲.setEditable(false);
		textArea_Google圖片爬蟲.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		scrollPane_Google圖片爬蟲.setViewportView(textArea_Google圖片爬蟲);

		JLabel lblNewLabel = new JLabel("請輸入圖片搜尋關鍵字：");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel.setBounds(53, 82, 204, 42);
		panel_Google圖片爬蟲.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("請問要爬幾張圖片（最多20張）：");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(53, 227, 278, 42);
		panel_Google圖片爬蟲.add(lblNewLabel_1);

		textField_圖片搜尋關鍵字 = new JTextField();
		textField_圖片搜尋關鍵字.setToolTipText("");
		textField_圖片搜尋關鍵字.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_圖片搜尋關鍵字.setBounds(53, 134, 397, 42);
		panel_Google圖片爬蟲.add(textField_圖片搜尋關鍵字);
		textField_圖片搜尋關鍵字.setColumns(10);

		textField_下載圖片張數 = new JTextField();
		textField_下載圖片張數.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_下載圖片張數.setColumns(10);
		textField_下載圖片張數.setBounds(53, 279, 397, 42);
		panel_Google圖片爬蟲.add(textField_下載圖片張數);

		JButton btnNewButton = new JButton("開始爬蟲");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_Google圖片爬蟲.setText("");
				if (textField_圖片搜尋關鍵字.getText().trim().equals("") | textField_下載圖片張數.getText().trim().equals("")) {
					if (textField_圖片搜尋關鍵字.getText().trim().equals("")) {
						textArea_Google圖片爬蟲.append("搜尋關鍵字不能是空白\n");
					}
					if (textField_下載圖片張數.getText().trim().equals("")) {
						textArea_Google圖片爬蟲.append("下載張數不能是空白\n");
					}
				} else {
					if (Integer.valueOf(textField_下載圖片張數.getText().trim()) > 20) {
						textArea_Google圖片爬蟲.append("下載張數沒辦法一次超過20張喔！\n");
					} else {
						textArea_Google圖片爬蟲.append("開始爬蟲！！！\n");
						for (int i = 0; i < 30; i++) {
							textArea_Google圖片爬蟲.append("=");
						}
						textArea_Google圖片爬蟲.append("\n");
						String keyword = textField_圖片搜尋關鍵字.getText();
						int i = Integer.valueOf(textField_下載圖片張數.getText().trim());
						Elements imgs = webCrawler.crawl(keyword, i);

						int j = 0;
						File file = new File("C:/Users/Student/Desktop/爬下來的照片");
						if (!file.exists()) {
							file.mkdir();
						}
						try {
							for (Element img : imgs) {
								if (j + 1 > i)
									break;
								if (!img.attr("src").contains("https:"))
									continue;
								URL img_url = new URL(img.attr("src"));
								String img_name = j + 1 + ".jpg";
								try (FileOutputStream fos = new FileOutputStream(
										file.getAbsoluteFile() + "/" + img_name);
										BufferedOutputStream bos = new BufferedOutputStream(fos);) {
									bos.write(img_url.openStream().readAllBytes());
								}
								j++;
								textArea_Google圖片爬蟲.append("印好了第" + j + "張圖\n");
							}
						} catch (IOException e1) {
							textArea_Google圖片爬蟲.append("出現錯誤：" + e1.getMessage());
						}
						for (int k = 0; k < 30; k++) {
							textArea_Google圖片爬蟲.append("=");
						}
						textArea_Google圖片爬蟲.append("\n");
						textArea_Google圖片爬蟲.append("圖片爬完囉！\n");
					}
				}
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton.setBounds(310, 492, 140, 53);
		panel_Google圖片爬蟲.add(btnNewButton);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		frmjava.setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("檔案");
		mnNewMenu.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("關閉");
		mntmNewMenuItem_1.addActionListener((event) -> System.exit(0));
		mntmNewMenuItem_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenu mnNewMenu_1 = new JMenu("其它");
		mnNewMenu_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("關於");
		mntmNewMenuItem_1_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		mnNewMenu_1.add(mntmNewMenuItem_1_1);
	}
}
