package advance;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class filetest {

	public static void main(String[] args) {
		String filename = "C:/Users/Student/Desktop/專題下載檔案/u1_new.csv";
//		String output = "C:/Users/henry/Desktop/專題下載檔案/u1_new_1.csv";
		try(
				FileInputStream fis = new FileInputStream(filename);
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
		){
			System.out.println(br.readLine());
//			String s = null;
//			while((s = br.readLine()) != null) {
//				System.out.println(s);
//			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
