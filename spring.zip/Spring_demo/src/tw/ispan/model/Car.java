package tw.ispan.model;

import java.util.Date;

public class Car {

	private Integer id;

	private String carName;

	private String brand;

	private Date releaseDate;
	
	private Date productionDate;

	public Car() {
	}

	public Car(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Car(Date releaseDate, Date productionDate) {
		this.releaseDate = releaseDate;
		this.productionDate = productionDate;
	}

	public Car(Integer id, String carName, String brand) {
		this.id = id;
		this.carName = carName;
		this.brand = brand;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Date getProductionDate() {
		return productionDate;
	}

	public void setProductionDate(Date productionDate) {
		this.productionDate = productionDate;
	}

}
