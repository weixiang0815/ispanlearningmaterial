package advance;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import system.SystemConstant;

public class CreateCSVTable {
	static String dropString = "";
	static String createString = "";
	
	public static void createCSVTable() {
		String dbURL = SystemConstant.getDbURL();
		String user = SystemConstant.getUser();
		String password = SystemConstant.getPassword();
		setSQLCOmmand();

		try (
			Connection conn = DriverManager.getConnection(dbURL, user, password);				
			PreparedStatement stmt1 = conn.prepareStatement(dropString);
			PreparedStatement stmt2 = conn.prepareStatement(createString);
		) {
			System.out.println("現在創建表格......");
		//  執行SQL命令
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			System.out.println("表格創建成功");
		} catch (SQLException e) {
			System.err.print("存取資料庫時發生例外: " + e);
			e.printStackTrace();
			return;
		}
	}
	
	private static void setSQLCOmmand() {
		// 新建Book_JDBC表格
		String[] titles = getTiltes();
		dropString = " drop table if exists [大專校院名錄]; ";
		createString = " create table [大專校院名錄] ( "
					+ "[" + titles[0] + "] int not null primary key identity, " // 代碼
					+ "[" + titles[1] + "] nvarchar(20) not null, " // 學校名稱
					+ "[" + titles[2] + "] nvarchar(2) not null, " // 公/私立
					+ "[" + titles[3] + "] nvarchar(3) not null, " // 縣市名稱
					+ "[" + titles[4] + "] nvarchar(50) not null, " // 地址
					+ "[" + titles[5] + "] nvarchar(20) not null, " // 電話
					+ "[" + titles[6] + "] nvarchar(100) not null, " // 網址
					+ "[" + titles[7] + "] nvarchar(2) " // 體系別
					+ "); "; 
	}
	
	private static String[] getTiltes() {
		String filename = "C:/Users/Student/Desktop/專題下載檔案/u1_new.csv";
		String[] titles = null;
		try(
				FileInputStream fis = new FileInputStream(filename);
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
		){
			String s = br.readLine();
			titles = s.split(",");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return titles;
	}
}