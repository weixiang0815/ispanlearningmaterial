package tw.com.henry.hw.emp.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import tw.com.henry.hw.emp.model.bean.DeptBean;
import tw.com.henry.hw.emp.model.bean.EmpBean;

public class EmpDao {

	private Connection conn;

	public EmpDao(Connection conn) {
		this.conn = conn;
	}

	// 新增員工資料
	public int addNewEmp(EmpBean emp) {
		String SQL = "INSERT INTO employee (empno, ename, hiredate, salary, deptno, title) VALUES (?, ?, ?, ?, ?, ?)";
		int result = -1;
		try (PreparedStatement preState = conn.prepareStatement(SQL);) {
			preState.setString(1, emp.getEmpno());
			preState.setString(2, emp.getEname());
			preState.setString(3, emp.getHiredate());
			preState.setString(4, emp.getSalary());
			preState.setString(5, emp.getDeptno());
			preState.setString(6, emp.getTitle());
			result = preState.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 透過ID更新員工資料
	public int updateEmpByID(EmpBean emp) {
		String SQL = "UPDATE employee SET ename=?, hiredate=?, salary=?, deptno=?, title=? WHERE empno = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, emp.getEname());
			stmt.setString(2, emp.getHiredate());
			stmt.setString(3, emp.getSalary());
			stmt.setString(4, emp.getDeptno());
			stmt.setString(5, emp.getTitle());
			stmt.setString(6, emp.getEmpno());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 可以寫很長的註解
	 * 
	 * @param empno 這個是員工編號
	 * @param xxx   之類的
	 * 
	 * @return int 成功或失敗的結果，1為成功
	 */
	public int deleteEmpByID(String empno) {
		String SQL = "DELETE * FROM employee WHERE empno = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, empno);
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	// 刪除所有員工資料
	public int deleteAllEmps() {
		String SQL = "TRUNCATE TABLE employee;";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 透過ID搜尋員工資料
	public EmpBean getEmpByID(String empno) {
		String SQL = "SELECT * FROM employee WHERE empno = ?";
		EmpBean emp = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, empno);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					emp = new EmpBean();
					emp.setEmpno(rs.getString("empno"));
					emp.setEname(rs.getString("ename"));
					emp.setHiredate(rs.getString("hiredate"));
					emp.setSalary(rs.getString("salary"));
					emp.setDeptno(rs.getString("deptno"));
					emp.setTitle(rs.getString("title"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return emp;
	}

	// 搜尋所有員工資料
	public List<EmpBean> getAllEmps() {
		String SQL = "SELECT * FROM employee;";
		List<EmpBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while(rs.next()) {
					EmpBean emp = new EmpBean();
					emp.setEmpno(rs.getString("empno"));
					emp.setEname(rs.getString("ename"));
					emp.setHiredate(rs.getString("hiredate"));
					emp.setSalary(rs.getString("salary"));
					emp.setDeptno(rs.getString("deptno"));
					emp.setTitle(rs.getString("title"));
					list.add(emp);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// 透過姓名進行模糊搜尋
	public List<EmpBean> getAllEmpsByName(String name) {
		String SQL = "SELECT * FROM employee WHERE name LIKE '%?%'";
		List<EmpBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, name);
			try (ResultSet rs = stmt.executeQuery();) {
				while(rs.next()) {
					EmpBean emp = new EmpBean();
					emp.setEmpno(rs.getString("empno"));
					emp.setEname(rs.getString("ename"));
					emp.setHiredate(rs.getString("hiredate"));
					emp.setSalary(rs.getString("salary"));
					emp.setDeptno(rs.getString("deptno"));
					emp.setTitle(rs.getString("title"));
					list.add(emp);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// 透過員工ID搜尋任職部門資料
	public DeptBean getDeptByEmpID(String empno) {
		String SQL = "SELECT dname FROM department AS d JOIN employee AS e ON e.deptno = d.deptno AND e.empno = ?";
		DeptBean dept = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, empno);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					dept = new DeptBean();
					dept.setDeptno(rs.getString("deptno"));
					dept.setDname(rs.getString("dname"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dept;
	}

}