package com.lcpan.m11;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@WebServlet("/UpdateEmp.do")
public class UpdateEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String sql = "UPDATE [servdb].[dbo].[employee] SET "
			+ "ename=?, hiredate=?, salary=?, deptno=?, title=? WHERE empno=?;";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String result = null;
		try {
			Context context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:comp/env/jdbc/servdb");
			try (
					Connection conn = ds.getConnection();
					PreparedStatement stmt = conn.prepareStatement(sql);
			) {
				stmt.setString(1, request.getParameter("ename"));
				stmt.setString(2, request.getParameter("hiredate"));
				stmt.setString(3, request.getParameter("salary"));
				stmt.setString(4, request.getParameter("deptno"));
				stmt.setString(5, request.getParameter("title"));
				stmt.setString(6, request.getParameter("empno"));
				stmt.executeUpdate();
				result = "��s���\";
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "��s����";
		}
		request.setAttribute("result", result);
		request.getRequestDispatcher("/m11/UpdateEmp.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
