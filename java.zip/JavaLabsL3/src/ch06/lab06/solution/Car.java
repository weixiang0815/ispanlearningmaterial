package ch06.lab06.solution;

public class Car {

}
