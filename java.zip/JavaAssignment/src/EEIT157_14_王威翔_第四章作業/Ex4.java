package EEIT157_14_王威翔_第四章作業;

public class Ex4 {

	public static void main(String[] args) {
		for(int i = 1; i <= 10; i ++) {
			System.out.print((i * i));
			if(i == 10) {
				System.out.println("");
			}
			else {
				System.out.print(" ");
			}
		}

	}

}
