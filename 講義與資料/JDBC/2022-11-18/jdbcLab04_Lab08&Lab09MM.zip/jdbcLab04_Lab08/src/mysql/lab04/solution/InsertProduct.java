package mysql.lab04.solution;
/*
文字檔data/product/ProductInsertDataUTF8.txt內有多筆產品資料，每一列表示一個產品的
名稱、價格、數量、圖片檔(相對於本專案的)路徑、相對於本專案的路徑的產品說明檔、建檔日期
等，每個欄位與欄位間用","隔開。

請逐列讀入ProductInsertDataUTF8.txt檔案內的每一列資料，分開每個欄位，然後
透過ProductBean的建構子存入ProductBean物件，再利用ProductDao介面的save()方法將每個產品
的資料儲存到Product表格內。

你需要完成本類別與 mssql.ex00.dao.impl.ProductDaoImpl.save(ProductBean)方法

*/
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Timestamp;

import mysql.ex00.SystemUtils;
import mysql.ex00.dao.ProductDao;
import mysql.ex00.dao.solution.ProductDaoImpl;
//import mysql.ex00.dao.impl.ProductDaoImpl;
import mysql.ex00.model.ProductBean;

public class InsertProduct {
	public static void main(String args[]) {
		// 開啟BufferedReader類別，因為它可以讀入文字檔的一橫列資料
		try (
				FileInputStream fis = new FileInputStream("data/product/ProductInsertDataUTF8.txt"); 
				InputStreamReader isr = new InputStreamReader(fis,"UTF8");
				BufferedReader br = new BufferedReader(isr);
		) {
			// 建立 ProductDao 物件
			ProductDao productDao = new ProductDaoImpl();
			String line = null;
			// 利用while迴圈，每次讀入一列的資料
			while ( ( line = br.readLine() ) != null){
				// 以逗號當作分界符號來分割讀入的一列資料
				String[] sa = line.split(",");
				String 	name 		= sa[0].trim();						//	產品名稱   
				Double 	price 		= Double.parseDouble(sa[1].trim());	//	單價
				Integer quantity 	= Integer.parseInt(sa[2].trim());	//	數量
				
				Timestamp productTime = Timestamp.valueOf(sa[3].trim());	// 建檔日期
				Blob 	blob = SystemUtils.fileToBlob(sa[4].trim());	
				Clob 	clob = SystemUtils.fileToClob(sa[5].trim(), "UTF8");
				String  fileName = SystemUtils.extractFilename(sa[4].trim());
				// 將產品的資料用ProductBean封裝起來，然後將此Bean物件傳給
				// productDao的insert()方法，由此方法將一筆產品資料寫入資料庫
				ProductBean bean = new ProductBean(null, name, price, quantity, 
						blob, clob, productTime, fileName );
				// 呼叫productDao的方法儲存productBean
				productDao.save(bean);
				System.out.println("新增記錄成功");
			}
			
		} catch (Exception ex) {
			System.out.println("新增記錄失敗:"  + ex.getMessage());
			ex.printStackTrace();
		}
	}
}