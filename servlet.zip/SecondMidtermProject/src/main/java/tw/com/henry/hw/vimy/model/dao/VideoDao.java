package tw.com.henry.hw.vimy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import tw.com.henry.hw.vimy.model.bean.CreatorBean;
import tw.com.henry.hw.vimy.model.bean.VideoBean;

public class VideoDao {

	private Connection conn;

	public VideoDao(Connection conn) {
		this.conn = conn;
	}

	// 新增影片資料
	public int addNewVideo(VideoBean video) {
		String SQL = "INSERT INTO Video (id, name, thumbnail, size,"
					+ "filepath, filetype, video, info, creator)"
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, video.getId());
			stmt.setString(2, video.getName());
			stmt.setString(3, video.getThumbnail());
			stmt.setInt(4, video.getSize());
			stmt.setString(5, video.getFilepath());
			stmt.setString(6, video.getFiletype());
			stmt.setBytes(7, video.getVideo());
			stmt.setString(8, video.getInfo());
			stmt.setInt(9, video.getCreator());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 透過ID更新影片資料
	public int updateVideo(VideoBean video) {
		String SQL = "UPDATE Video SET name=?, thumbnail=?, size=?, filepath=?,"
					+ "filetype=?, video=?, info=?, creator=? WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, video.getName());
			stmt.setString(2, video.getThumbnail());
			stmt.setInt(3, video.getSize());
			stmt.setString(4, video.getFilepath());
			stmt.setString(5, video.getFiletype());
			stmt.setBytes(6, video.getVideo());
			stmt.setString(7, video.getInfo());
			stmt.setInt(8, video.getCreator());
			stmt.setInt(9, video.getId());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 可以寫很長的註解
	 * 
	 * @param id 這個是影片編號
	 * @param xxx   之類的
	 * 
	 * @return int 成功或失敗的結果，1為成功
	 */
	public int deleteVideoByID(int id) {
		String SQL = "DELETE * FROM Video WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 刪除所有影片資料
	public int deleteAllVideos() {
		String SQL = "TRUNCATE TABLE Video;";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 透過ID搜尋影片資料
	public VideoBean getVideoByID(int id) {
		String SQL = "SELECT * FROM Video WHERE id = ?";
		VideoBean Video = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					Video = new VideoBean();
					Video.setId(rs.getInt("id"));
					Video.setName(rs.getString("name"));
					Video.setThumbnail(rs.getString("thumbnail"));
					Video.setVideo(rs.getBytes("video"));
					Video.setInfo(rs.getString("info"));
					Video.setCreator(rs.getInt("creator"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Video;
	}

	// 搜尋所有影片資料
	public List<VideoBean> getAllVideos() {
		String SQL = "SELECT * FROM Video;";
		List<VideoBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				VideoBean Video = null;
				while (rs.next()) {
					Video = new VideoBean();
					Video.setId(rs.getInt("id"));
					Video.setName(rs.getString("name"));
					Video.setThumbnail(rs.getString("thumbnail"));
					Video.setVideo(rs.getBytes("video"));
					Video.setInfo(rs.getString("info"));
					Video.setCreator(rs.getInt("creator"));
					list.add(Video);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// 透過片名進行模糊搜尋
	public List<VideoBean> getAllVideosByName(String name) {
		String SQL = "SELECT * FROM Video WHERE name LIKE '%" + name + "%'";
		List<VideoBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				VideoBean Video = null;
				while (rs.next()) {
					Video = new VideoBean();
					Video.setId(rs.getInt("id"));
					Video.setName(rs.getString("name"));
					Video.setThumbnail(rs.getString("thumbnail"));
					Video.setVideo(rs.getBytes("video"));
					Video.setInfo(rs.getString("info"));
					Video.setCreator(rs.getInt("creator"));
					list.add(Video);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// 透過影片ID搜尋創作者資料
	public CreatorBean getDeptByVideoID(int id) {
		String SQL = "SELECT * FROM Creator AS c JOIN Video AS v ON v.creator = c.id AND v.creator = ?";
		CreatorBean crt = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					crt = new CreatorBean();
					crt.setId(rs.getInt("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getString("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getInt("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setSocialAccount("Google", rs.getString("google_account"));
					crt.setSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setSocialAccount("Instagram", rs.getString("ig_account"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return crt;
	}

}