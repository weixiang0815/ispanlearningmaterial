package ch02.lab03;

//練習目的：了解識別字的命名規則(類別名稱就是識別字的一種)
//取消下面的註解後，更正本程式的錯誤。 

//public class 1stClass {
   
//}

