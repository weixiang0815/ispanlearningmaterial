package tw.pers.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GetImgWithBase64.do")
public class GetImgWithBase64 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String imgId = request.getParameter("imgId");

		String SQL = "SELECT * FROM [PetForum].[dbo].[Users] WHERE id = ?";

		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement preState = conn.prepareStatement(SQL);
			preState.setString(1, imgId);
			ResultSet rs = preState.executeQuery();

			if (rs.next()) {
				String photoString = rs.getString("photo");
				
				request.setAttribute("photo", photoString);
			}

			rs.close();
			preState.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.getRequestDispatcher("ShowBase64.jsp").forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
