package tw.hibernatedemo.action;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tw.hibernatedemo.model.Book;
import tw.hibernatedemo.model.BookUser;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoOneToManyActionEx3 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();

			// 我們只知道 bookuser id = 1，他還了一本書叫【SQL 100 種解法】
			BookUser user3 = session.get(BookUser.class, 1);
			Set<Book> books = user3.getBooks();
			Iterator<Book> itr_book = books.iterator();
			while(itr_book.hasNext()) {
				Book book = itr_book.next();
				if (book.getBooktitle().contentEquals("SQL 100 種解法")) {
//					book.setBookUser(null);
					//	若 OneToMany 有設定 orphanRemoval = true，則不用第 28 跟 31 行
					itr_book.remove();
//					session.delete(book);
				}
			}
			session.get(BookUser.class, 1).getBooks().forEach(b -> System.out.println("書名：" + b.getBooktitle()));
			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
