package tw.hibernatedemo.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tw.hibernatedemo.model.CompanyBean;
import tw.hibernatedemo.model.CompanyDao;
import tw.hibernatedemo.util.HibernateUtil;

public class TestCompanyDaoAction {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			CompanyDao comDao = new CompanyDao(session);
			
//			CompanyBean com1 = new CompanyBean(1003, "CloudFlare");
//			comDao.insert(com1);
			
//			CompanyBean result = comDao.select(999);
//			if (result != null) {
//				System.out.println("Name : " + result.getCompanyName());
//			} else {
//				System.out.println("查無資料");
//			}
			
//			List<CompanyBean> result = comDao.selectAll();
//			result.forEach(comp -> System.out.println(comp.toString()));

			CompanyBean result = comDao.updateOne(1002, "Alphabet");
			if (result != null) {
				System.out.println("更新成功");
			} else {
				System.out.println("更新失敗");
			}
			
//			boolean result = comDao.deleteOne(1003);
//			if (result) {
//				System.out.println("刪除成功");
//			} else {
//				System.out.println("刪除失敗");
//			}
			
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
