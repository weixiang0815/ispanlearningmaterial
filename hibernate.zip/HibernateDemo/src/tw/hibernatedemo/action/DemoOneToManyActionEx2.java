package tw.hibernatedemo.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tw.hibernatedemo.model.BookUser;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoOneToManyActionEx2 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();

			// 我們只知道 bookuser id = 1 ， 請印出他借的書名
			BookUser user2 = session.get(BookUser.class, 1);
			user2.getBooks().forEach(b -> System.out.println("書名：" + b.getBooktitle()));

//			Iterator<Book> itr_book = user2.getBooks().iterator();
//			while(itr_book.hasNext()) {
//				System.out.println("書名：" + itr_book.next().getBooktitle());
//			}

			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
