package _01.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _01.dao.CustomerDao;
import _01.model.CustomerBean;
import _01.service.CustomerService;

@Transactional
@Service
public class CustomerServiceImpl implements CustomerService {

	CustomerDao custDao;
	
	@Autowired
	public CustomerServiceImpl(CustomerDao custDao) {
		this.custDao = custDao;
	}

	@Override
	public CustomerBean findById(Integer id) {
		return custDao.findById(id);
	}

	@Override
	public List<CustomerBean> findAll() {
		return custDao.findAll();
	}

	@Override
	public Object save(CustomerBean bean) {
		return custDao.save(bean);
	}

	@Override
	public void update(CustomerBean bean) {
		custDao.update(bean);
	}

	@Override
	public void deleteById(Integer id) {
		custDao.deleteById(id);
	}
}
