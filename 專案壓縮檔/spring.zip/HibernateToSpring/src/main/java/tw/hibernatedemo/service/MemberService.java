package tw.hibernatedemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tw.hibernatedemo.model.Member;
import tw.hibernatedemo.model.MemberDao;

@Service
public class MemberService {

	@Autowired
	private MemberDao mDao;

	public Member checkLogin(String loginName, String loginPwd) {
		return mDao.findByNameAndPassword(loginName, loginPwd);
	}
	
}
