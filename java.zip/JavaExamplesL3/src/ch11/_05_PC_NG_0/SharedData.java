package ch11._05_PC_NG_0;

public class SharedData {
	int data;
}
