package EEIT157_14_王威翔_第二章作業;

public class Ex2 {
	public static void main(String[] arg) {
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
	}
}
