package tw.hibernatedemo.action;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tw.hibernatedemo.model.Friend;
import tw.hibernatedemo.model.MyGroup;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoManyToManyActionEx1 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			// 假設只知道 work 群組 id 是 3
			MyGroup group1 = session.get(MyGroup.class, 3);
			
			Set<Friend> friends = group1.getFriends();
			
			// 從 friends 裡面移除 Tina
			Iterator<Friend> itr_friends = friends.iterator();
			while(itr_friends.hasNext()) {
				Friend friend = itr_friends.next();
				if (friend.getFriendName().contentEquals("Tina")) {
					itr_friends.remove();
				}
			}
			
			// 新增 Bill 為 Friend
			Friend newFriend = new Friend();
			newFriend.setFriendName("Bill");
			session.save(newFriend);
			
			// 加 Bill 到 work 群組內
			friends.add(newFriend);

			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
