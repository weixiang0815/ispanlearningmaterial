package com.tw.henry.controller.insert;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Video;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/UploadVideo.do")
@MultipartConfig
public class UploadVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		Part videoFile = request.getPart("video");
		String filename = videoFile.getSubmittedFileName();
		System.out.println(filename);
		Video video = null;
		String result;
		try {
			if (!"".contentEquals(filename)) {
				video = new Video();
				video.setName(request.getParameter("name"));
				Part thumbnail = request.getPart("thumbnail");
				video.setThumbnail(thumbnail.getInputStream().readAllBytes());
				video.setVideo(videoFile.getInputStream().readAllBytes());
				video.setFilename(videoFile.getSubmittedFileName());
				String fileContentType = videoFile.getContentType();
				video.setFiletype(fileContentType.substring(fileContentType.indexOf("/") + 1));
				video.setInfo(request.getParameter("info"));
				video.setCreatorId(request.getParameter("creatorId"));
				video.setCreatorName(request.getParameter("creatorName"));
				result = new VideoDao(ConnectionFactory.getConnection()).addNewVideo(video);
			} else {
				result = "上傳影片不得為空白";
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/insert/UploadVideo.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
