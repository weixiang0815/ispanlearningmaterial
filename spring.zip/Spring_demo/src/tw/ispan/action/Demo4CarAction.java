package tw.ispan.action;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import tw.ispan.model.Car;

public class Demo4CarAction {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

//		Car car1 = context.getBean("car1", Car.class);
//		System.out.println("name: " + car1.getCarName());
//		System.out.println("brand: " + car1.getBrand());

		Car car2 = context.getBean("car2", Car.class);
		System.out.println("releaseDate: " + car2.getReleaseDate());
		System.out.println("productionDate: " + car2.getProductionDate());

//		Car car3 = context.getBean("car3", Car.class);
//		System.out.println("id: " + car3.getId());
//		System.out.println("name: " + car3.getCarName());
//		System.out.println("brand: " + car3.getBrand());
		
		context.close();
	}

}
