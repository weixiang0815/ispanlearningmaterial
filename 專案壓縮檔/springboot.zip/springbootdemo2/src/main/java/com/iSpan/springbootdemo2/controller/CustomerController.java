package com.iSpan.springbootdemo2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iSpan.springbootdemo2.model.Customer;
import com.iSpan.springbootdemo2.model.CustomerRepository;

@Controller
public class CustomerController {

	@Autowired
	private CustomerRepository customerDao;

	@ResponseBody
	@PostMapping("/customer/add")
	public Customer insert1() {
		Customer cus1 = new Customer();
		cus1.setName("阿文");
		cus1.setLevel(2);

		Customer response = customerDao.save(cus1);
		return response;
	}

	@ResponseBody
	@PostMapping("/customer/add2")
	public Customer insert2(@RequestBody Customer cus) {
		return customerDao.save(cus);
	}

	@ResponseBody
	@PostMapping("/customer/addd")
	public List<Customer> addManyCustomer(@RequestBody List<Customer> customers) {
		return customerDao.saveAll(customers);
	}

	@ResponseBody
	@GetMapping("/customer/{id}")
	public Customer getCustomerById(@PathVariable Integer id) {
		Optional<Customer> op = customerDao.findById(id);

		if (op.isPresent()) {
			return op.get();
		}

		Customer responsecus = new Customer();
		responsecus.setName("沒有這筆資料");
		return responsecus;
	}

	@ResponseBody
	@GetMapping("/customer")
	public List<Customer> findAllCustomer() {
		return customerDao.findAll();
	}

	@ResponseBody
	@DeleteMapping("/customer/delete")
	public String deleteById(@RequestParam Integer id) {
		try {
			customerDao.deleteById(id);
		} catch (EmptyResultDataAccessException e) {
			return "沒有這筆資料";
		}
		return "成功刪除";
	}

	@ResponseBody
	@PutMapping("/customer/update")
	@Transactional // 用 @Transactional 蓋掉預設的 @Transactional(readOnly = true)
	public String updateLevelById(@RequestParam Integer id, @RequestParam Integer level) {
		Optional<Customer> op = customerDao.findById(id);

		if (op.isPresent()) {
			Customer cus = op.get();
			cus.setLevel(level);
//			customerDao.save(cus);	//	Spring Data JPA 的 save 是 saveOrUpdate
			return "修改 ok";
		}

		return "沒有這筆資料";
	}

}