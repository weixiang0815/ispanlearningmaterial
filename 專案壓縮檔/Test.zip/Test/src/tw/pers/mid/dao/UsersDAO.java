package tw.pers.mid.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import tw.pers.mid.bean.Users;

public class UsersDAO {

	private Connection conn;

	public UsersDAO(Connection conn) {
		this.conn = conn;
	}

	public Users getOneUserByID(int id) {
		String SQL = "SELECT * FROM Users WHERE id = ?";
		try {
			PreparedStatement preState = conn.prepareStatement(SQL);
			preState.setInt(1, id);
			ResultSet rs = preState.executeQuery();
			if (rs.next()) {
				Users u = new Users();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setAge(rs.getInt("age"));
				return u;
			}
			rs.close();
			preState.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public List<Users> getAllUsers() {
		String SQL = "SELECT * FROM Users";
		List<Users> uList = new ArrayList<Users>();

		try {
			PreparedStatement preState = conn.prepareStatement(SQL);
			ResultSet rs = preState.executeQuery();
			while (rs.next()) {
				Users u = new Users();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setAge(rs.getInt("age"));
				uList.add(u);
			}
			rs.close();
			preState.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return uList;
	}

	public List<Users> getUsersByNameWithKeyword(String keyword) {
		String SQL = "SELECT * FROM Users WHERE name LIKE ?";
		List<Users> uList = new ArrayList<Users>();

		try {
			PreparedStatement preState = conn.prepareStatement(SQL);
			preState.setString(1, "%" + keyword + "%");
			ResultSet rs = preState.executeQuery();
			while (rs.next()) {
				Users u = new Users();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setAge(rs.getInt("age"));
				uList.add(u);
			}
			rs.close();
			preState.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return uList;
	}

}
