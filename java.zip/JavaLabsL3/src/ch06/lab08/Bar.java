package ch06.lab08;

public class Bar {
	public void greeting(String s) {
		System.out.println(s);
	}
}
