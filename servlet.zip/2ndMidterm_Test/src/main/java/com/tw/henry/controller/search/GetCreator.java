package com.tw.henry.controller.search;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Creator;
import com.tw.henry.model.dao.CreatorDao;

@WebServlet("/GetCreator.do")
public class GetCreator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String account = request.getParameter("account");
		String result;
		Creator crt = null;
		try {
			CreatorDao creatorDao = new CreatorDao(ConnectionFactory.getConnection());
			if (!"".contentEquals(id)) {
				crt = creatorDao.getCreatorByID(id);
				result = "查詢成功";
			} else if (!"".contentEquals(account)) {
				crt = creatorDao.getCreatorByAccount(account);
				result = "查詢成功";
			} else {
				result = "查詢欄位不得為空白";
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("crt", crt);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/search/GetCreator.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
