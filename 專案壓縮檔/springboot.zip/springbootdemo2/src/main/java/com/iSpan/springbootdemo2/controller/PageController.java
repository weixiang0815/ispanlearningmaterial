package com.iSpan.springbootdemo2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.iSpan.springbootdemo2.model.Message;
import com.iSpan.springbootdemo2.service.MessageService;

@Controller
public class PageController {

	@Autowired
	private MessageService mService;
	
	@GetMapping("/")
	public String goToIndex() {
		return "index";
	}

	@GetMapping("/test1")
	@ResponseBody
	public String test() {
		return "6666";
	}

	@GetMapping("/playAjax/intro1")
	public String goAjaxIntro() {
		return "ajax/ajax1-intro1";
	}

	@GetMapping("/playAjax/sendPage")
	public String goAjaxSendData() {
		return "ajax/ajax2-send";
	}
	
	@GetMapping("/playAjax/message")
	public String goAjaxMessage() {
		return "ajax/ajax3-message";
	}

}