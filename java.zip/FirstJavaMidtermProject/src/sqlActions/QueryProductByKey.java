package sqlActions;

// 依鍵值查詢產品資料

/*
文字檔data/product/ProductQueryData.txt內有多筆產品的代號(主鍵)，
// 逐筆讀入ProductQueryData.txt檔案內的每一列資料，將此代號轉換為int型態，
// 然後呼叫ProductDaoImpl類別的findById(key)方法查詢單筆產品資料。

你需要完成本類別與mssql.ex00.dao.impl.ProductDaoImpl.findById()方法
*/
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import dao.ProductDao;
import dao.ProductDaoImpl;
import model.ProductBean;

public class QueryProductByKey {
	public static void main(String args[]) {
		try (
			FileInputStream fis = new FileInputStream("data/product/ProductQueryData.txt"); 
			InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
			BufferedReader br = new BufferedReader(isr);
		) {
			String line = null;
			ProductDao productDao = new ProductDaoImpl();
			
			while ( (line = br.readLine()) != null){
				int key = Integer.parseInt(line.trim());
				ProductBean productBean = productDao.findById(key);
				if (productBean == null){
					System.out.println("查無此資料:Key = " + key); 
				} else {
					System.out.println("查得資料: " +  productBean);
				}
			}
			
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		}
		System.out.println("==========================================");
		System.out.println("查詢記錄完畢");
	}
}