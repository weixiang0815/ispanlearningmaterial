package mysql.ex00.dao.solution;

import java.sql.Blob;
import java.sql.Clob;
// 本程式維護產品資料
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import mysql.ex00.SystemConstant;
import mysql.ex00.dao.ProductDao;
import mysql.ex00.model.ProductBean;

public class ProductDaoImpl implements ProductDao{
	public ProductDaoImpl() {
	}
	
	// 新增單筆產品紀錄
	@Override
	public void save(ProductBean productBean) throws SQLException {
		String sql = "INSERT INTO Product (PRODUCT_NAME, PRICE, QUANTITY, "
						+ "PRODUCT_DATE, IMAGE, REMARK, FileName)"
						+ " VALUES(?, ?, ?, ?, ?, ?, ?)";
		try (
			Connection con = DriverManager.getConnection(SystemConstant.getDbURL());
			PreparedStatement stmt = con.prepareStatement(sql);
		) {
			stmt.setString(1, productBean.getProductName());
			stmt.setDouble(2, productBean.getPrice());
			stmt.setInt(3, productBean.getQuantity());
			stmt.setTimestamp(4, productBean.getProductDate());
			stmt.setBlob(5, productBean.getImage());
			stmt.setClob(6, productBean.getRemark());
			stmt.setString(7, productBean.getFileName());
			stmt.executeUpdate();
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
	}
	// 依鍵值刪除單筆產品紀錄
	@Override
	public void deleteById(int key) throws SQLException {
		String sql = "DELETE FROM Product WHERE PRODUCT_ID = ? ";
		try (
			Connection con = DriverManager.getConnection(SystemConstant.getDbURL());
			PreparedStatement stmt = con.prepareStatement(sql);
		) {
			stmt.setInt(1, key);
			int n = stmt.executeUpdate();
			if (n == 0) {
				throw new RuntimeException("該紀錄不存在, key=" + key);
			}
		} 
	}
	// 修改單筆產品紀錄
	@Override
	public void update(ProductBean productBean) throws SQLException {
		String sql = "UPDATE Product SET PRODUCT_NAME = ?, PRICE = ?, "
				+ " QUANTITY = ?,  PRODUCT_DATE = ?, IMAGE = ?,  REMARK = ?, " 
				+ " FileName = ? where PRODUCT_ID = ? ";
		try (
			Connection con = DriverManager.getConnection(SystemConstant.getDbURL());
			PreparedStatement stmt = con.prepareStatement(sql);
		) {
			stmt.setString(1, productBean.getProductName());
			stmt.setDouble(2, productBean.getPrice());
			stmt.setInt(3, productBean.getQuantity());
			stmt.setTimestamp(4, productBean.getProductDate());
			stmt.setBlob(5, productBean.getImage());
			stmt.setClob(6, productBean.getRemark());
			stmt.setString(7, productBean.getFileName());
			stmt.setInt(8, productBean.getProductId());
			int n = stmt.executeUpdate();
			if (n == 0) {
				throw new RuntimeException("該紀錄不存在, key=" + productBean.getProductId());
			}
		} 
	}

	

	// 查詢多筆產品紀錄
	@Override
	public List<ProductBean> findAll() throws SQLException {
		String sql = "SELECT * FROM Product";
		List<ProductBean> list = new ArrayList<>();
		ProductBean productBean = null;
		try (
			Connection con = DriverManager.getConnection(SystemConstant.getDbURL());
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rset = stmt.executeQuery();
		) {
			while (rset.next()) {
				Integer id = rset.getInt(1);
				String name = rset.getString(2);
				Double price = rset.getDouble(3);
				Integer quantity = rset.getInt(4);
				Timestamp ts = rset.getTimestamp(5);
				Blob image = rset.getBlob(6);
				Clob remark = rset.getClob(7);
				String filename = rset.getString(8);
				productBean = new ProductBean(id, name, price, 
						quantity, image, remark, ts, filename);
				list.add(productBean);
			}
		} 
		return list;
	}

	// 依鍵值查詢單筆產品紀錄
	@Override
	public ProductBean findById(int key) throws SQLException {
		String sql = "SELECT * FROM Product WHERE PRODUCT_ID = ? ";
		ProductBean productBean = null;

		try (
			Connection con = DriverManager.getConnection(SystemConstant.getDbURL());
			PreparedStatement stmt = con.prepareStatement(sql);
		) {
			stmt.setInt(1, key);
			try (
				ResultSet rset = stmt.executeQuery();
			) {
				if (rset.next()) {
					Integer id = rset.getInt(1);
					String name = rset.getString(2);
					Double price = rset.getDouble(3);
					Integer quantity = rset.getInt(4);
					Timestamp ts = rset.getTimestamp(5);
					Blob image = rset.getBlob(6);
					Clob remark = rset.getClob(7);
					String filename = rset.getString(8);
					productBean = new ProductBean(id, name, price, 
							quantity, image, remark, ts, filename);
				}
			}
		} 
		return productBean;
	}
}