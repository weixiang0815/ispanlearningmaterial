package mysql.lab06;

// 更新產品資料
/*
文字檔data/product/ProductUpdateData.txt內有多筆產品資料，
每一列表示一個產品代號(即主鍵)、產品名稱、單價、數量、建檔日期、圖片檔路徑、說明檔路徑等，
每個欄位之間用","隔開。請逐列讀入ProductUpdateData.txt檔案內的每一列資料，
區分每個欄位，然後透過ProductBean的建構子，將這些欄位放入ProductBean物件內，
再利用ProductDaoImpl類別的update()將產品的資料新增到資料庫內。

你需要完成本類別與mssql.ex00.dao.impl.ProductDaoImpl.update()方法

*/
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import mysql.ex00.dao.ProductDao;
import mysql.ex00.dao.impl.ProductDaoImpl;


public class UpdateProduct {
	@SuppressWarnings("unused")
	public static void main(String args[]) {
		try (
			FileInputStream fis = null; 
			InputStreamReader isr = null;
			BufferedReader br = null;	
		) {
			String line = null;
			ProductDao productDao = new ProductDaoImpl();
			/*
			while ( (line = br.???????()) != null){
				String[] sa = line.????(",");
				Integer id 			= ??????.??????(sa[0].trim());	// Key	
				String 	name 		= sa[1].trim();		//	產品名稱   
				Double 	price 		= ??????.????????(sa[2].trim());//	單價
				Integer quantity 	= ??????.???????(sa[3].trim());//	數量
				
				Timestamp productTime = ???????.??????(sa[4].trim());	// 建檔日期
				Blob 	blob = SystemUtils.??????????(sa[5].trim());	
				Clob 	clob = SystemUtils.??????????(sa[6].trim(), "UTF8");
				String  fileName = SystemUtils.??????????(sa[5].trim());
				// 將產品的資料用ProductBean封裝起來，然後將此Bean物件傳給
				// productDao的update()方法，由此方法將一筆產品資料寫入資料庫
				ProductBean bean = new ProductBean(id, name, price, quantity, 
						blob, clob, productTime, fileName );
				dao.update(bean);
				System.out.println("修改記錄:Key=" + id + " " + "成功");
			}
			*/
		} catch (Exception ex) {
			System.err.println("修改記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		} 
	}
}