package tw.hibernatedemo.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import tw.hibernatedemo.model.Department;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoDepartmentActionEx6 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			// 查詢
//			Department dept6 = session.get(Department.class, 1);
//			System.out.println("id:" + dept6.getId());
//			System.out.println("name:" + dept6.getName());
			
			// 刪除
//			Department dept6 = session.get(Department.class, 1);
//			session.delete(dept6);
			
			// 更新
			Department dept6 = session.get(Department.class, 2);
			dept6.setName("人資部門");
			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
