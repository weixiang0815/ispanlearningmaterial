package EEIT157_14_王威翔_第八章作業;

import java.io.*;
import java.net.*;

public class Ex2 {

	public static void main(String[] args) {
		methodA();
		System.out.println("Program ends");
	}
	
	static void methodA() {
		try {
			int i = 3 / 0;
			URL urlA = new URL("http://www.seed.net.tw");
			FileInputStream fis = new FileInputStream("C:\\user\\student\\Desktop\\Text.txt");
		} catch (ArithmeticException e) {
		} catch (MalformedURLException e) {
		} catch (FileNotFoundException e) {
		}
	}
}
