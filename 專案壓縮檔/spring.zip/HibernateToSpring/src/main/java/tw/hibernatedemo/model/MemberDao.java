package tw.hibernatedemo.model;

import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDao {

	@Autowired
	private SessionFactory factory;
	
	public Member findByNameAndPassword(String memberName, String memberPwd) {
		Session session = factory.getCurrentSession();
		String queryStr = "FROM Member m WHERE m.memberName = :pName AND m.memberPwd = :pwd";
		
		try {
			Member result = session.createQuery(queryStr, Member.class)
				.setParameter("pwd", memberPwd)
				.setParameter("pName", memberName)
				.getSingleResult();
			return result;
		} catch (NoResultException e) {
			System.out.println("沒有這筆資料");
			System.out.println(e);
			return null;
		}
	}
	
}
