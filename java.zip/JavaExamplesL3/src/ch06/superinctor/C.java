package ch06.superinctor;

public class C extends B {
	int z = (int)(Math.random() * 100) + y;
	
	public C(int z) {
		super();
		this.z = z;
	}
	
//	public C() {
//		
//	}

	public void displayData() {
		System.out.println("x=" + x);
		System.out.println("y=" + y);
		System.out.println("z=" + z);
	} 
}
