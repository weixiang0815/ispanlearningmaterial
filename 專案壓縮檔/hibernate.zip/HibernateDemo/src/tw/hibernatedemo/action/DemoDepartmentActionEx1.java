package tw.hibernatedemo.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import tw.hibernatedemo.model.Department;

public class DemoDepartmentActionEx1 {

	public static void main(String[] args) {
		try (StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
				SessionFactory factory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
				Session session = factory.openSession();) {
			session.beginTransaction();
			Department dept1 = new Department("HR");
			session.save(dept1);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
