package com.tw.henry.controller.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Admin;
import com.tw.henry.model.dao.AdminDao;

@WebServlet("/AdminLogin.do")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String account = request.getParameter("account");
		String password = request.getParameter("password");
		String result;
		Admin admin = null;
		try {
			admin = new AdminDao(ConnectionFactory.getConnection()).getAdminByAccount(account);
			if (admin == null) {
				result = "查無此帳號：" + account;
			} else {
				if (!password.contentEquals(admin.getPassword())) {
					result = "密碼輸入錯誤：" + password;
				} else {
					result = "管理員登入成功";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/user/AdminInfo.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
