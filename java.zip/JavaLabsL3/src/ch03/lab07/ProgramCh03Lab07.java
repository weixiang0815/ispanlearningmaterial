package ch03.lab07;
/*
  請編寫程式ch03.lab07.ProgramCh03Lab07，在main()之內
  請計算89個雞蛋是多少打又多少個。
*/
public class ProgramCh03Lab07 {
    public static void main(String[] args) {
    	System.out.println("89個雞蛋是" + (89 / 12) + "打又" + (89 % 12) + "個");
        
        
    }
}
