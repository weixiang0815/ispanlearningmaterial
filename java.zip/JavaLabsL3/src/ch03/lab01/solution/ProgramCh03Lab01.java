package ch03.lab01.solution;

// 練習目的：了解變數一定要有初值才能參與運算

public class ProgramCh03Lab01 {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		int sum = i + j;
		System.out.println("本程式有何問題 ?");
	}
}
