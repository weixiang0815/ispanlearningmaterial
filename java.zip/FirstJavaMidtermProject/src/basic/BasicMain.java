package basic;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import sqlActions.CreateTable;
import sqlActions.InsertTable;

public class BasicMain {

	public static void main(String[] args) {
		// 1. 把檔案資料讀進SQL Server
		// 1.0. 將SQL Server資料庫建好 (√)
		// 1.1. 讀取下載好的檔案中的第一列文字當作表頭 (√)
		// 1.2. 將讀到的表頭送進SQL Server創建資料表 (√)
		// 1.3. 將檔案剩餘的每列資料分割成Bean送進資料表insert (√)
		// 2. 提取SQL Server資料並秀出來
		// 2.1. 使用executeQuery()將資料表內容提取出來
		
//		printTable();
//		
//		System.out.println("以下列印表頭：");
//		String[] titles = getTitles();
//		for(int i = 0; i < titles.length; i ++) {
//			System.out.println(i + 1 + ". " + titles[i]);
//		}
//		System.out.println();
		System.out.println("---------------------------------");
		CreateTable.createTable();
		System.out.println("---------------------------------");
		InsertTable.insertTable();
		System.out.println("---------------------------------");
	}
	
	public static String[] getTitles() {
		String[] table_title = null;
		try(
				
				FileInputStream fis = new FileInputStream("C:\\Users\\Student\\Downloads\\TDCC_OD_4-1.csv");
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
		) {
			table_title = br.readLine().split(",");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return table_title;
	}
	
	public static void printTable() {
		StringBuffer ret_str = new StringBuffer();
		try(
				
				FileInputStream fis = new FileInputStream("C:\\Users\\Student\\Downloads\\TDCC_OD_4-1.csv");
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
				) {
			System.out.println("以下將檔案內的資料印出：\n");
			String s = "";
			while ((s = br.readLine()) != null) {
				System.out.println(s);
				ret_str.append(s);
			}
			System.out.println("\n資料列印完畢\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
