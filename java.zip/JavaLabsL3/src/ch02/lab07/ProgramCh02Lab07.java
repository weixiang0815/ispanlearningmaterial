package ch02.lab07;

// 練習目的：了解如何定義boolean與char型態的變數

public class ProgramCh02Lab07 {
	public static void main(String[] args) {
		// 定義一個boolean型態的變數 bo1, 初值為 true;
		
		// 定義一個boolean型態的變數 bo2, 初值為 false;
		
		// 定義一個char型態的變數 ch1, 初值為 'A';
		
		// 定義一個char型態的變數 ch2, 初值為 '李';
		
	}
}
