/**
 * 
 */
/**
 * @author Student
 *
 */
module FirstJavaMidtermProjectGUI {
	requires java.sql;
	requires java.sql.rowset;
	requires java.desktop;
	requires jsoup;
}