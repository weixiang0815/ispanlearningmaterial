package EEIT157_14_王威翔_第六章作業;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		double sum = 0;
		int num = 0;
		int max = Integer.MIN_VALUE;
		int min = Integer.MAX_VALUE;
		
		while(true) {
			String str = s.nextLine();
			if(str.contentEquals("quit")) {
				break;
			}
			String[] num_str = str.split(" ");
			
			for(int i = 0; i < num_str.length; i ++) {
				sum += Integer.parseInt(num_str[i]);
				num ++;
				if(Integer.parseInt(num_str[i]) < min)
					min = Integer.parseInt(num_str[i]);
				if(Integer.parseInt(num_str[i]) > max)
					max = Integer.parseInt(num_str[i]);
			}
		}
		s.close();
		
		System.out.print("總和：" + (int)sum + "，");
		System.out.print("平均：" + sum / num + "，");
		System.out.print("，最大值：" + max + "，");
		System.out.print("最小值：" + min);
	}

}
