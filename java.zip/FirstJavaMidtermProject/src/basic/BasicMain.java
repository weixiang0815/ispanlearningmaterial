package basic;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import sqlActions.CreateTable;
import sqlActions.InsertTable;
import sqlActions.QueryAllProducts;

public class BasicMain {

	public static void main(String[] args) {
		System.out.println("---------------------------------");
		CreateTable.createTable();
		System.out.println("---------------------------------");
		InsertTable.insertTable();
		System.out.println("---------------------------------");
		QueryAllProducts.queryAllProducts();
		System.out.println("---------------------------------");
	}
	
	public static String[] getTitles() {
		String[] table_title = null;
		try(
				
				FileInputStream fis = new FileInputStream("C:/Users/Student/Desktop/TDCC_OD_4-1.csv");
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
		) {
			table_title = br.readLine().split(",");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return table_title;
	}
	
	public static void printTable() {
		StringBuffer ret_str = new StringBuffer();
		try(
				
				FileInputStream fis = new FileInputStream("C:/Users/Student/Desktop/TDCC_OD_4-1.csv");
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
				) {
			System.out.println("以下將檔案內的資料印出：\n");
			String s = "";
			while ((s = br.readLine()) != null) {
				System.out.println(s);
				ret_str.append(s);
			}
			System.out.println("\n資料列印完畢\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
