package tw.hibernatedemo.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import tw.hibernatedemo.model.GoodPhoto;
import tw.hibernatedemo.service.GoodPhotoService;

@MultipartConfig
@WebServlet("/GoodPhotoUploadServlet.do")
public class GoodPhotoUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		Part file = request.getPart("file");
		InputStream file_stream = file.getInputStream();
		String photoName = request.getParameter("photoName");
		GoodPhoto photo = new GoodPhoto();
		photo.setPhotoFile(file_stream.readAllBytes());
		photo.setPhotoName(photoName);
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		GoodPhotoService gService = context.getBean("goodPhotoService", GoodPhotoService.class);
		GoodPhoto tempPhoto = gService.inserPhoto(photo);
		request.setAttribute("result", tempPhoto != null ? "上傳成功" : "上傳失敗");
		String path = "/page/" + (tempPhoto != null ? "upload_success.jsp" : "upload.jsp");
		request.getRequestDispatcher(path).forward(request, response);
	}

}
