package _01.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import _01.dao.CustomerDao;
import _01.model.CustomerBean;
import _01.ude.NoSuchCustomerException;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	SessionFactory factory;
	
	@Autowired
	public CustomerDaoImpl(SessionFactory factory) {
		this.factory = factory;
	}

	@Override
	public CustomerBean findById(Integer id) {
		CustomerBean bean = null;
		Session session = factory.getCurrentSession();
		String hql  = "FROM CustomerBean cb WHERE cb.customerId = :id";
		try {
			bean = (CustomerBean)session.createQuery(hql)
										.setParameter("id", id)
										.getSingleResult();
		} catch(NoResultException e) {
			throw new NoSuchCustomerException(id);  // 表示查無紀錄
		}
		return bean;
	}

	@Override
	public List<CustomerBean> findAll() {
		Session session = factory.getCurrentSession();
		String hql  = "FROM CustomerBean";
		List<CustomerBean> list = new ArrayList<>();
		list = session.createQuery(hql, CustomerBean.class).getResultList();
		return list;
	}

	@Override
	public Object save(CustomerBean bean) {
		Session session = factory.getCurrentSession();
		return session.save(bean);
	}
	
	@Override
	public void update(CustomerBean bean) {
		Session session = factory.getCurrentSession();
		session.update(bean);
	}

	@Override
	public void deleteById(Integer key) {
		Session session = factory.getCurrentSession();
		CustomerBean customer = new CustomerBean();
		customer.setCustomerId(key);
		session.delete(customer);
	}
}
