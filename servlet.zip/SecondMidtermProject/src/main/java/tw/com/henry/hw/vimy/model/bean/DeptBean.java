package tw.com.henry.hw.vimy.model.bean;

import java.io.Serializable;

public class DeptBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String deptno;
	private String dname;

	public DeptBean() {
	}

	public DeptBean(String deptno, String dname) {
		this.deptno = deptno;
		this.dname = dname;
	}

	public String getDeptno() {
		return deptno;
	}

	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	@Override
	public String toString() {
		return "DeptBean [deptno=" + deptno + ", dname=" + dname + "]";
	}
}
