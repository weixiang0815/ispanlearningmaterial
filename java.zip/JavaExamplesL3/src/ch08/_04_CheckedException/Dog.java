package ch08._04_CheckedException;

public class Dog extends Mammal {
	public void smile(){
    	System.out.println("Dog :)");
    }
}
