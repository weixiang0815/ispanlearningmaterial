package img;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import system.SystemConstant;

public class QueryImg {
	private static String path = "";
	private static String filename = "";
	private static String sql = "";

	public static void insertImg(Scanner in) {
		setSQLCOmmand();
		batchQuery(in);
	}
	public static void batchQuery(Scanner in) {
		@SuppressWarnings("unused")
		String temp = "";
		String dbURL = SystemConstant.getDbURL();
		String user = SystemConstant.getUser();
		String password = SystemConstant.getPassword();
		path = "C:/專題下載檔案";
		File file = new File(path);
		if (!file.exists()) {
			file.mkdir();
		}
		try (
				Connection conn = DriverManager.getConnection(dbURL, user, password);
				PreparedStatement stmt = conn.prepareStatement(sql);
		) {
			System.out.print("請輸入想取出的圖片代碼：");
			stmt.setInt(1, Integer.valueOf(in.nextInt()));
			System.out.println("正在尋找圖片......");
			temp = in.nextLine();
			try(
					ResultSet rs = stmt.executeQuery();
					){
				if(rs.next()) {
					filename = path + "/" + rs.getString("檔名") + "." + rs.getString("副檔名");
					try(
							FileOutputStream fos = new FileOutputStream(filename);
							BufferedOutputStream bos = new BufferedOutputStream(fos);
							){
						bos.write(rs.getBytes("圖片"));
					}
				}
			}
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		}
		System.out.println("圖片成功取出來囉！");
	}
	private static void setSQLCOmmand() {
		// 新增一筆大專院校名錄紀錄
		sql = " SELECT * FROM [圖片] WHERE [代碼] = ?; ";
	}
}