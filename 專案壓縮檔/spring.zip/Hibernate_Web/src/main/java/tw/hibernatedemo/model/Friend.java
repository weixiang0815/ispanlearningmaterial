package tw.hibernatedemo.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "friends")
public class Friend {

	@Id
	@Column(name = "friends_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer friendId;
	
	@Column(name = "friendName")
	private String friendName;
	
	@ManyToMany(mappedBy = "friends")
	private Set<MyGroup> groups = new HashSet<>();
	
	public Friend() {
	}

	public Integer getFriendId() {
		return friendId;
	}

	public void setFriendId(Integer friendId) {
		this.friendId = friendId;
	}

	public String getFriendName() {
		return friendName;
	}

	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}

	public Set<MyGroup> getGroups() {
		return groups;
	}

	public void setGroups(Set<MyGroup> groups) {
		this.groups = groups;
	}

	@Override
	public String toString() {
		return "Friend [friendId=" + friendId + ", friendName=" + friendName + ", groups=" + groups.size() + "個團體]";
	}

}
