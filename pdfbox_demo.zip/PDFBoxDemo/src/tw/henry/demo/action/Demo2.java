package tw.henry.demo.action;

import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

public class Demo2 {

	public static void main(String[] args) {
		try (PDDocument doc = new PDDocument();) {
			for (int i = 0; i < 50; i++) {
				PDPage page = new PDPage();
				doc.addPage(page);
				System.out.println("產生第" + (i + 1) + "個新 PDF 頁面");
			}
			doc.save("C:/Users/Student/Desktop/demo.pdf");
			System.out.println("產生一個 PDF 檔");
			doc.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
