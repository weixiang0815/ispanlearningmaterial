package ch01;
/* 
   這是第一個Java程式
*/
public class HelloWorld {
    public static void main(String args[]) {
        System.out.println("Hello, Java world!") ;
    }
}
