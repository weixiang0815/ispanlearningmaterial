package tw.henry.demo.action;

import java.io.File;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.pdmodel.PDPage;

public class Demo7 {

	public static void main(String[] args) {
		File file = new File("C:/Users/Student/Desktop/Demo.pdf");
		try (PDDocument doc = PDDocument.load(file);) {
			PDPage page = new PDPage();
			doc.addPage(page);
			PDDocumentInformation pdd = doc.getDocumentInformation();
			pdd.setAuthor("setAuthor: 威翔");
			pdd.setTitle("setTitle: 用 PDFBox 練習印發票");
			pdd.setCreator("setCreator: 阿力");
			pdd.setSubject("setSubject: PDFBox Demo");
			GregorianCalendar gc = new GregorianCalendar();
			gc.set(2023, 1, 1);
			pdd.setCreationDate(gc);
			gc.setTime(new Date());
			pdd.setModificationDate(gc);
			pdd.setKeywords("setKeywords: Java, PDFBox, ISpan");
			pdd.setProducer("setProducer: EEIT157第三組");
			doc.save(file);
			System.out.println("新增許多檔案屬性");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
