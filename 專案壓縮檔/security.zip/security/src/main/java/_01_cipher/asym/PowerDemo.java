package _01_cipher.asym;

import java.math.BigInteger;

public class PowerDemo {

	public static void main(String[] args) {
		Double d1 = Math.pow(94, 28);
		System.out.println(d1);
		
		BigInteger b1 = BigInteger.valueOf(94);
		BigInteger b2 = b1.pow(28);
		System.out.println(b2);
	}
	
}