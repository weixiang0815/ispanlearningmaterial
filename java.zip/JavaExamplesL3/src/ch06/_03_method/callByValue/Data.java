package ch06._03_method.callByValue;

public class Data {
	int i;
	int j;
}
