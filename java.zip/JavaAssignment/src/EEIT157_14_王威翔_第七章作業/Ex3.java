package EEIT157_14_王威翔_第七章作業;

abstract class Human {
	int weight = 50;
	abstract void smile();
}
abstract class OrdinaryPeople extends Human {
}
class HappyMary extends OrdinaryPeople {
	void smile() {
		System.out.println("HA");
	};
}
public class Ex3 {
	public static void main(String[] args) {
		HappyMary hm = new HappyMary();
		hm.smile();
	}
}
