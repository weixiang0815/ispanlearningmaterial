package tw.henry.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

// 相當於 web.xml 的 Java 程式組態
public class WebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override // 用來註冊相當於 applicationContext.xml (beans.config.xml) 的 Java 程式組態
	protected Class<?>[] getRootConfigClasses() {
		return null;
	}

	@Override // 用來註冊相當於 mvc-servlet.xml 的 Java 程式組態
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] { WebAppConfig.class };
	}

	@Override // 設定 DispatcherServlet 的 url-pattern
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

}
