package ch03;

public class StringConcate {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		 String s1 = "123" ; 
		 String s2 = "xyz" ; 
		 String s3 = s1 + s2 ;  		// s3的內含值 "123xyz"

		 int x = 100 ; 
		 System.out.println("x=" + x) ;

		 double d = 3.14 ; 
		 System.out.println("d=" + d) ;


		 int a = 3  ; 
		 int b = 5  ; 
		 System.out.println("a*b=" + a * b) ;  



	}

}
