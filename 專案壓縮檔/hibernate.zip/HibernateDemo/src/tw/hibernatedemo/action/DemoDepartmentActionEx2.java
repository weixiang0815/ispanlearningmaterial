package tw.hibernatedemo.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import tw.hibernatedemo.model.Department;

public class DemoDepartmentActionEx2 {

	public static void main(String[] args) {
		try (StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
				SessionFactory factory = new MetadataSources(registry).buildMetadata().buildSessionFactory();
				Session session = factory.openSession();) {
			session.beginTransaction();
			Department dept2 = new Department("Tech");
			session.save(dept2);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
