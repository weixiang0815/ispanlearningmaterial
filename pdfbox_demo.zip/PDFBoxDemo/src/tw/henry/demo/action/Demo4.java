package tw.henry.demo.action;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

public class Demo4 {

	public static void main(String[] args) {
		File file = new File("C:/Users/Student/Desktop/Demo.pdf");
		try (PDDocument doc = PDDocument.load(file);) {
			PDPage page = doc.getPage(1);
			try (PDPageContentStream stream = new PDPageContentStream(doc, page);) {
				stream.beginText();
//				stream.setFont(PDType1Font.HELVETICA_BOLD, 16);
				stream.setFont(PDType0Font.load(doc, new File("C:/Windows/Fonts/kaiu.ttf")), 14);
				stream.setLeading(1.5f);
				stream.newLineAtOffset(25, 500);
				String text = "Hi!!! This is the multiple text content example.";
				String Line1 = "Here, we discussed about how to add text content in the pages of the PDF document.";
				String Line2 = "We do this by using the ShowText() method of the ContentStream class";
				stream.showText(text);
				stream.newLine();
				stream.showText(Line1);
				stream.newLine();
				stream.showText(Line2);
				stream.endText();
			}
			System.out.println("寫了好多行字");
			doc.save(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
