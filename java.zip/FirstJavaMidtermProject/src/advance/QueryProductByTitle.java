package advance;

public class QueryProductByTitle {
	public static void queryProductByKey(String title, String keyin) {
		try {
			ProductBean productBean = new ProductDaoImpl().findBytitle(title, keyin);
			if (productBean == null){
				System.out.println("查無此資料:"+title+" = " + keyin); 
			} else {
				System.out.println("查得資料: " +  productBean);
			}
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		}
		System.out.println("查詢記錄完畢");
	}
}