package advance;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class QueryOutputImg {
	public static void queryOutputFile(int[] ids, Scanner in) {
		String path = "C:/Users/Student/Desktop/專題下載檔案";
		File file = new File(path);
		if (!file.exists()) {
			file.mkdir();
		}
		String filename = path + "/查詢資料匯出檔" + ".csv";
		try (FileOutputStream fos = new FileOutputStream(filename, true);
				OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
				PrintWriter pw = new PrintWriter(osw);) {
			for (int i = 0; i < ids.length; i++) {
				StringBuffer str = new StringBuffer();
				ProductBean productBean = new ProductDaoImpl().findById(ids[i]);
				if (productBean == null) {
					System.out.println("查無此資料:Key = " + ids[i]);
					@SuppressWarnings("unused")
					String temp = in.nextLine();
				} else {
					System.out.println("查得資料: " + productBean);
					str.append(productBean.getId()+',');
					str.append(productBean.getSchoolName()+',');
					str.append(productBean.getPubOrPriv()+',');
					str.append(productBean.getRegion()+',');
					str.append(productBean.getAddress()+',');
					str.append(productBean.getPhone()+',');
					str.append(productBean.getUrl()+',');
					str.append(productBean.getSystem()+'\n');
					pw.write(str.toString());
				}
			}
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		}
		System.out.println("紀錄新增成功");
	}
}