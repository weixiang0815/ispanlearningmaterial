package com.tw.henry.controller.search;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Video;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/GetVideo.do")
public class GetVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String filepath = "C:/Users/henry/Desktop/Servlet/workspace/2ndMidterm_Test/src/main/webapp/video/";
		Video video = null;
		String unit = "bytes";
		int size = 0;
		String result;
		try {
			video = new VideoDao(ConnectionFactory.getConnection()).getVideoByID(id);
			size = video.getSize();
			if (size >= 1024) {
				size /= 1024;
				unit = "kb";
			}
			if (size >= 1024) {
				size /= 1024;
				unit = "mb";
			}
			if (size >= 1024) {
				size /= 1024;
				unit = "gb";
			}
			if (size >= 1024) {
				size /= 1024;
				unit = "tb";
			}
			if (size >= 1024) {
				size /= 1024;
				unit = "pb";
			}
			File file = new File(filepath);
			if (!file.exists()) {
				file.mkdir();
			}
			filepath += video.getFilename();
			try (FileOutputStream fos = new FileOutputStream(filepath);
					BufferedOutputStream bos = new BufferedOutputStream(fos);) {
				bos.write(video.getVideo());
			}
			result = "查詢成功";
		} catch (Exception e) {
			e.printStackTrace();
			result = "查詢失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("video", video);
		request.setAttribute("videoSize", size + " " + unit);
		request.setAttribute("filepath", "/video/" + video.getFilename());
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/search/GetVideo.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
