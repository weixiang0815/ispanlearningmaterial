package ch08._01;

public class Bar {
	public void divide() {
		System.out.println("Bar類別的divide()方法開始");
		int sum = 100;
		int no = 0;
		int average = sum / no;
		System.out.println("平均=" + average);
		System.out.println("Bar類別的divide()方法結束");
	}
}
