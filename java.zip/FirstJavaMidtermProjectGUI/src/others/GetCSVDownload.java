package others;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class GetCSVDownload {
	public static String getCSVDownload(String url) {

		// 大專院校名錄："https://stats.moe.gov.tw/files/school/110/u1_new.csv"
		String sURL = url;
		URL aURL;
		try {
			aURL = new URL(sURL);
			String fileName = sURL.substring(sURL.lastIndexOf("/") + 1);
			System.out.println("檔名:" + fileName);
			File file = new File("C:/Users/Student/Desktop/專題下載檔案");
			if(!file.exists()) {
				file.mkdir();
			}
			fileName = file.getAbsolutePath() + "/" + fileName;
			try (
					OutputStream fos = new FileOutputStream(fileName);
					InputStream is = aURL.openStream();
					) {
				fos.write(is.readAllBytes());
				return "檔案已經下載好囉！";
			} catch (IOException e) {
				return "檔案讀取有問題：" + e.getMessage();
			}
		} catch (MalformedURLException e) {
			return "網址有問題：" + e.getMessage();
		}
	}
}
