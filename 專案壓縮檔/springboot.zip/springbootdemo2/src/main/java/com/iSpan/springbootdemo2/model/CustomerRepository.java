package com.iSpan.springbootdemo2.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

//@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	@Query(value = "from Customer where name = ?1")
	public Customer findCustomerByName(String name);

	@Query(value = "from Customer where name = :name")
	public Customer findCustomerByName2(@Param("name") String name);

	// 模糊搜尋? like %%
//	@Query(value = "from Customer where name like concat('%', :name, '%')")	//	springboot 2.7 以前
	@Query(value = "from Customer where name like %:name%")
	public List<Customer> findCustomerLike(@Param("name") String name);
	// 透過 JavaScript 解決 URL encoding 問題

	@Query(value = "from Customer where level < :level")
	public List<Customer> findCustomerByLevel(@Param("level") int level);

	// 執行原生 SQL，非 HQL
	@Query(value = "select * from customer where name = :name", nativeQuery = true)
	public Customer findCustomerByNameNativeQuery(@Param("name") String name);

	@Transactional
	@Modifying
	@Query(value = "delete from customer where id = :id", nativeQuery = true)
	public void deleteAccount(@Param("id") Integer id);

	public List<Customer> findByLevelOrderByIdDesc(Integer id);

	public List<Customer> findByNameContaining(String name);

}