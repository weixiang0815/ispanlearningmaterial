package query;

import model.ProductBean;
import model.ProductDaoImpl;

public class QueryMultipleProductsById {
	public static String queryMultipleProductsById(int[] ids) {
		try {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < ids.length; i++) {
				ProductBean productBean = new ProductDaoImpl().findById(ids[i]);
				if (productBean == null) {
					sb.append("查無此資料:Key = " + ids[i] + '\n');
				} else {
					sb.append("查得資料: " + productBean + '\n');
				}
			}
			sb.append("多筆紀錄查詢完畢");
			return sb.toString();
		} catch (Exception ex) {
			return "查詢記錄時發生例外: " + ex.getMessage();
		}
	}
}