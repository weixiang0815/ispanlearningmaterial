package tw.com.henry.hw.init;

import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import tw.com.henry.hw.conn.ConnectionFactory;

@WebListener
public class Initialize implements ServletContextListener {

	private String realPath = "";

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		realPath = sce.getServletContext().getRealPath("");
		try (Connection conn = ConnectionFactory.getConnection()) {
			createDB(conn);
			initializeCreator(conn);
			initializeVideo(conn);
			initializeAdmin(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createDB(Connection conn) {
		String SQL = "IF DB_ID('Vimy') IS NULL CREATE DATABASE Vimy";
		try (Statement state = conn.createStatement();) {
			state.execute(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initializeCreator(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[Vimy].[dbo].[Creator]') IS NULL CREATE TABLE [Vimy].[dbo].[Creator]("
					+ "id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,"
					+ "name NVARCHAR(50) NOT NULL,"
					+ "account NVARCHAR(50) NOT NULL,"
					+ "password NVARCHAR(50) NOT NULL,"
					+ "thumbnail NVARCHAR(MAX),"
					+ "gender NVARCHAR(6) NOT NULL,"
					+ "birthdate DATE NOT NULL,"
					+ "uploadCount INT NOT NULL,"
					+ "country NVARCHAR(20) NOT NULL,"
					+ "info NVARCHAR(MAX),"
					+ "fb_account NVARCHAR(MAX),"
					+ "google_account NVARCHAR(MAX),"
					+ "twitter_account NVARCHAR(MAX),"
					+ "ig_account NVARCHAR(MAX)"
					+ ")";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();

		if (conn.createStatement().executeQuery("SELECT id FROM [Vimy].[dbo].[Creator]").next()) {
			return;
		}

//		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Creator.json"));
//		List<CreatorDao> CreatorList = null;
//		br.close();
//
//		SQL = "INSERT INTO [Vimy].[dbo].[Creator](id, account, password, level, photo) VALUES (?, ?, ?, ?, ?)";
//
//		PreparedStatement preState = conn.prepareStatement(SQL);
//		for (CreatorDao u : CreatorList) {
//			preState.setString(1, u.getId());
//			preState.setString(2, u.getAccount());
//			preState.setString(3, u.getPassword());
//			preState.setString(4, u.getLevel());
//			preState.setString(5, u.getPhoto());
//			preState.addBatch();
//		}
//		preState.executeBatch();
//		preState.close();
	}
	private void initializeAdmin(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[Vimy].[dbo].[Creator]') IS NULL CREATE TABLE [Vimy].[dbo].[Creator]("
				+ "id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,"
				+ "name NVARCHAR(50) NOT NULL,"
				+ "account NVARCHAR(50) NOT NULL,"
				+ "password NVARCHAR(50) NOT NULL,"
				+ "thumbnail NVARCHAR(MAX),"
				+ "gender NVARCHAR(6) NOT NULL,"
				+ "birthdate DATE NOT NULL,"
				+ "uploadCount INT NOT NULL,"
				+ "country NVARCHAR(20) NOT NULL,"
				+ "info NVARCHAR(MAX),"
				+ "fb_account NVARCHAR(MAX),"
				+ "google_account NVARCHAR(MAX),"
				+ "twitter_account NVARCHAR(MAX),"
				+ "ig_account NVARCHAR(MAX)"
				+ ")";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();
		
		if (conn.createStatement().executeQuery("SELECT id FROM [Vimy].[dbo].[Creator]").next()) {
			return;
		}
		
//		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Creator.json"));
//		List<CreatorDao> CreatorList = null;
//		br.close();
//
//		SQL = "INSERT INTO [Vimy].[dbo].[Creator](id, account, password, level, photo) VALUES (?, ?, ?, ?, ?)";
//
//		PreparedStatement preState = conn.prepareStatement(SQL);
//		for (CreatorDao u : CreatorList) {
//			preState.setString(1, u.getId());
//			preState.setString(2, u.getAccount());
//			preState.setString(3, u.getPassword());
//			preState.setString(4, u.getLevel());
//			preState.setString(5, u.getPhoto());
//			preState.addBatch();
//		}
//		preState.executeBatch();
//		preState.close();
	}

	private void initializeVideo(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[Vimy].[dbo].[Video]') IS NULL CREATE TABLE [Vimy].[dbo].[Video]("
					+ "id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,"
					+ "name NVARCHAR(50) NOT NULL,"
					+ "thumbnail NVARCHAR(50) NOT NULL,"
					+ "size INT NOT NULL,"
					+ "filepath NVARCHAR(MAX) NOT NULL,"
					+ "filetype NVARCHAR(10) NOT NULL,"
					+ "video VARBINARY(MAX) NOT NULL,"
					+ "info NVARCHAR(MAX) NOT NULL,"
					+ "creator int FOREIGN KEY REFERENCES [Vimy].[dbo].[Creator](id)"
					+ ")";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();

		if (conn.createStatement().executeQuery("SELECT id FROM [Vimy].[dbo].[Video]").next()) {
			return;
		}

//		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Video.json"));
//		List<VideoDao> VideoList = null;
//		br.close();
//
//		SQL = "INSERT INTO [Vimy].[dbo].[Video](nickName, type, age, photo, ownerID) VALUES (?, ?, ?, ?, ?)";
//		PreparedStatement preState = conn.prepareStatement(SQL);
//		for (VideoDao p : VideoList) {
//			BufferedInputStream bis = new BufferedInputStream(
//					new FileInputStream(realPath + "forInit/VideosIMG/" + p.getNickName() + ".jpg"));
//			byte[] bytes = bis.readAllBytes();
//			preState.setString(1, p.getNickName());
//			preState.setString(2, p.getType());
//			preState.setInt(3, p.getAge());
//			preState.setBytes(4, bytes);
//			preState.setString(5, p.getOwnerID());
//			preState.addBatch();
//			bis.close();
//		}
//		preState.executeBatch();
//		preState.close();
	}
}
