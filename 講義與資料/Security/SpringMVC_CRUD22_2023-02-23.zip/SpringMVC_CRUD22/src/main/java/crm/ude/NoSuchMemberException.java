package crm.ude;

@SuppressWarnings("serial")
public class NoSuchMemberException extends RuntimeException {
	private Integer id;
	
	public NoSuchMemberException() {
	}

	public NoSuchMemberException(String message) {
		super(message);
	}

	public NoSuchMemberException(Throwable cause) {
		super(cause);
	}

	public NoSuchMemberException(String message, Throwable cause) {
		super(message, cause);
	}

	public NoSuchMemberException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NoSuchMemberException(int id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

}
