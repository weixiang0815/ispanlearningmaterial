package yoan;

public class Ex1 {

	public static void main(String[] args) {
		String str = new String();
		char c = 'a';
		for (int i = 1; i <= 26; i ++) {
			str += (char)(c + (i - 1));
			if (i < 26) {
				str += ",";
			}
		}
		System.out.println(str);
		String[] arr = str.split(",");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i] + "1");
		}
	}

}
