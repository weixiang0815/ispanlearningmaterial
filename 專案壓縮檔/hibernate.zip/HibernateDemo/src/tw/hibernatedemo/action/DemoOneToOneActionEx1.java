package tw.hibernatedemo.action;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tw.hibernatedemo.model.Instructor;
import tw.hibernatedemo.model.InstructorDetail;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoOneToOneActionEx1 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			Instructor ins1 = new Instructor();
			ins1.setName("Jerry");
			
			InstructorDetail detail = new InstructorDetail();
			detail.setEmail("henry940129@gmail.com");
			detail.setPhone("0900000000");
			
			ins1.setInstructorDetail(detail);
			
			session.save(ins1);
			System.out.println("新增成功");
			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
