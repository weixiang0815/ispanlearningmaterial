package img;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import system.SystemConstant;
import system.SystemUtils;

public class InsertImg {
	private static String insertImgString = "";
	private static String filename = "";
	// C:/Users/Student/Desktop/專題下載檔案/u1_new.csv
	public static void insertImg(Scanner in) {
		setSQLCOmmand();
		batchInsert(in);
	}

	private static void batchInsert(Scanner in) {
		System.out.print("請輸入圖檔位址：");
		filename = in.nextLine().trim();
		try (Connection conn = DriverManager.getConnection(
				SystemConstant.getDbURL(), 
				SystemConstant.getUser(),
				SystemConstant.getPassword()); 
			PreparedStatement stmt = conn.prepareStatement(insertImgString);
			BufferedInputStream bis = new BufferedInputStream(
							new FileInputStream(filename));	
		) {
			System.out.println("現在開始新增圖檔......");
			String imgFullName = SystemUtils.extractFilename(filename);
			String imgName = imgFullName.substring(0, imgFullName.lastIndexOf("."));
			String imgType = imgFullName.substring(imgFullName.lastIndexOf(".")+1);
			stmt.setString(1, imgName);
			Blob blob = SystemUtils.fileToBlob(bis);
			stmt.setBlob(2, blob);
			stmt.setString(3, imgType);
			stmt.executeUpdate();
			System.out.println("圖檔新增成功");
		} catch (SQLException e) {
			System.err.print("存取資料庫時發生例外: " + e);
			e.printStackTrace();
		} catch (IOException e) {
			System.err.print("IO時發生例外: " + e);
			e.printStackTrace();
		}
	}

	private static void setSQLCOmmand() {
		// 新增一筆大專院校名錄紀錄
		insertImgString = " insert into [圖片] " 
						+ " (檔名, 圖片, 副檔名) "
						+ " values (?, ?, ?); ";
	}
}
