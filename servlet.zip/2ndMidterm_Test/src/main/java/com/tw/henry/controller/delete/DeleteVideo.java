package com.tw.henry.controller.delete;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/DeleteVideo.do")
public class DeleteVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String videoId = request.getParameter("videoId");
		String result;
		try {
			VideoDao videoDao = new VideoDao(ConnectionFactory.getConnection());
			String creatorId = videoDao.getVideoByID(videoId).getCreatorId();
			result = videoDao.deleteVideoByID(videoId, creatorId);
		} catch (Exception e) {
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/delete/DeleteVideo.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
