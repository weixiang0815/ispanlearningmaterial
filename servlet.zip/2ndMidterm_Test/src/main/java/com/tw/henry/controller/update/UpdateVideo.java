package com.tw.henry.controller.update;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Video;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/UpdateVideo.do")
@MultipartConfig
public class UpdateVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String filepath = "C:/Users/henry/Desktop/video/";
		String result;
		Video video;
		VideoDao videoDao;
		try {
			video = new Video();
			videoDao = new VideoDao(ConnectionFactory.getConnection());
			video.setId(request.getParameter("id"));
			video.setName(request.getParameter("name"));
			if (request.getParameter("thumbnail_update") == null) {
				video.setThumbnail(videoDao.getVideoByID(video.getId()).getThumbnail());
			} else {
				video.setThumbnail(request.getPart("thumbnail_update").getInputStream().readAllBytes());
			}
			if (request.getParameter("video_update") == null) {
				Video vid_temp = videoDao.getVideoByID(video.getId());
				video.setVideo(vid_temp.getVideo());
				video.setFilename(vid_temp.getFilename());
				video.setFiletype(vid_temp.getFiletype());
			} else {
				video.setVideo(request.getPart("video_update").getInputStream().readAllBytes());
				video.setFilename(request.getParameter("filename"));
				video.setFiletype(request.getParameter("filetype"));
			}
			filepath += video.getFilename();
			video.setInfo(request.getParameter("info"));
			video.setCreatorId(request.getParameter("creatorId"));
			video.setCreatorName(request.getParameter("creatorName"));
			result = videoDao.updateVideoById(video);
			request.setAttribute("video", video);			
		} catch (Exception e) {
			e.printStackTrace();
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("filepath", filepath);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/update/UpdateVideo.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
