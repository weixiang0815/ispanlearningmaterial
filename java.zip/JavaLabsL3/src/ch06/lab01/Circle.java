package ch06.lab01;

public class Circle {
	public double radius = 10; 

	public double getArea() {
		return radius * radius * Math.PI;
	}

}
