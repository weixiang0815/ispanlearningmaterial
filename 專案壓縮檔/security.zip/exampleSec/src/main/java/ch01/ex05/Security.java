package ch01.ex05;

public class Security {

}
