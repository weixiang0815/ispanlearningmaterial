package com.iSpan.springbootdemo2.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "house")
public class House {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "house_name")
	private String houseName;

	@JsonManagedReference // 由這邊控管序列化
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "house")
	private List<HousePhoto> housePhoto = new ArrayList<>();

	public House() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHouseName() {
		return houseName;
	}

	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}

	public List<HousePhoto> getHousePhoto() {
		return housePhoto;
	}

	public void setHousePhoto(List<HousePhoto> housePhoto) {
		this.housePhoto = housePhoto;
	}

}