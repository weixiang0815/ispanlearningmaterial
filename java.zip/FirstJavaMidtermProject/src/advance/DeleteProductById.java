package advance;

import java.sql.SQLException;

import sqlActions.ProductNotFoundException;

public class DeleteProductById {
	public static void deleteProductById(int key) {
		ProductDao productDao = new ProductDaoImpl();
		try {
			productDao.deleteById(key);
			System.out.println("刪除記錄:Key=" + key + "成功");
		} catch (ProductNotFoundException e) {
			e.setProductID(key);
			System.err.println("紀錄不存在，無法刪除:Key=" + e.getProductID());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
