package com.tw.henry.init;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.dao.CreatorDao;

@WebListener
public class Initialize implements ServletContextListener {

	private String realPath = "";

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		realPath = sce.getServletContext().getRealPath("");
		try (Connection conn = ConnectionFactory.getConnection()) {
			createDB(conn);
			initializeCreator(conn);
			initializeVideo(conn);
			initializeAdmin(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createDB(Connection conn) {
		String SQL = "IF DB_ID('servdb') IS NULL CREATE DATABASE servdb";
		try (Statement state = conn.createStatement();) {
			state.execute(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initializeCreator(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[servdb].[dbo].[Creator]') IS NULL CREATE TABLE [servdb].[dbo].[Creator]("
					+ "id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,"
					+ "name NVARCHAR(50) NOT NULL,"
					+ "account NVARCHAR(50) NOT NULL,"
					+ "password NVARCHAR(50) NOT NULL,"
					+ "thumbnail VARBINARY(MAX),"
					+ "gender NVARCHAR(6) NOT NULL,"
					+ "birthday DATE NOT NULL,"
					+ "uploadCount INT NOT NULL,"
					+ "country NVARCHAR(20) NOT NULL,"
					+ "info NVARCHAR(MAX),"
					+ "fb_account NVARCHAR(MAX),"
					+ "google_account NVARCHAR(MAX),"
					+ "twitter_account NVARCHAR(MAX),"
					+ "ig_account NVARCHAR(MAX)"
					+ ")";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();

		if (conn.createStatement().executeQuery("SELECT id FROM [servdb].[dbo].[Creator]").next()) {
			return;
		}

//		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Creator.json"));
//		List<CreatorDao> CreatorList = null;
//		br.close();
//
//		SQL = "INSERT INTO [servdb].[dbo].[Creator](id, account, password, level, photo) VALUES (?, ?, ?, ?, ?)";
//
//		PreparedStatement preState = conn.prepareStatement(SQL);
//		for (CreatorDao u : CreatorList) {
//			preState.setString(1, u.getId());
//			preState.setString(2, u.getAccount());
//			preState.setString(3, u.getPassword());
//			preState.setString(4, u.getLevel());
//			preState.setString(5, u.getPhoto());
//			preState.addBatch();
//		}
//		preState.executeBatch();
//		preState.close();
	}
	
	private void initializeAdmin(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[servdb].[dbo].[Admin]') IS NULL CREATE TABLE [servdb].[dbo].[Admin]("
				+ "id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,"
				+ "name NVARCHAR(50) NOT NULL,"
				+ "account NVARCHAR(50) NOT NULL,"
				+ "password NVARCHAR(50) NOT NULL,"
				+ ")";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();
		
		if (conn.createStatement().executeQuery("SELECT id FROM [servdb].[dbo].[Admin]").next()) {
			return;
		}
		
//		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Creator.json"));
//		List<CreatorDao> CreatorList = null;
//		br.close();
//
		SQL = "INSERT INTO [servdb].[dbo].[Admin](name, account, password) VALUES (?, ?, ?)";

		PreparedStatement stmt = conn.prepareStatement(SQL);
		stmt.setString(1, "Admin_Wang");
		stmt.setString(2, "weixiang_w");
		stmt.setString(3, "1234");
		stmt.executeUpdate();
		stmt.close();
	}

	private void initializeVideo(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[servdb].[dbo].[Video]') IS NULL CREATE TABLE [servdb].[dbo].[Video]("
					+ "id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,"
					+ "name NVARCHAR(50) NOT NULL,"
					+ "thumbnail VARBINARY(MAX) NOT NULL,"
					+ "size INT NOT NULL,"
					+ "filename NVARCHAR(50) NOT NULL,"
					+ "filetype NVARCHAR(10) NOT NULL,"
					+ "video VARBINARY(MAX) NOT NULL,"
					+ "info NVARCHAR(MAX) NOT NULL,"
					+ "creator INT FOREIGN KEY REFERENCES [servdb].[dbo].[Creator](id)"
					+ ")";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();

		if (conn.createStatement().executeQuery("SELECT id FROM [servdb].[dbo].[Video]").next()) {
			return;
		}

//		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Video.json"));
//		List<VideoDao> VideoList = null;
//		br.close();
//
//		SQL = "INSERT INTO [servdb].[dbo].[Video](nickName, type, age, photo, ownerID) VALUES (?, ?, ?, ?, ?)";
//		PreparedStatement preState = conn.prepareStatement(SQL);
//		for (VideoDao p : VideoList) {
//			BufferedInputStream bis = new BufferedInputStream(
//					new FileInputStream(realPath + "forInit/VideosIMG/" + p.getNickName() + ".jpg"));
//			byte[] bytes = bis.readAllBytes();
//			preState.setString(1, p.getNickName());
//			preState.setString(2, p.getType());
//			preState.setInt(3, p.getAge());
//			preState.setBytes(4, bytes);
//			preState.setString(5, p.getOwnerID());
//			preState.addBatch();
//			bis.close();
//		}
//		preState.executeBatch();
//		preState.close();
	}
}
