package advance;

import java.util.List;

import dao.ProductDao;
import dao.ProductDaoImpl;
import model.ProductBean;

// 呼叫 mssql.ex00.dao.impl.ProductDaoImpl類別的findAll()方法來取得所有的產品資料
// 你需要完成本類別與mssql.ex00.dao.impl.ProductDaoImpl.findAll()方法

public class QueryAllProducts {
	public static void queryAllProducts() {
		try  {
			System.out.println("現在查詢所有紀錄......");
			ProductDao productDao = new ProductDaoImpl();
			List<ProductBean> beans = productDao.findAll();
			System.out.println("查到的紀錄有"+beans.size()+"筆\n");
			for (int i = 0; i < beans.size(); i ++) {
				System.out.println(i+1+".");
				System.out.println(beans.get(i));
				System.out.println();
			}
			System.out.println("所有紀錄查詢完畢");
			
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生: " + ex.getMessage());
		} 
	}
}