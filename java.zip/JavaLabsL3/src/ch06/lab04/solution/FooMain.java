package ch06.lab04.solution;

public class FooMain {
	public static void main(String[] args) {
		Foo foo = new Foo();
		foo.greeting();
	}
}
