package ch02.lab02;

// 練習目的：Java原始程式檔的命名規定
// 本程式檔的檔案名稱為ProgramCh02Lab02.java
// 解題前先取消下面的注解
/*
public class Ch02  {
	public static void main(String[] args) {
		System.out.println("請更正此程式(Ch02Lab02)含有的錯誤");
	}
}
*/
