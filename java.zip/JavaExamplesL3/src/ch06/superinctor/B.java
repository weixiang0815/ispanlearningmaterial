package ch06.superinctor;

public class B extends A {
	int y = (int)(Math.random() * 100) + 100 + x;

	public B(int y) {
		super();
		this.y = y;
	}
	
	public B() {
		super();
	}
}
