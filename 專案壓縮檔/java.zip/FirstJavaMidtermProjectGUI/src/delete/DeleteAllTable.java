package delete;

import java.sql.SQLException;

import model.ProductDao;
import model.ProductDaoImpl;

public class DeleteAllTable {
	public static String deleteAllTable() {
		ProductDao productDao = new ProductDaoImpl();
		try {
			productDao.deleteAll();
			System.out.println("所有紀錄刪除成功");
			return "所有紀錄刪除成功";
		} catch (SQLException e) {
			return "刪除紀錄出現問題：" + e.getMessage();
		}
	}
}
