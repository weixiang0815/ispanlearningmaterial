package com.tw.henry.model.bean;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.Serializable;
import java.util.Base64;
import java.util.HashMap;

public class Creator implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String name;
	private String account;
	private String password;
	private String thumbnail;
	private String gender;
	private String birthday;
	private String uploadCount;
	private String country;
	private String info;
	private HashMap<String, String> socialAccount;

	public Creator() {
		setUploadCount("0");
		setInfo("");
		socialAccount = new HashMap<>();
		socialAccount.put("Facebook", "");
		socialAccount.put("Google", "");
		socialAccount.put("Twitter", "");
		socialAccount.put("Instagram", "");
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(byte[] pic) {
		thumbnail = "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(pic);
	}
	
	public void setThumbnail(String filepath) {
		try (
				FileInputStream fis = new FileInputStream(filepath);
				BufferedInputStream bis = new BufferedInputStream(fis);
				) {
			thumbnail = "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bis.readAllBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getUploadCount() {
		return uploadCount;
	}

	public void setUploadCount(String uploadCount) {
		this.uploadCount = uploadCount;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public HashMap<String, String> getSocialAccount() {
		return socialAccount;
	}
	
	public void setOneSocialAccount(String platform, String account) {
		socialAccount.put(platform, account);
	}

	public void setAllSocialAccount(HashMap<String, String> socialAccount) {
		this.socialAccount.putAll(socialAccount);
	}

	@Override
	public String toString() {
		StringBuffer str = new StringBuffer("創作者：\n");
		str.append("編號：" + id + "\n");
		str.append("名稱：" + name + "\n");
		str.append("帳號：" + account + "\n");
		str.append("密碼：" + password + "\n");
		str.append("性別：" + gender + "\n");
		str.append("生日：" + birthday + "\n");
		str.append("上傳作品數：" + uploadCount + "\n");
		str.append("國籍：" + country + "\n");
		str.append("簡介：" + info + "\n");
		for (String platform : socialAccount.keySet()) {
			str.append(platform + "帳號：" + socialAccount.get(platform) + "\n");
		}
		return str.toString();
	}

}
