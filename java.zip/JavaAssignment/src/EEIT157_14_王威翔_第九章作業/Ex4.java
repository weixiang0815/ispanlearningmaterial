package EEIT157_14_王威翔_第九章作業;

import java.util.Arrays;

public class Ex4 {

	public static void main(String[] args) {
		String[] names = {"張君雅", "潘美雪", "劉雪莉", "黃彬彬", "潘美雪", "黃美華", "劉雪麗",
				"黃彬彬", "潘美雪", "潘美雪"};
		Arrays.sort(names);
		for(String name : names)
			System.out.println(name);
	}

}
