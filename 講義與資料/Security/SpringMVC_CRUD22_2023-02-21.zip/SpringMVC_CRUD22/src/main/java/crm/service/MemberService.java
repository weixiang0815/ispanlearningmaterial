package crm.service;

import java.util.List;
import org.springframework.stereotype.Repository;
import crm.model.Member;

@Repository
public interface MemberService {
	void save(Member member);

	void deleteById(Integer id);

	Member findById(Integer id);

	void update(Member member);

	List<Member> findAll();

}
