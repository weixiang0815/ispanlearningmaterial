package tw.pers.mid.action;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import tw.pers.mid.bean.Users;
import tw.pers.mid.conn.ConnctionFactory;
import tw.pers.mid.dao.UsersDAO;

public class Action {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		while (true) {

			System.out.println("請選擇功能：");
			System.out.println("(1)根據ID查詢資料");
			System.out.println("(2)查詢所有資料");
			System.out.println("(3)姓名的模糊搜尋");
			int functionNum = scan.nextInt();

			if (functionNum == 1) {
				System.out.println("請輸入使用者ID：");
				createConnectionThenSearchAndPrintUsersByID(scan.nextInt());
			}
			if (functionNum == 2) {
				createConnectionThenSearchAllUsers();
			}
			if (functionNum == 3) {
				System.out.println("請輸入使用者姓名：");
				createConnectionThenSearchUsersByNameWithKeyword(scan.next());
			}

			if (functionNum == 0) {
				System.out.println("離開程式");
				break;
			}

		}
		scan.close();
	}

	private static void createConnectionThenSearchAndPrintUsersByID(int id) {
		try {
			Connection conn = ConnctionFactory.getConnectionToSQLServer();
			UsersDAO uDAO = new UsersDAO(conn);
			Users u = uDAO.getOneUserByID(id);
			System.out.println(u);
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void createConnectionThenSearchAllUsers() {
		try {
			Connection conn = ConnctionFactory.getConnectionToSQLServer();
			UsersDAO uDAO = new UsersDAO(conn);
			List<Users> uList = uDAO.getAllUsers();
			System.out.println(uList.toString());
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private static void createConnectionThenSearchUsersByNameWithKeyword(String keyword) {
		try {
			Connection conn = ConnctionFactory.getConnectionToSQLServer();
			UsersDAO uDAO = new UsersDAO(conn);
			List<Users> uList = uDAO.getUsersByNameWithKeyword(keyword);
			System.out.println(uList.toString());
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
