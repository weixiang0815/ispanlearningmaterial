package tw.hibernatedemo.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import tw.hibernatedemo.model.Employee;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoHQLAction {

	public void hqlSelectAll() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			Query<Employee> query1 = session.createQuery("FROM Employee", Employee.class);
			
//			query1.list();	// 舊版
			List<Employee> result = query1.getResultList();
			
			result.forEach(emp -> System.out.println(emp.toString()));
			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}
	
	public void hqlSelectBySalaryAndVacation(Integer salary, Integer vacation) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			Query<Employee> query1 = session.createQuery(
					"FROM Employee e WHERE e.salary > :ss AND e.vacation > :vv",
					Employee.class)
					.setParameter("ss", salary)
					.setParameter("vv", vacation)
					.setFirstResult(1)
					.setMaxResults(4);
			
//			query1.list();	// 舊版
			List<Employee> result = query1.getResultList();
			
			result.forEach(emp -> System.out.println(emp.toString()));
			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}
	
	public void hqlUpdateSalaryByName(Integer salary, String name) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			session.createQuery("UPDATE Employee e SET e.salary = :ss WHERE e.name = :name")
					.setParameter("ss", salary)
					.setParameter("name", name)
					.executeUpdate();
			
			session.getTransaction().commit();
			System.out.println("更新成功");
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}
	
	public void hqlSelectByName(String name) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();
			
			Query<Employee> query1 = session.createQuery(
					"FROM Employee e WHERE e.name LIKE :pName",
					Employee.class)
					.setParameter("pName", "%" + name + "%");
			
			List<Employee> result = query1.getResultList();
			
			result.forEach(emp -> System.out.println(emp.toString()));
			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}
	
	public static void main(String[] args) {
		DemoHQLAction demoHql = new DemoHQLAction();
//		demoHql.hqlSelectAll();
//		demoHql.hqlSelectBySalaryAndVacation(20000, 5);
//		demoHql.hqlUpdateSalaryByName(30000, "John");
		demoHql.hqlSelectByName("o");
	}

}
