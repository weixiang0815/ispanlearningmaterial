package others;

import java.net.URI;

public class openWebPage {
	public static void main(String[] args) {

		try {

			URI uri = new URI("http://www.instanceofjava.com");

			java.awt.Desktop.getDesktop().browse(uri);
			System.out.println("Web page opened in browser");

		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}
