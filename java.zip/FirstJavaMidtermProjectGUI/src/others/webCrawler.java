package others;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class webCrawler {

	public static Elements crawl(String keyword, int i) {
		Elements imgs = null;
		try {
			String url_prefix = "https://www.google.com.tw/search?q=";
			String url_suffix = "&source=lnms&tbm=isch";
//			System.out.print("請輸入想搜尋的圖片關鍵字：");
			keyword = url_prefix + keyword.trim() + url_suffix;
			Document doc = Jsoup.connect(keyword).userAgent("Mozilla/5.0").referrer("https://www.google.com")
					.timeout(1000).followRedirects(true).get();
			imgs = doc.select("img");
//			System.out.print("請問你想爬幾張照片（最多20張）：");
//			int i = in.nextInt();
//			if(i > 20) {
//				System.out.println("很抱歉，一次最多只能爬前20張");
//			}
//			int j = 0;
//			File file = new File("C:/Users/Student/Desktop/爬下來的照片");
//			if (!file.exists()) {
//				file.mkdir();
//			}
//			for (Element img : imgs) {
//				if (j + 1 > i)
//					break;
//				if (!img.attr("src").contains("https:"))
//					continue;
//				URL img_url = new URL(img.attr("src"));
//				String img_name = j + 1 + ".jpg";
//				try (
//						FileOutputStream fos = new FileOutputStream(file.getAbsoluteFile() + "/" + img_name);
//						BufferedOutputStream bos = new BufferedOutputStream(fos);
//				) {
//					bos.write(img_url.openStream().readAllBytes());
//				}
//				j++;
//				System.out.println("印好了第" + j + "張圖");
//			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return imgs;
//		System.out.println("結束爬蟲");
	}

}
