package com.tw.henry.model.bean;

import java.io.Serializable;

public class Admin implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String name;
	private String account;
	private String password;

	public Admin() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		StringBuffer str = new StringBuffer("管理員：\n");
		str.append("編號：" + id + "\n");
		str.append("名稱：" + name + "\n");
		str.append("帳號：" + account + "\n");
		str.append("密碼：" + password + "\n");
		return str.toString();
	}

}
