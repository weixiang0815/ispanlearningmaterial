package crm.service;

import java.util.List;

import crm.model.Category;

public interface CategoryService {
	List<Category> findAll();

	Category findById(Integer id);
}
