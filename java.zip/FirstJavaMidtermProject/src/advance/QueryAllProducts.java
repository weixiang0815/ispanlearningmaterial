package advance;

import java.util.List;


public class QueryAllProducts {
	public static void queryAllProducts() {
		try  {
			System.out.println("現在查詢所有紀錄......");
			ProductDao productDao = new ProductDaoImpl();
			List<ProductBean> beans = productDao.findAll();
			System.out.println("查到的紀錄有"+beans.size()+"筆\n");
			for (int i = 0; i < beans.size(); i ++) {
				System.out.println(i+1+".");
				System.out.println(beans.get(i));
				System.out.println();
			}
			System.out.println("所有紀錄查詢完畢");
			
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生: " + ex.getMessage());
		} 
	}
}