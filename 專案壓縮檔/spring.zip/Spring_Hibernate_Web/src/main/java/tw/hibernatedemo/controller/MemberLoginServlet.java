package tw.hibernatedemo.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import tw.hibernatedemo.model.Member;
import tw.hibernatedemo.service.MemberService;

@WebServlet("/MemberLoginServlet.do")
public class MemberLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		Map<String, String> errorMsgMap = new HashMap<>();

		request.setAttribute("errorMsgMap", errorMsgMap);

		HttpSession httpSession = request.getSession();

		// 抓到 request parameter
		String loginName = request.getParameter("uname");
		String loginPwd = request.getParameter("psw");

		// 給 Service 驗證
//		Member member = new MemberService().checkLogin(loginName, loginPwd);
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		MemberService mService = context.getBean("memberService", MemberService.class);
		Member member = mService.checkLogin(loginName, loginPwd);

		if (member != null) {
			// 有找到 Member，把登入者加到 Session，回傳成功頁面，顯示登入者 memberName
			httpSession.setAttribute("memberName", member.getMemberName());
		} else {
			// 沒有的話，存錯誤訊息到 Map
			errorMsgMap.put("LoginError", "帳號密碼錯誤，請重新輸入");
		}

		// 沒有的話，跳回 login.jsp，印出錯誤訊息
		if (errorMsgMap.isEmpty()) {
			request.getRequestDispatcher("/page/login_success.jsp").forward(request, response);
		} else {
			request.getRequestDispatcher("/page/login.jsp").forward(request, response);
		}
	}

}
