package ch06._04_constructor.callOtherCtor;

public class EmployeeOCMain {
	public static void main(String args[]) {
		EmployeeOC tom = new EmployeeOC("Tom", 45);
		tom.printData();
	}
}
