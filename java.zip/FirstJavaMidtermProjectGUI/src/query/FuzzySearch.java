package query;

import java.util.List;
import model.ProductBean;
import model.ProductDaoImpl;

public class FuzzySearch {
	public static String fuzzySearch(String keyword) {
		try {
			StringBuffer sb = new StringBuffer();
			String[] titles = { "代碼", "學校名稱", "[公/私立]", "縣市名稱", "地址", "電話", "網址", "體系別" };
			List<ProductBean> resultBean = new ProductDaoImpl().fuzzySearch(titles[0], keyword);
			for (int i = 1; i < titles.length; i++) {
				List<ProductBean> tempBean = new ProductDaoImpl().fuzzySearch(titles[i], keyword);
				if (tempBean.size() > resultBean.size()) {
					resultBean.clear();
					resultBean.addAll(tempBean);
				}
			}
			if (resultBean.size() == 0) {
				sb.append("我輕輕地來，帶不回一條結果～\n");
				sb.append("查到" + resultBean.size() + "條結果");
			} else {
				if (resultBean.size() == 1) {
					sb.append("萬中選一的結果被我找到啦！\n");
				} else {
					sb.append("手上好多東西呀！快拿不動啦！\n");
				}
				sb.append("查到" + resultBean.size() + "條結果\n");
				System.out.println("查到" + resultBean.size() + "條結果");
				resultBean.forEach(n -> sb.append(n + "\n"));
			}
			sb.append("結束模糊搜尋");
			return sb.toString();
		} catch (Exception ex) {
			return "查詢記錄時發生例外: " + ex.getMessage();
		}
	}
}