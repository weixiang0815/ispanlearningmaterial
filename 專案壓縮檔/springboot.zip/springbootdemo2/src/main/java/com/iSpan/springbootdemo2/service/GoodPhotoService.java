package com.iSpan.springbootdemo2.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iSpan.springbootdemo2.model.GoodPhoto;
import com.iSpan.springbootdemo2.model.GoodPhotoRepository;

@Service
@Transactional
public class GoodPhotoService {

	@Autowired
	private GoodPhotoRepository gDao;

	public GoodPhoto insertPhoto(GoodPhoto gp) {
		return gDao.save(gp);
	}

	public List<GoodPhoto> findAllPhoto() {
		return gDao.findAll();
	}

	public GoodPhoto getPhotoById(Integer id) {
		Optional<GoodPhoto> optional = gDao.findById(id);
		return optional.isPresent() ? optional.get() : null;
	}

}