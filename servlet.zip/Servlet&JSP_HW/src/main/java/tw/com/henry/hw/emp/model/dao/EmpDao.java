package tw.com.henry.hw.emp.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import tw.com.henry.hw.emp.model.bean.EmpBean;

public class EmpDao {

	private Connection conn;

	public EmpDao(Connection conn) {
		this.conn = conn;
	}

	public EmpBean getUsersByID(String userID) throws SQLException {
		String SQL = "SELECT * FROM Users WHERE id =?";
		PreparedStatement preState = conn.prepareStatement(SQL);
		preState.setString(1, userID);
		ResultSet rs = preState.executeQuery();

		if (rs.next()) {
			EmpBean emp = new EmpBean();
			emp.setEmpno(rs.getString("empno"));
			emp.setEname(rs.getString("ename"));
			emp.setHiredate(rs.getString("hiredate"));
			emp.setSalary(rs.getString("salary"));
			emp.setDeptno(rs.getString("deptno"));
			emp.setTitle(rs.getString("title"));
			return emp;
		}

		preState.close();
		return null;
	}

}
