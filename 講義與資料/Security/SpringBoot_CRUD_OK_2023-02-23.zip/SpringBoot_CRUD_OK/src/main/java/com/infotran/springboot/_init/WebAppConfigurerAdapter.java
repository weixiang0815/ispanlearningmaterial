package com.infotran.springboot._init;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebAppConfigurerAdapter implements WebMvcConfigurer {

//	@Bean
//	public LocaleResolver localeResolver() {
//	   SessionLocaleResolver sessionLocaleResolver = new SessionLocaleResolver();
//	   sessionLocaleResolver.setDefaultLocale(Locale.TAIWAN);
//	   return sessionLocaleResolver;
//	}
//	@Bean
//	public LocaleChangeInterceptor localeChangeInterceptor() {
//	    LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
//	    lci.setParamName("lang");
//	    return lci;
//	}
//	@Override
//	public void addInterceptors(InterceptorRegistry registry) {
//	    registry.addInterceptor(localeChangeInterceptor());
//	}

	
}
