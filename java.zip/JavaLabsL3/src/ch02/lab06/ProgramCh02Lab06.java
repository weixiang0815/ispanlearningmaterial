package ch02.lab06;

//練習目的：了解如何定義浮點數(double, float)型態的變數

public class ProgramCh02Lab06 {
    public static void main(String[] args) {
        // 定義一個浮點數(double)型態的變數 d1, 初值為 3.14;
         double d1 = 3.14;
        // 定義一個浮點數(float)型態的變數 f1, 初值為 0.05;
         float f1 = 0.05f;
         System.out.println("d1 = " + d1);
         System.out.println("f1 = " + f1);
    }
}
