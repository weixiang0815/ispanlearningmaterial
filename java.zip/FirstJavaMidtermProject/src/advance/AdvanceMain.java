package advance;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AdvanceMain {

	public static void main(String[] args) throws IOException {
		printMenu();
		try (Scanner in = new Scanner(System.in)) {
			while (true) {
				System.out.print("請輸入功能代號：");
				String input = in.nextLine().trim();
				if (input.equalsIgnoreCase("q")) {
					System.out.println("感謝使用❤❤❤");
					break;
				}
				switch (input) {
				case "1": // 下載資料 (√)
					getDownload(in);
					break;
				case "2": // 建立新資料庫 (√)
					CreateCSVTable.createCSVTable();
					break;
				case "3": // 檔案存入資料庫 (√)
					InsertAllTable.insertAllTable();
					break;
				case "4": // 讀取所有資料 (√)
					QueryAllProducts.queryAllProducts();
					break;
				case "5": // 讀取指定資料 (√)
					queryProduct(in);
					break;
				case "6": // 讀取指定資料並建立檔案 (√)
					queryOutput(in);
					break;
				case "7": // 依特定欄位搜尋資料 (√ ?)
					queryByTitle(in);
					break;
				case "8": // 刪除指定資料 (√)
					deleteById(in);
					break;
				case "9": // 刪除所有資料 (√)
					DeleteAllTable.deleteAllTable();
					break;
				case "10": // 新增單筆資料 (√)
					insertOneItem(in);
					break;
				case "11": // 修改單筆資料 (√)
					updateOneItem(in);
					break;
				case "12": // 圖片存入資料庫 (√)
					insertImg(in);
					break;
				case "13": // 讀取圖片並建立檔案 (√)
					QueryOutputImg.insertImg(in);
					break;
				case "14": // 顯示功能選單 (√)
					printMenu();
					break;
				default: // 亂打一通 (√)
					System.out.println("無效指令，請重新輸入");
					break;
				}
				System.out.println("==============================================");
			}
		}
		System.out.println("程式已結束");
	}

	// 下載資料
	public static void getDownload(Scanner in) throws IOException {
		System.out.print("請問下載的是JSON還是CSV（JSON選1，CSV選2）：");
		String input = in.nextLine().trim();
		String url = null;
		switch (input) {
		case "1":
			System.out.println("不好意思，目前還不支援JSON格式喔！");
			break;
		case "2":
			System.out.print("請輸入下載檔案的網址：");
			url = in.nextLine().trim();
			GetCSVDownload.getCSVDownload(url);
			break;
		default:
			System.out.println("無效指令，已退回主選單");
			break;
		}
	}

	// 讀取指定資料
	public static void queryProduct(Scanner in) {
		try {
			System.out.print("請輸入想要讀取的資料ID：");
			int pk = in.nextInt();
			QueryProductByKey.queryProductByKey(pk);
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("無效ID，已退回主選單");
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		}
	}

	// 讀取指定資料並建立檔案
	public static void queryOutput(Scanner in) {
		System.out.print("請輸入想輸出成檔案的資料代碼（用\',\'隔開並按Enter結束）：");
		String[] input = in.nextLine().split(",");
		int[] ids = new int[input.length];
		for (int i = 0; i < ids.length; i++) {
			ids[i] = Integer.valueOf(input[i].trim());
		}
		Arrays.sort(ids);
		QueryOutputFile.queryOutputFile(ids, in);
	}
	
	// 依特定欄位搜尋資料 (未完)
	public static void queryByTitle(Scanner in) {
		String[] titles = {"代碼","學校名稱","公/私立","縣市名稱","地址","電話","網址","體系別"};
		System.out.println("以下為可供搜尋的欄位：");
		for (int i = 0; i < titles.length; i++) {
			System.out.println(i+1+". "+titles[i]);
		}
		System.out.print("請問你想查詢 1.單筆資料 2.多筆資料：");
		String input = in.nextLine().trim();
		if(input.contentEquals("1")) {
			System.out.print("請輸入想查詢的欄位（輸入數字，但不能輸入3、4與8）：");
			input = in.nextLine().trim();
			if(input.contentEquals("1")) {
				queryProduct(in);
			}
			else {
				String title = titles[Integer.valueOf(input)-1];
				System.out.print("請輸入想要的"+title+"：");
				String keyin = '\'' + in.nextLine().trim() + '\'';
				QueryProductByTitle.queryProductByKey(title, keyin);
			}
		}
		else if(input.contentEquals("2")) {
			System.out.print("請輸入想查詢的欄位（3、4或8）：");
			input = in.nextLine().trim();
			String title = titles[Integer.valueOf(input)-1];
			System.out.print("請輸入想要的"+title+"：");
			if(input.contentEquals("3")) {
				title = '[' + title + ']';
			}
			String keyin = '\'' + in.nextLine().trim() + '\'';
			QueryAllProductsByTitle.queryAllProductsByTitle(title, keyin);
		}
		else {
			System.out.println("無效指令，已退回主選單");
		}
//		@SuppressWarnings("unused")
//		String temp = in.nextLine();
	}
	
	// 刪除指定資料
	public static void deleteById(Scanner in) {
		try {
			System.out.print("請輸入想要刪除的資料ID：");
			int pk = in.nextInt();
			DeleteProductById.deleteProductById(pk);
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("無效ID，已退回主選單");
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		}
	}

	// 新增單筆資料
	public static void insertOneItem(Scanner in) {
		try {
			System.out.println("以下輸入要新增的資料");
//			@SuppressWarnings("unused")
//			String temp = in.nextLine();
			System.out.print("請輸入學校名稱：");
			String schoolName = in.nextLine();
			System.out.print("請輸入公立還是私立：");
			String pubOrPriv = in.nextLine();
			System.out.print("請輸入學校所在縣市：");
			String region = in.nextLine();
			System.out.print("請輸入學校地址：");
			String address = in.nextLine();
			System.out.print("請輸入學校電話：");
			String phone = in.nextLine();
			System.out.print("請輸入學校網址：");
			String url = in.nextLine();
			System.out.print("請輸入學校體系：");
			String system = in.nextLine();
			ProductDao productDao = new ProductDaoImpl();
			ProductBean bean = new ProductBean(null, schoolName, pubOrPriv, region, address, phone, url, system);
			productDao.save(bean);
			System.out.println("一筆資料新增成功");
//			@SuppressWarnings("unused")
//			String temp1 = in.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("無效輸入，已退回主選單");
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		} catch (SQLException e) {
			e.printStackTrace();
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		}
	}
	
	// 修改單筆資料
	public static void updateOneItem(Scanner in) {
		try {
			System.out.print("請輸入要修改的檔案代碼：");
			int Id = in.nextInt();
			@SuppressWarnings("unused")
			String temp = in.nextLine();
			System.out.print("請輸入學校名稱：");
			String schoolName = in.nextLine();
			System.out.print("請輸入公立還是私立：");
			String pubOrPriv = in.nextLine();
			System.out.print("請輸入學校所在縣市：");
			String region = in.nextLine();
			System.out.print("請輸入學校地址：");
			String address = in.nextLine();
			System.out.print("請輸入學校電話：");
			String phone = in.nextLine();
			System.out.print("請輸入學校網址：");
			String url = in.nextLine();
			System.out.print("請輸入學校體系：");
			String system = in.nextLine();
			ProductBean bean = new ProductBean(Id, schoolName, pubOrPriv, region, address, phone, url, system);
			UpdateSingleProduct.updateSingleProduct(bean, Id);
		} catch (InputMismatchException e) {
			System.out.println("無效代碼，已退回主選單");
			@SuppressWarnings("unused")
			String temp = in.nextLine();
		}
	}

	// 圖片存入資料庫
	public static void insertImg(Scanner in) {
		System.out.print("請問你建圖片資料庫了嗎（y/n）：");
		@SuppressWarnings("unused")
		String temp = null;
		String input = in.nextLine().trim();
		if(input.equalsIgnoreCase("y")) {
			InsertImg.insertImg(in);
		}
		else if(input.equalsIgnoreCase("n")) {
			CreateImgTable.createImgTable();
			temp = in.nextLine();
			InsertImg.insertImg(in);
		}
		else {
			System.out.println("連這麼簡單的問題都能亂打==");
			System.out.println("無效輸入，已退回主選單");
		}
	}

	// 顯示功能選單
	public static void printMenu() {
		// 共46個字元長
		for (int i = 0; i < 16; i++) {
			System.out.print("=");
		}
		System.out.print("歡迎使用功能選單");
		for (int i = 0; i < 16; i++) {
			System.out.print("=");
		}
		System.out.println();

		System.out.println("| (1)\t下載資料\t\t\t\t     |");
		System.out.println("| (2)\t建立新資料庫\t\t\t     |");
		System.out.println("| (3)\t檔案存入資料庫\t\t\t     |");
		System.out.println("| (4)\t讀取所有資料\t\t\t     |");
		System.out.println("| (5)\t讀取指定資料\t\t\t     |");
		System.out.println("| (6)\t讀取指定資料並建立檔案\t\t     |");
		System.out.println("| (7)\t依特定欄位搜尋資料\t\t     |");
		System.out.println("| (8)\t刪除指定資料\t\t\t     |");
		System.out.println("| (9)\t刪除所有資料\t\t\t     |");
		System.out.println("| (10)\t新增單筆資料\t\t\t     |");
		System.out.println("| (11)\t修改指定資料\t\t\t     |");
		System.out.println("| (12)\t圖片存入資料庫\t\t\t     |");
		System.out.println("| (13)\t讀取圖片並建立檔案\t\t     |");
		System.out.println("| (14)\t顯示功能選單\t\t\t     |");
		System.out.println("| (q)\t結束程式\t\t\t\t     |");

		for (int i = 0; i < 46; i++) {
			System.out.print("=");
		}
		System.out.println();
	}

}
