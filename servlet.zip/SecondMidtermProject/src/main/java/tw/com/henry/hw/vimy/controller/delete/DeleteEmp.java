package tw.com.henry.hw.vimy.controller.delete;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@WebServlet("/DeleteEmp.do")
public class DeleteEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String sql = "DELETE FROM [servdb].[dbo].[employee] WHERE empno = ?;";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String result = null;
		try {
			Context context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:comp/env/jdbc/servdb");
			try (Connection conn = ds.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql);) {
				stmt.setString(1, request.getParameter("empno"));
				stmt.executeUpdate();
			}
			result = "刪除成功";
		} catch (Exception e) {
			e.printStackTrace();
			result = "刪除失敗";
		}
		response.getWriter().write(result);
//		request.setAttribute("result", result);
//		request.getRequestDispatcher("/m11/DeleteEmp.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
