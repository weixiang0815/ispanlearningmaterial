package EEIT157_14_王威翔_第六章作業;

public class Ex9 {

	public static void main(String[] args) {

	}

}

class Animal {
}

class Mammal extends Animal{
}

class Cat extends Mammal{
}

class Dog extends Mammal{
}
