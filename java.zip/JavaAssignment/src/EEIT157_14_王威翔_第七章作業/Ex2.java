package EEIT157_14_王威翔_第七章作業;

import java.util.Calendar;

class StaticCodeBlock{
	static String season;
	
	static {
		Calendar d = Calendar.getInstance();
		if(d.get(Calendar.MONTH) + 1 >= 3 & d.get(Calendar.MONTH) + 1 <= 5)
			season = "春天";
		else if(d.get(Calendar.MONTH) + 1 >= 6 & d.get(Calendar.MONTH) + 1 <= 8)
			season = "夏天";
		else if(d.get(Calendar.MONTH) + 1 >= 9 & d.get(Calendar.MONTH) + 1 <= 11)
			season = "秋天";
		else
			season = "冬天";
	}
}

public class Ex2 {

	public static void main(String[] args) {
		System.out.println(StaticCodeBlock.season);
	}

}
