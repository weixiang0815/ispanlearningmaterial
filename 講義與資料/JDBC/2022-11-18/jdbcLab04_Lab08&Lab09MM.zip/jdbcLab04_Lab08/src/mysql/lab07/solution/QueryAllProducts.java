package mysql.lab07.solution;

import java.util.List;

import mysql.ex00.dao.ProductDao;
import mysql.ex00.dao.solution.ProductDaoImpl;
import mysql.ex00.model.ProductBean;

// 呼叫 mssql.ex00.dao.impl.ProductDaoImpl類別的findAll()方法來取得所有的產品資料
// 你需要完成本類別與mssql.ex00.dao.impl.ProductDaoImpl.findAll()方法

public class QueryAllProducts {
	public static void main(String args[]) {
		try  {
			ProductDao productDao = new ProductDaoImpl();
			List<ProductBean> list = productDao.findAll();
			for (ProductBean bean : list) {
				System.out.println(bean);
			}
			System.out.println("查詢記錄完畢");
			
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生: " + ex.getMessage());
		} 
	}
}