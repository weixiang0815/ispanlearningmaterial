package main;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.InputMethodEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import others.webCrawler;

public class MainFrame {

	private JFrame frmjava;
	private JTextField textField_圖片搜尋關鍵字;
	private JTextField textField_下載圖片張數;
	private JTextArea textArea_Google圖片爬蟲;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frmjava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmjava = new JFrame();
		frmjava.setTitle("資展Java班157期第一次期中專題");
		frmjava.setBounds(100, 100, 1080, 720);
		frmjava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmjava.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
		frmjava.getContentPane().add(tabbedPane);

		JPanel panel_大專校院名冊 = new JPanel();
		tabbedPane.addTab("大專校院名冊", null, panel_大專校院名冊, null);
		panel_大專校院名冊.setLayout(new GridLayout(0, 1, 0, 0));

		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
		panel_大專校院名冊.add(tabbedPane_1);

		JPanel panel_下載資料 = new JPanel();
		tabbedPane_1.addTab("下載資料", null, panel_下載資料, null);
		panel_下載資料.setLayout(null);

		JPanel panel_建立新資料庫 = new JPanel();
		tabbedPane_1.addTab("建立新資料庫", null, panel_建立新資料庫, null);

		JPanel panel_檔案存入資料庫 = new JPanel();
		tabbedPane_1.addTab("檔案存入資料庫", null, panel_檔案存入資料庫, null);

		JPanel panel_讀取所有資料 = new JPanel();
		tabbedPane_1.addTab("讀取所有資料", null, panel_讀取所有資料, null);

		JPanel panel_讀取指定資料 = new JPanel();
		tabbedPane_1.addTab("讀取指定資料", null, panel_讀取指定資料, null);

		JPanel panel_讀取指定資料並建立檔案 = new JPanel();
		tabbedPane_1.addTab("讀取指定資料並建立檔案", null, panel_讀取指定資料並建立檔案, null);

		JPanel panel_依關鍵字搜尋資料 = new JPanel();
		tabbedPane_1.addTab("依關鍵字搜尋資料", null, panel_依關鍵字搜尋資料, null);

		JPanel panel_刪除指定資料 = new JPanel();
		tabbedPane_1.addTab("刪除指定資料", null, panel_刪除指定資料, null);

		JPanel panel_刪除所有資料 = new JPanel();
		tabbedPane_1.addTab("刪除所有資料", null, panel_刪除所有資料, null);

		JPanel panel_新增單筆資料 = new JPanel();
		tabbedPane_1.addTab("新增單筆資料", null, panel_新增單筆資料, null);

		JPanel panel_修改指定資料 = new JPanel();
		tabbedPane_1.addTab("修改指定資料", null, panel_修改指定資料, null);

		JPanel panel_圖片資料庫 = new JPanel();
		tabbedPane.addTab("圖片資料庫", null, panel_圖片資料庫, null);
		panel_圖片資料庫.setLayout(null);

		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_2.setBounds(0, 0, 1061, 618);
		tabbedPane_2.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
		panel_圖片資料庫.add(tabbedPane_2);

		JPanel panel_圖片存入資料庫 = new JPanel();
		tabbedPane_2.addTab("圖片存入資料庫", null, panel_圖片存入資料庫, null);
		panel_圖片存入資料庫.setLayout(null);

		JButton btnNewButton_Google圖片爬蟲_1 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1.setBounds(920, 533, 126, 41);
		panel_圖片存入資料庫.add(btnNewButton_Google圖片爬蟲_1);

		JTextArea textArea_Google圖片爬蟲_1 = new JTextArea();
		textArea_Google圖片爬蟲_1.setFont(new Font("Monospaced", Font.PLAIN, 14));
		textArea_Google圖片爬蟲_1.setBounds(633, 10, 413, 513);
		panel_圖片存入資料庫.add(textArea_Google圖片爬蟲_1);

		JPanel panel_讀取圖片並建立檔案 = new JPanel();
		tabbedPane_2.addTab("讀取圖片並建立檔案", null, panel_讀取圖片並建立檔案, null);
		panel_讀取圖片並建立檔案.setLayout(new BorderLayout(0, 0));

		JPanel panel_Google圖片爬蟲 = new JPanel();
		tabbedPane.addTab("Google圖片爬蟲", null, panel_Google圖片爬蟲, null);
		panel_Google圖片爬蟲.setLayout(null);

		JButton btnNewButton_Google圖片爬蟲 = new JButton("清空");
		btnNewButton_Google圖片爬蟲.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_圖片搜尋關鍵字.setText("");
				textField_下載圖片張數.setText("");
				textArea_Google圖片爬蟲.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲.setBounds(911, 555, 140, 53);
		panel_Google圖片爬蟲.add(btnNewButton_Google圖片爬蟲);

		JScrollPane scrollPane_Google圖片爬蟲 = new JScrollPane();
		scrollPane_Google圖片爬蟲.setBounds(522, 10, 529, 535);
		panel_Google圖片爬蟲.add(scrollPane_Google圖片爬蟲);

		textArea_Google圖片爬蟲 = new JTextArea();
		textArea_Google圖片爬蟲.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		scrollPane_Google圖片爬蟲.setViewportView(textArea_Google圖片爬蟲);

		JLabel lblNewLabel = new JLabel("請輸入圖片搜尋關鍵字：");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel.setBounds(53, 82, 214, 42);
		panel_Google圖片爬蟲.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("請問要爬幾張圖片（最多20張）：");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(53, 227, 278, 42);
		panel_Google圖片爬蟲.add(lblNewLabel_1);

		textField_圖片搜尋關鍵字 = new JTextField();
		textField_圖片搜尋關鍵字.setToolTipText("");
		textField_圖片搜尋關鍵字.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_圖片搜尋關鍵字.setBounds(53, 134, 397, 42);
		panel_Google圖片爬蟲.add(textField_圖片搜尋關鍵字);
		textField_圖片搜尋關鍵字.setColumns(10);

		textField_下載圖片張數 = new JTextField();
		textField_下載圖片張數.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_下載圖片張數.setColumns(10);
		textField_下載圖片張數.setBounds(53, 279, 397, 42);
		panel_Google圖片爬蟲.add(textField_下載圖片張數);

		JButton btnNewButton = new JButton("開始爬蟲");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_Google圖片爬蟲.setText("");
				if (textField_圖片搜尋關鍵字.getText().trim().equals("") | textField_下載圖片張數.getText().trim().equals("")) {
					if (textField_圖片搜尋關鍵字.getText().trim().equals("")) {
						textArea_Google圖片爬蟲.append("搜尋關鍵字不能是空白\n");
					}
					if (textField_下載圖片張數.getText().trim().equals("")) {
						textArea_Google圖片爬蟲.append("下載張數不能是空白\n");
					}
				} else {
					if (Integer.valueOf(textField_下載圖片張數.getText().trim()) > 20) {
						textArea_Google圖片爬蟲.append("下載張數沒辦法一次超過20張喔！\n");
					} else {
						textArea_Google圖片爬蟲.append("開始爬蟲！！！\n");
						for (int i = 0; i < 30; i++) {
							textArea_Google圖片爬蟲.append("=");
						}
						textArea_Google圖片爬蟲.append("\n");
						String keyword = textField_圖片搜尋關鍵字.getText();
						int i = Integer.valueOf(textField_下載圖片張數.getText().trim());
						Elements imgs = webCrawler.crawl(keyword, i);

						int j = 0;
						File file = new File("C:/Users/Student/Desktop/爬下來的照片");
						if (!file.exists()) {
							file.mkdir();
						}
						try {
							for (Element img : imgs) {
								if (j + 1 > i)
									break;
								if (!img.attr("src").contains("https:"))
									continue;
								URL img_url = new URL(img.attr("src"));
								String img_name = j + 1 + ".jpg";
								try (FileOutputStream fos = new FileOutputStream(
										file.getAbsoluteFile() + "/" + img_name);
										BufferedOutputStream bos = new BufferedOutputStream(fos);) {
									bos.write(img_url.openStream().readAllBytes());
								}
								j++;
								textArea_Google圖片爬蟲.append("印好了第" + j + "張圖\n");
							}
						} catch (IOException e1) {
							textArea_Google圖片爬蟲.append("出現錯誤："+e1.getMessage());
						}
						for (int k = 0; k < 30; k++) {
							textArea_Google圖片爬蟲.append("=");
						}
						textArea_Google圖片爬蟲.append("\n");
						textArea_Google圖片爬蟲.append("圖片爬完囉！\n");
					}
				}
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton.setBounds(310, 492, 140, 53);
		panel_Google圖片爬蟲.add(btnNewButton);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 14));
		frmjava.setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("檔案");
		mnNewMenu.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("關閉");
		mntmNewMenuItem_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenu mnNewMenu_1 = new JMenu("其它");
		mnNewMenu_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("關於");
		mntmNewMenuItem_1_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		mnNewMenu_1.add(mntmNewMenuItem_1_1);
	}
}
