package tw.com.henry.hw.vimy.controller.search;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.EmpBean;
import tw.com.henry.hw.vimy.model.dao.EmpDao;

@WebServlet("/GetEmp")
public class GetEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		EmpBean emp = null;
		String empno = request.getParameter("empno");
		try {
			emp = new EmpDao(ConnectionFactory.getConnection()).getEmpByID(empno);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("emp", emp);
		request.getRequestDispatcher("/page/search/GetEmp.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
