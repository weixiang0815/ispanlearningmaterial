package EEIT157_14_王威翔_第九章作業;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;

public class Ex1 {

	public static void main(String[] args) throws ConcurrentModificationException{
		Collection<Object> v = new ArrayList<>();
		v.add(Integer.valueOf(100));
		v.add(Double.valueOf(3.14));
		v.add(Long.valueOf(12L));
		v.add((short)100);
		v.add(Double.valueOf(5.1));
		v.add("Kitty");
		v.add(Integer.valueOf(200));
		v.add(new Object());
		v.add("Snoopy");
		v.add(new BigInteger("1000"));

		System.out.println("印出物件v內所有元素：");
		for(Object obj : v) {
			System.out.println(obj);
		}
		System.out.println();

		Iterator<Object> itr = v.iterator();
		while(itr.hasNext()) {
			Object obj = itr.next();
			if(!(obj instanceof Number))
				itr.remove();
		}
		
		System.out.println("再次印出物件v內所有元素：");
		for(Object obj : v) {
			System.out.print(obj + " ");
		}
	}

}
