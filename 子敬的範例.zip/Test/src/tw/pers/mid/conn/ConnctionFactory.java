package tw.pers.mid.conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnctionFactory {

	public static Connection getConnectionToSQLServer() {
		String sqlURL = "jdbc:sqlserver://localhost:1433;user=sa;password=1234;trustservercertificate=true;database=TestDB";
		Connection conn = null;

		try {
			conn = DriverManager.getConnection(sqlURL);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

}
