package com.tw.henry.controller.search;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Creator;
import com.tw.henry.model.dao.CreatorDao;

@WebServlet("/GetCreators.do")
public class GetCreators extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String result;
		List<Creator> crts = null;
		try {
			CreatorDao creatorDao = new CreatorDao(ConnectionFactory.getConnection());
			if (!"".contentEquals(name)) {
				crts = creatorDao.getAllCreatorsByName(name);
				result = "查詢成功";
			} else {
				result = "查詢欄位不得為空白";
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("crts", crts);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/search/GetCreators.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
