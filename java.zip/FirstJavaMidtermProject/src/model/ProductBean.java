package model;

import java.io.Serializable;
import java.sql.Date;

public class ProductBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	Integer		productId;
	Date 		date;
	String		agent;
	String		productName;
	String		distAgency;
	String		assuAgency;
	
	public ProductBean(Integer productId, Date date, String agent, String productName, String distAgency,
			String assuAgency) {
		super();
		this.productId = productId;
		this.date = date;
		this.agent = agent;
		this.productName = productName;
		this.distAgency = distAgency;
		this.assuAgency = assuAgency;
	}
	
	@Override
	public String toString() {
		return "ProductBean [productId=" + productId + ", date=" + date + ", agent=" + agent + ", productName="
				+ productName + ", distAgency=" + distAgency + ", assuAgency=" + assuAgency + "]";
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDistAgency() {
		return distAgency;
	}

	public void setDistAgency(String distAgency) {
		this.distAgency = distAgency;
	}

	public String getAssuAgency() {
		return assuAgency;
	}

	public void setAssuAgency(String assuAgency) {
		this.assuAgency = assuAgency;
	}
}
