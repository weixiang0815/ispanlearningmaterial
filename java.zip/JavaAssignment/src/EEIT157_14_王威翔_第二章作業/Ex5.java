package EEIT157_14_王威翔_第二章作業;

public class Ex5 {

	public static void main(String[] args) {
		System.out.print("一斤半的牛肉、兩斤雞蛋與三把青菜共需要");
		System.out.println((((int)(120 * 1.5) + (36 * 2) + (20 * 3))) + "元");
	}

}
