package tw.hibernatedemo.model;

public class HouseBean {
	
	private int houseId;
	private String houseName;

	public HouseBean() {
	}
	
	public HouseBean(String houseName) {
		super();
		this.houseName = houseName;
	}

	public HouseBean(int houseId, String houseName) {
		super();
		this.houseId = houseId;
		this.houseName = houseName;
	}

	public int gethouseId() {
		return houseId;
	}

	public void sethouseId(int houseId) {
		this.houseId = houseId;
	}

	public String gethouseName() {
		return houseName;
	}

	public void sethouseName(String houseName) {
		this.houseName = houseName;
	}

	@Override
	public String toString() {
		return "HouseBean [houseId=" + houseId + ", houseName=" + houseName + "]";
	}
	
}
