package ch05;

public class Mapper {
	public static void main(String args[]) {
		for (int j = 0; j < args.length; j++) {
			System.out.println("arg[" + j + "]=" + args[j]);
		}
	}
}
