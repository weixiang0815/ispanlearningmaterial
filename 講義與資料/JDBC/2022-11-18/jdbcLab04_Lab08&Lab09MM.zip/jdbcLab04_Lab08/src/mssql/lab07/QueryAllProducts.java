package mssql.lab07;

// 呼叫 mssql.ex00.dao.impl.ProductDaoImpl類別的findAll()方法來取得所有的產品資料
// 你需要完成本類別與mssql.ex00.dao.impl.ProductDaoImpl.findAll()方法

public class QueryAllProducts {
	public static void main(String args[]) {
		try  {
//			ProductDao productDao = ....;
//			List<ProductBean> beans = productDao.???????();
//			for (??????? bean : ????) {
//				System.out.println(bean);
//			}
			System.out.println("查詢記錄完畢");
			
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生: " + ex.getMessage());
		} 
	}
}