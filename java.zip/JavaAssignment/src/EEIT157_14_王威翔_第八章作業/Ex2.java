package EEIT157_14_王威翔_第八章作業;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
