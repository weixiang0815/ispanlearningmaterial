package query;

import java.util.List;
import java.util.Scanner;

import model.ProductBean;
import model.ProductDaoImpl;
import update.UpdateSingleProduct;

public class FuzzySearch {
	public static void fuzzySearch(Scanner in, String keyword) {
		try {
			String[] titles = {"代碼", "學校名稱", "[公/私立]", "縣市名稱", "地址", "電話", "網址", "體系別" };
			List<ProductBean> resultBean = new ProductDaoImpl().fuzzySearch(titles[0], keyword);
			for (int i = 1; i < titles.length; i++) {
				List<ProductBean> tempBean = new ProductDaoImpl().fuzzySearch(titles[i], keyword);
				if(tempBean.size()>resultBean.size()) {
					resultBean.clear();
					resultBean.addAll(tempBean);
				}
			}
			if (resultBean.size() == 0) {
				System.out.println("我輕輕地來，帶不回一條結果～");
				System.out.println("查到" + resultBean.size() + "條結果");
			} else {
				boolean flag1 = false;
				boolean flag2 = false;
				if (resultBean.size() == 1) {
					System.out.println("萬中選一的結果被我找到啦！");
				} else {
					System.out.println("手上好多東西呀！快拿不動啦！");
				}
				System.out.println("查到" + resultBean.size() + "條結果");
				System.out.print("要印出來給你看嗎（y/n）:");
				if (in.nextLine().trim().equalsIgnoreCase("y")) {
					resultBean.forEach(n->System.out.println(n+"\n"));
				}
				else if(in.nextLine().trim().equalsIgnoreCase("n")){
					flag1 = true;
				}
				else {
					System.out.println("你打這東西大概只有仙女星人才看得懂");
					flag1 = true;
				}
				if (resultBean.size() == 1) {
					System.out.print("你的結果只有一筆，要刪掉嗎（y/n）？");
					String input = in.nextLine().trim();
					if (input.equalsIgnoreCase("y")) {
						new ProductDaoImpl().deleteById(resultBean.get(0).getId());
					}
					else if(input.equalsIgnoreCase("n")){
						flag2 = true;
					}
					else {
						System.out.println("你打這東西大概只有仙女星人才看得懂");
						flag2 = true;
					}
				}
				if(!flag1&flag2) {
					System.out.println("你刪了一筆資料");
				}
				else if(flag1&flag2) {
					System.out.println("不想看也不想刪，那你是查心酸的嗎？？？");
				}
			}
		} catch (

		Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		}
		System.out.println("結束模糊搜尋");
	}
	
	// 修改單筆資料
	public static void updateOneItem(int Id, Scanner in) {
		System.out.println("以下輸入要修改的欄位資料");
		System.out.print("請輸入學校名稱：");
		String schoolName = in.nextLine();
		System.out.print("請輸入公立還是私立：");
		String pubOrPriv = in.nextLine();
		System.out.print("請輸入學校所在縣市：");
		String region = in.nextLine();
		System.out.print("請輸入學校地址：");
		String address = in.nextLine();
		System.out.print("請輸入學校電話：");
		String phone = in.nextLine();
		System.out.print("請輸入學校網址：");
		String url = in.nextLine();
		System.out.print("請輸入學校體系：");
		String system = in.nextLine();
		ProductBean bean = new ProductBean(Id, schoolName, pubOrPriv, region, address, phone, url, system);
		UpdateSingleProduct.updateSingleProduct(bean, Id);
	}

}