/**
 * 
 */
/**
 * @author Student
 *
 */
module JavaAssignment {
}