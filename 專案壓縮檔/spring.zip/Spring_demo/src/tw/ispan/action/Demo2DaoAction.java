package tw.ispan.action;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import tw.ispan.model.LoginDao;

public class Demo2DaoAction {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoginDao loginDao = context.getBean("loginDao", LoginDao.class);

		System.out.println("result 1: " + loginDao.checkLogin("jerry", "pwdd"));
		System.out.println("result 2: " + loginDao.checkLogin("jerry", "pwd"));
		
		context.close();
	}

}
