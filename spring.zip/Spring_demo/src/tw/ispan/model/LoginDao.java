package tw.ispan.model;

public class LoginDao {

	public LoginDao() {
	}

	public boolean checkLogin(String username, String pwd) {
		return "jerry".equals(username) && "pwdd".equals(pwd);
	}
	
}
