package tw.com.henry.hw.vimy.controller.insert;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.Creator;
import tw.com.henry.hw.vimy.model.dao.CreatorDao;

@WebServlet("/InsertCreator.do")
public class InsertCreator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String result = null;
		Creator crt = null;
		try {
			if (new CreatorDao(ConnectionFactory.getConnection())
					.getCreatorByAccount(request.getParameter("crt_name")).equals(null)) {
				crt = new Creator();
				crt.setId(Integer.valueOf(request.getParameter("crt_id")));
				crt.setName(request.getParameter("crt_name"));
				crt.setAccount(request.getParameter("account"));
				crt.setPassword(request.getParameter("password"));
				crt.setThumbnail(request.getParameter("crt_thumbnail"));
				crt.setGender(request.getParameter("gender"));
				crt.setBirthday(request.getParameter("birthday"));
				crt.setUploadCount(Integer.valueOf(request.getParameter("uploadCount")));
				crt.setCountry(request.getParameter("country"));
				crt.setInfo(request.getParameter("crt_info"));
				crt.setSocialAccount("Facebook", request.getParameter("fb_account"));
				crt.setSocialAccount("Google", request.getParameter("google_account"));
				crt.setSocialAccount("Twitter", request.getParameter("twitter_account"));
				crt.setSocialAccount("Instagram", request.getParameter("ig_account"));
				int insert = new CreatorDao(ConnectionFactory.getConnection()).addNewCreator(crt);
				result = insert < 0 ? "註冊失敗" : "註冊成功";
			} else {
				result = "此帳戶已存在";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/insert/InsertCreator.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
