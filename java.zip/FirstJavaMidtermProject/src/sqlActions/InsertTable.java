package sqlActions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import system.SystemConstant;

public class InsertTable {
	static String insertBookString = "";
	static String dataFilename = "C:/Users/Student/Desktop/TDCC_OD_4-1.csv";

	public static void insertTable() {
		setSQLCOmmand();
		batchInsert();
	}

	private static void batchInsert() {
		try (Connection conn = DriverManager.getConnection(
				SystemConstant.getDbURL(), 
				SystemConstant.getUser(),
				SystemConstant.getPassword()); 
			PreparedStatement stmt = conn.prepareStatement(insertBookString);
			BufferedReader br = new BufferedReader(
								new InputStreamReader(
								new FileInputStream(dataFilename)));	
		) {
			// 先讀第一行表頭並拋棄
			br.readLine();
			
			System.out.println("現在開始新增紀錄......");
			String line = "";
			while ((line = br.readLine()) != null) {
				String[] sa = line.split(",");
				// 資料日期
				StringBuilder date = new StringBuilder(sa[0]);
				date.insert(4, '-');
				date.insert(7, '-');
				stmt.setDate(1, Date.valueOf(date.toString()));
				// 發行人/總代理人身分別
				stmt.setString(2, sa[1]);
				// 境外結構型商品名稱
				stmt.setString(3, sa[2]);
				// 所屬發行機構
				stmt.setString(4, sa[3]);
				// 所屬保證機構
				stmt.setString(5, sa[4]);
				stmt.executeUpdate();
//				System.out.println("新增一筆紀錄成功");
			}
			System.out.println("記錄新增成功");
		} catch (SQLException e) {
			System.err.print("存取資料庫時發生例外: " + e);
			e.printStackTrace();
		} catch (IOException e) {
			System.err.print("IO時發生例外: " + e);
			e.printStackTrace();
		}
	}

	private static void setSQLCOmmand() {
		// 新增一筆Book_JDBC之紀錄
		insertBookString = " insert into [境外結構型商品發行人/總代理人資訊] " + " (資料日期, [發行人/總代理人身分別], 境外結構型商品名稱, 所屬發行機構, 所屬保證機構) "
				+ " values " + " (?, ?, ?, ?, ?); ";
	}
}
