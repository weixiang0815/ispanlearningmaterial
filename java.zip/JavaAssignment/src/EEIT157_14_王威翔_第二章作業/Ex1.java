package EEIT157_14_王威翔_第二章作業;

public class Ex1 {

	public static void main(String[] args) {
		int x = 12, y = 6;
		System.out.println("長方形邊長和：" + ((x + y) * 2));
		System.out.println("長方形面積：" + (x * y));
	}

}
