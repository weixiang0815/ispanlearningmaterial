package EEIT157_14_王威翔_第二章作業;

public class Ex3 {
	public static void main(String[] arg) {
		double r = 10, pi = 3.14;
		System.out.println("圓形面積：" + (r * r * pi));
	}
}
