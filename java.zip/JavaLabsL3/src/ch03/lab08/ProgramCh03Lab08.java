package ch03.lab08;

public class ProgramCh03Lab08 {
/*
 請編寫程式ch03.lab08.ProgramCh03Lab08，在main()之內請將
 華氏70度轉換攝氏溫度。
 
提示1: 華氏溫度減去 32, 然後乘以 5, 再除以 9 即為攝氏溫度。
提示2: 華氏溫度-40度是攝氏溫度-40度。
提示3: 華氏溫度212度是攝氏溫度100度。

 
*/
  public static void main(String[] args) {
    System.out.println("華氏溫度70度是攝氏溫度" + ((70 - 32) * 5 / 9) + "度。");
   
  }
}
