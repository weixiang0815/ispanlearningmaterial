package tw.ispan.model;

public interface CreditCard {

	void useCard(String messages);

}
