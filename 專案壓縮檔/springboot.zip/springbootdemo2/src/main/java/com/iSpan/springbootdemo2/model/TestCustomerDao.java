package com.iSpan.springbootdemo2.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class TestCustomerDao {

	// 若 query 語法是動態的，就用這個 DAO 寫法

	@PersistenceContext
	private EntityManager em;

	public List<Customer> someSQL() {
		TypedQuery<Customer> query = em.createQuery("from Customer", Customer.class);
		return query.getResultList();
	}

}