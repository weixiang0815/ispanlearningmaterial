package ch01;

public class PrintlnDemo {
	public static void main(String args[]) {
		System.out.println("111");
		System.out.println("222");
		System.out.println("333");

		System.out.println();

		System.out.print("111");
		System.out.print("222");
		System.out.print("333");
	}
}
