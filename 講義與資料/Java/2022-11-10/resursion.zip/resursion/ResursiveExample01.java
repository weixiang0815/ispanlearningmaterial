package ch06.resursion; 

public class ResursiveExample01 {

	public static long factorial(int n) {
		if ( n == 0) {
			return 1;
		} else { 
			return n * factorial(n-1);
		}
		
	}
	
	public static long fibonacci(int n) {
		if ( n == 0) {
			return 0;
		} else if (n == 1) { 
			return 1;
		} else { 
			return fibonacci(n - 1) + fibonacci(n-2);
		}
	}
	
	public static long pow(int x, int n) {
		if ( n == 0) {
			return 1;
		} else if (n == 1) { 
			return x;
		} else { 
			return x * pow(x, n-1);
		}
		
		
	}
	
	public static void main(String[] args) {
//		for(int n = 0; n <= 10 ; n++) {
//			long ans = factorial(n);
//			System.out.println( n + "!= " + ans);
//		}
//		System.out.println("\n---------------------------");		
//		for(int n = 0; n <= 20 ; n++) {
//			long ans = fibonacci(n);
//			System.out.print(ans + " ");
//		}
//		System.out.println("\n---------------------------");
		for(int n = 0; n <= 10 ; n++) {
			long ans = pow(2, n);
			System.out.println(ans);
		}
		System.out.println("---------------------------");
	}
}
