package EEIT157_14_王威翔_第六章作業.Ex7;

public class MyRectangle {
	
	private double width, depth;
	
	void setWidth(double w) {
		this.width = w;
	}
	
	void setDepth(double d) {
		this.depth = d;
	}
	
	double getArea() {
		return width * depth;
	}
	
	public MyRectangle() {
		setWidth(0);
		setDepth(0);
	}
	
	public MyRectangle(double width, double depth) {
		setWidth(width);
		setDepth(depth);
	}
}
