package query;

import model.ProductBean;
import model.ProductDaoImpl;

public class QueryProductByKey {
	public static void queryProductByKey(int pk) {
		try {
			ProductBean productBean = new ProductDaoImpl().findById(pk);
			if (productBean == null){
				System.out.println("查無此資料:Key = " + pk); 
			} else {
				System.out.println("查得資料: " +  productBean);
			}
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		}
		System.out.println("查詢記錄完畢");
	}
}