package tw.pers.mid.test;

import tw.pers.mid.bean.Users;

public class Test {

	public static void main(String[] args) {
		Users u = new Users();
		u.setName("Amy");
		u.setAge(18);
		u.setId(1005);
		Users u2 = new Users();
		u2.setName("Amy");
		u2.setAge(18);
		u2.setId(1005);
		
		System.out.println(u);
		System.out.println(u2.toString());
	}

}
