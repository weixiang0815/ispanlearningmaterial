package ch06._09_object.equalsA;

public class Triangle {

}
