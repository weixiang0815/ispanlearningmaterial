package advance;

import java.sql.SQLException;

public class DeleteAllTable {
	public static void deleteAllTable() {
		ProductDao productDao = new ProductDaoImpl();
		try {
			productDao.deleteAll();
			System.out.println("所有紀錄刪除成功");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
