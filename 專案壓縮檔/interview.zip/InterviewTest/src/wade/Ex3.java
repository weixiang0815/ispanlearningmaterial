package wade;

public class Ex3 {

	public static void main(String[] args) {
		for (int i = 1; i <= 5; i++) {
			for (int j = 5; j >= i+1; j--) {
				System.out.print(" ");
			}
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
				if (j < i) {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		for (int i = 4; i >= 1; i--) {
			for (int j = i+1; j <= 5; j++) {
				System.out.print(" ");
			}
			for (int j = i; j >= 1; j--) {
				System.out.print("*");
				if (j > 1) {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

}
