package query;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import model.ProductBean;
import model.ProductDaoImpl;

public class QueryOutputFile {
	public static String queryOutputFile(int[] ids) {
		StringBuffer sb = new StringBuffer();
		sb.append("現在開始匯出檔案\n");
		String path = "C:/Users/Student/Desktop/專題下載檔案";
		File file = new File(path);
		if (!file.exists()) {
			file.mkdir();
		}
		String filename = path + "/查詢資料匯出檔" + ".csv";
		try (FileOutputStream fos = new FileOutputStream(filename);
				OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
				PrintWriter pw = new PrintWriter(osw);) {
			pw.write("代碼,學校名稱,公/私立,縣市名稱,地址,電話,網址,體系別\n");
			for (int i = 0; i < ids.length; i++) {
				ProductBean productBean = new ProductDaoImpl().findById(ids[i]);
				StringBuffer str = new StringBuffer();
				if (productBean == null) {
//					System.out.println("查無此資料:Key = " + ids[i]);
					sb.append("查無此資料:Key = " + ids[i]+'\n');
				} else {
//					System.out.println("查得資料: " + productBean);
					sb.append("查得資料: " + productBean+'\n');
					str.append(productBean.getId()+",");
					str.append(productBean.getSchoolName()+',');
					str.append(productBean.getPubOrPriv()+',');
					str.append(productBean.getRegion()+',');
					str.append(productBean.getAddress()+',');
					str.append(productBean.getPhone()+',');
					str.append(productBean.getUrl()+',');
					str.append(productBean.getSystem()+'\n');
					pw.write(str.toString());
				}
			}
//			System.out.println("紀錄新增成功");
			sb.append("紀錄新增成功");
			return sb.toString();
		} catch (Exception ex) {
//			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
//			ex.printStackTrace();
			return "查詢記錄時發生例外: " + ex.getMessage();
		}
	}
}