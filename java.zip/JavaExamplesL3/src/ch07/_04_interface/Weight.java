package ch07._04_interface;

public interface Weight {
	int getWeight();
}
