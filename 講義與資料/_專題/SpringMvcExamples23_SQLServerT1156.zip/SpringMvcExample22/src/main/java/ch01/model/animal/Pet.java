package ch01.model.animal;

public interface Pet {
	public void play();
}
