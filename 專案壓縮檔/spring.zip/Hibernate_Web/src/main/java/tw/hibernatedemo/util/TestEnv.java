package tw.hibernatedemo.util;

public class TestEnv {

	public static void main(String[] args) {
		System.out.println("Hi，我是王威翔");
	}

}
