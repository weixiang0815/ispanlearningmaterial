package tw.com.henry.hw.vimy.model.bean;

import java.io.Serializable;
import java.util.HashMap;

public class CreatorBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String name;
	private String account;
	private String password;
	private String thumbnail;
	private String gender;
	private String birthday;
	private int uploadCount;
	private String country;
	private String info;
	private HashMap<String, String> socialAccount;

	public CreatorBean() {
	}

	public CreatorBean(int id, String name, String account, String password, String thumbnail, String gender, String birthdate, int uploadCount,
			String country, String info, HashMap<String, String> socialAccount) {
		setId(id);
		setName(name);
		setAccount(account);
		setPassword(password);
		setThumbnail(thumbnail);
		setGender(gender);
		setBirthday(birthdate);
		setUploadCount(uploadCount);
		setCountry(country);
		setInfo(info);
		initSocialAccount();
		for (String s : socialAccount.keySet()) {
			setSocialAccount(s, socialAccount.get(s));
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthdate) {
		this.birthday = birthdate;
	}

	public int getUploadCount() {
		return uploadCount;
	}

	public void setUploadCount(int uploadCount) {
		this.uploadCount = uploadCount;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public HashMap<String, String> getSocialAccount() {
		return socialAccount;
	}

	private void initSocialAccount() {
		socialAccount = new HashMap<>();
		socialAccount.put("Facebook", "");
		socialAccount.put("Google", "");
		socialAccount.put("Twitter", "");
		socialAccount.put("Instagram", "");
	}

	public String addSocialAccount(String platform, String url) {
		if (!socialAccount.containsKey(platform)) {
			return "此社群網站不存在（Facebook、Google、Twitter、Instagram），帳號新增失敗";
		}
		if (!socialAccount.get(platform).equals("")) {
			return "此社群網站已建立帳號，請改用setSocialAccount()方法";
		}
		socialAccount.put(platform, url);
		return "帳號新增成功";
	}

	public String removeSocialAccount(String platform) {
		if (socialAccount.containsKey(platform)) {
			socialAccount.put(platform, "");
			return "帳號刪除成功";
		}
		return "此社群網站不存在（Facebook、Google、Twitter、Instagram），帳號刪除失敗";
	}

	public String setSocialAccount(String platform, String url) {
		if (!socialAccount.containsKey(platform)) {
			return "此社群網站不存在（Facebook、Google、Twitter、Instagram），帳號修改失敗";
		}
		if (socialAccount.get(platform).equals("")) {
			return "此社群網站尚未建立帳號，請改用addSocialAccount()方法";
		}
		socialAccount.put(platform, url);
		return "帳號修改成功";
	}

	@Override
	public String toString() {
		StringBuilder output = new StringBuilder("這位創作者的資訊：\n");
		output.append("編號：" + id + '\n');
		output.append("姓名：" + name + '\n');
		output.append("性別：" + gender + '\n');
		output.append("上傳作品數：" + uploadCount + '\n');
		output.append("國籍：" + country + '\n');
		output.append("社交帳號：\n");
		for (String s : socialAccount.keySet()) {
			if (!socialAccount.get(s).equals(""))
				output.append("\t" + s + "：" + socialAccount.get(s) + '\n');
		}
		output.append("簡介：\n" + info);
		return output.toString();
	}
}
