package tw.com.henry.hw.vimy.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.Creator;
import tw.com.henry.hw.vimy.model.dao.CreatorDao;

@WebServlet("/CheckLogin")
public class CheckLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String account = request.getParameter("account");
		String password = request.getParameter("password");
		String result = null;
		Creator crt = null;
		try {
			crt = new CreatorDao(ConnectionFactory.getConnection()).getCreatorByAccount(account);
			if (crt.equals(null)) {
				result = "查無此帳號，登入失敗";
			} else {
				if (password != crt.getPassword()) {
					result = "密碼錯誤，登入失敗";
				} else {
					result = "登入成功";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("login.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
