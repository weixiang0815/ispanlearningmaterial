package tw.com.henry.hw.vimy.controller.insert;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.VideoBean;
import tw.com.henry.hw.vimy.model.dao.VideoDao;

@WebServlet("/InsertVideo.do")
public class InsertVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String sql = "INSERT INTO [servdb].[dbo].[employee] " + "VALUES (?, ?, ?, ?, ?, ?);";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String result = null;
		VideoBean video = null;
		try {
			video = new VideoBean();
			video.setId(Integer.valueOf(request.getParameter("video_id")));
			video.setName(request.getParameter("video_name"));
			video.setThumbnail(request.getParameter("video_thumbnail"));
			video.setVideo(request.getParameter("filepath"));
			video.setInfo(request.getParameter("video_info"));
			video.setCreator(Integer.valueOf(request.getParameter("crt_id")));
			int insert = new VideoDao(ConnectionFactory.getConnection()).addNewVideo(video);
			result = insert < 0 ? "新增失敗" : "新增成功";
		} catch (Exception e) {
			e.printStackTrace();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/InsertVideo.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
