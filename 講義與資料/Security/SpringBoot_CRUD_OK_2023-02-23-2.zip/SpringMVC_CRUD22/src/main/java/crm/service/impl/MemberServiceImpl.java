package crm.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.model.Member;
import crm.repository.MemberRepository;
import crm.service.MemberService;
@Service
@Transactional
public class MemberServiceImpl implements MemberService {

	MemberRepository memberDao;
	
	@Autowired
	public MemberServiceImpl(MemberRepository memberDao) {
		this.memberDao = memberDao;
	}

	@Override
	public void save(Member member) {
		memberDao.save(member);
	}

	@Override
	public Member findById(Integer id) {
		return memberDao.findById(id);
	}

	@Override
	public void update(Member member) {
		memberDao.update(member);
	}

	@Override
	public List<Member> findAll() {
		return memberDao.findAll();
	}

	@Override
	public void deleteById(Integer id) {
		memberDao.deleteById(id);
	}

}
