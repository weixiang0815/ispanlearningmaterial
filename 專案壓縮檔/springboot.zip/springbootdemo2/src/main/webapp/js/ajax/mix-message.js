const editBtn = document.getElementsByClassName("edit-btn");
let editBtnLength = editBtn.length
for (let i = 0; i <= editBtnLength - 1; i++) {
    editBtn[i].addEventListener("click", function (e) {
        let msgId = this.getAttribute("data-msgid");
        editMsg(msgId);
    });
}

function editMsg(msgId) {
    let content = document.querySelector(`[data-contentid="${msgId}"]`);

    let cardBody = content.parentNode;
    if (cardBody.childNodes.length <= 5) {
        let saveAndUpdateButton = document.createElement("button");
        saveAndUpdateButton.className = "save-update-btn btn btn-info btn-sm";
        saveAndUpdateButton.innerHTML = "修改且送出";
        insertAfter(content, saveAndUpdateButton);

        content.setAttribute("contenteditable", "true");
        content.focus();

        saveAndUpdateButton.addEventListener("click", e => {
            const putObj = {
                "msg-id": msgId,
                "edit-Text": content.textContent,
            };
            saveAndUpdateButton.remove();
            sendPutAjax(putObj);
        });
    }
}

function insertAfter(refNode, newNode) {
    refNode.parentNode.insertBefore(newNode, refNode.nextSibling);
}

// 送 ajax
function sendPutAjax(json) {
    axios.put("http://localhost:8088/my-app/messages/api/put", json).then(res => {
        console.log(res.data);
    }).catch(err => {
        console.log(err);
    });
}

// ajax 回傳 html Page
const deleteBtn = document.getElementsByClassName("delete-btn");
let length = deleteBtn.length;
for (let i = 0; i < length; i++) {
    deleteBtn[i].addEventListener("click", function (e) {
        let msgID = this.getAttribute("data-msgid");
        sendDeleteAjax(msgID);
    })
}

function sendDeleteAjax(msgId) {
    axios({
        url: "http://localhost:8088/my-app/messages/api/delete",
        method: "delete",
        // get request 以外的 axios 會自動把 content type 轉 application/json
        // 但我們這次沒有要送 body，所以要設定回 application/x-www-form-urlencoded
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        // axios 的 response type 預設為 json，但這次回傳 html
        responseType: "text",
        params: {
            // key 看 controller，value 看 js
            msgId: msgId,
        },
    }).then(res => {
        console.log(res.data);
        // 405 就不會跳這裡
    }).catch(err => {
        console.log(err);
        // 前端 request 不是送 get，就不能用後段送 get 回來，需要在前端呼叫 controller 跳頁
        window.location.href = "http://localhost:8088/my-app/messages/mix";
    });
}