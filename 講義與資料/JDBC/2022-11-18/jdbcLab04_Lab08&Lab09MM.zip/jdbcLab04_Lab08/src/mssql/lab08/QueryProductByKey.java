package mssql.lab08;

// 依鍵值查詢產品資料

/*
文字檔data/product/ProductQueryData.txt內有多筆產品的代號(主鍵)，
// 逐筆讀入ProductQueryData.txt檔案內的每一列資料，將此代號轉換為int型態，
// 然後呼叫ProductDaoImpl類別的findById(key)方法查詢單筆產品資料。

你需要完成本類別與mssql.ex00.dao.impl.ProductDaoImpl.findById()方法
*/
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import mssql.ex00.dao.ProductDao;

public class QueryProductByKey {
	public static void main(String args[]) {
		try (
			FileInputStream fis = null; 
			InputStreamReader isr = null;
			BufferedReader br = null;	
		) {
			String line = null;
			ProductDao productDao = null;
			/*
			while ( (line = br.????????()) != null){
				int key = Integer.????????(line.trim());
				ProductBean productBean = productDao.??????????????(key);
				if (bean==null){
					System.out.println("查無此資料Key: " + key); 
				} else {
					System.out.println("查得資料: " +  productBean);
				}
				System.out.println("查詢記錄完畢");
			}
			*/
		} catch (Exception ex) {
			System.err.println("查詢記錄時發生例外: " + ex.getMessage());
			ex.printStackTrace();
		} 
	}
}