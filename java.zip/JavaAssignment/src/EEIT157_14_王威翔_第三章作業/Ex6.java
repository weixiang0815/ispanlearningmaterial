package EEIT157_14_王威翔_第三章作業;

public class Ex6 {

	public static void main(String[] args) {
		double square = 10 * 10, round = 5 * 5 * Math.PI;
		System.out.println("正方形面積與其內接圓面積的差值為" + (square - round));

	}

}
