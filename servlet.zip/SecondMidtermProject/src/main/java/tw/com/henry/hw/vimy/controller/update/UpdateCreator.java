package tw.com.henry.hw.vimy.controller.update;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.CreatorBean;
import tw.com.henry.hw.vimy.model.dao.CreatorDao;

@WebServlet("/UpdateCreator.do")
public class UpdateCreator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String result = null;
		CreatorBean crt = null;
		try {
			crt = new CreatorBean();
			crt.setId(Integer.valueOf(request.getParameter("crt_id")));
			crt.setName(request.getParameter("crt_name"));
			crt.setAccount(request.getParameter("account"));
			crt.setPassword(request.getParameter("password"));
			crt.setThumbnail(request.getParameter("crt_thumbnail"));
			crt.setGender(request.getParameter("gender"));
			crt.setBirthday(request.getParameter("birthday"));
			crt.setUploadCount(Integer.valueOf(request.getParameter("uploadCount")));
			crt.setCountry(request.getParameter("country"));
			crt.setInfo(request.getParameter("crt_info"));
			crt.setSocialAccount("Facebook", request.getParameter("fb_account"));
			crt.setSocialAccount("Google", request.getParameter("google_account"));
			crt.setSocialAccount("Twitter", request.getParameter("twitter_account"));
			crt.setSocialAccount("Instagram", request.getParameter("ig_account"));
			int update = new CreatorDao(ConnectionFactory.getConnection()).updateCreatorByID(crt);
			result = update < 0 ? "更新失敗" : "更新成功";
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/UpdateCreator.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
