package com.iSpan.springbootdemo2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.iSpan.springbootdemo2.model.Message;
import com.iSpan.springbootdemo2.service.MessageService;

@Controller
public class MessageController {

	@Autowired
	private MessageService mService;

	@GetMapping("/messages/add")
	public String addMsg(Model model) {
		model.addAttribute("messages", new Message());
		model.addAttribute("latestMsg", mService.getLatestMessage());
		return "messages/addMessages";
	}

	@PostMapping("/messages/post")
	public String addMsg(@ModelAttribute Message msg, Model model) {
		mService.insert(msg);
		model.addAttribute("messages", new Message());
		model.addAttribute("latestMsg", mService.getLatestMessage());
		return "messages/addMessages";
	}

	@GetMapping("/messages/page")
	public String showMessageByPage(@RequestParam(name = "p", defaultValue = "1") Integer pageNumber, Model model) {
		model.addAttribute("page", mService.getMessageByPage(pageNumber));
		return "messages/showMessages";
	}

	@GetMapping("/messages/edit")
	public String editMessagePage(@RequestParam("id") Integer id, Model model) {
		model.addAttribute("message", mService.findById(id));
		return "messages/editMessages";
	}

	@PutMapping("/messages/edit")
	public String sendEditedMessage(@ModelAttribute("message") Message msg) {
		mService.insert(msg);
		return "redirect:/messages/page";
	}

	@DeleteMapping("/messages/delete")
	public String deleteMessage(@RequestParam("id") Integer id) {
		mService.deleteById(id);
		return "redirect:/messages/page";
	}

}