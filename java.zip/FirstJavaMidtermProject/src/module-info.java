/**
 * 
 */
/**
 * @author Student
 *
 */
module FirstJavaMidtermProject {
	requires java.sql;
	requires java.sql.rowset;
	requires java.desktop;
}