package ch12._03_annotation._01;

public class MyAnnoMain {
	public static void main(String[] args) {
	}
	@MyAnno(str="Annotation Example", val=100)
	public void myMeth(){
	    //…..
	}

}
