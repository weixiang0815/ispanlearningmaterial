package EEIT157_14_王威翔_第四章作業;

public class Ex7 {

	public static void main(String[] args) {
		String s = "Hello, World, 大家好";
		for(int i = 0; i < s.length(); i ++) {
			System.out.println(s.charAt(i) + " " + (int)s.charAt(i));
		}

	}

}
