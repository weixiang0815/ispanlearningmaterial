package advance;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import system.SystemConstant;

public class InsertImg {
	static String insertBookString = "";
	static String dataFilename = "";
	// C:/Users/Student/Desktop/專題下載檔案/u1_new.csv
	public static void insertAllTable() {
		setSQLCOmmand();
		batchInsert();
	}

	private static void batchInsert() {
		try (Connection conn = DriverManager.getConnection(
				SystemConstant.getDbURL(), 
				SystemConstant.getUser(),
				SystemConstant.getPassword()); 
			PreparedStatement stmt = conn.prepareStatement(insertBookString);
			BufferedReader br = new BufferedReader(
								new InputStreamReader(
								new FileInputStream(dataFilename)));	
		) {
			System.out.println("請輸入");
			System.out.println("現在開始新增紀錄......");
			String line = "";
			while ((line = br.readLine()) != null) {
				String[] sa = line.split(",");
				stmt.setString(1, sa[1]); // 學校名稱
				stmt.setString(2, sa[2]); // 公/私立
				stmt.setString(3, sa[3].substring(sa[3].indexOf(']')+1)); // 縣市名稱
				stmt.setString(4, sa[4].substring(sa[4].indexOf(']')+1)); // 地址
				stmt.setString(5, sa[5]); // 電話
				stmt.setString(6, sa[6]); // 網址
				stmt.setString(7, sa[7].substring(sa[7].indexOf(']')+1)); // 體系別
				stmt.executeUpdate();
			}
			System.out.println("所有紀錄新增成功");
		} catch (SQLException e) {
			System.err.print("存取資料庫時發生例外: " + e);
			e.printStackTrace();
		} catch (IOException e) {
			System.err.print("IO時發生例外: " + e);
			e.printStackTrace();
		}
	}

	private static void setSQLCOmmand() {
		// 新增一筆大專院校名錄紀錄
		insertBookString = " insert into [圖片] " 
						+ " (檔名, 圖片, 副檔名) "
						+ " values (?, ?, ?); ";
	}
}
