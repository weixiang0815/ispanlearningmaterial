package sqlActions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import system.SystemConstant;

public class CreateTable {
	static String dropString = "";
	static String createString = "";
	
	public static void createTable() {
		String dbURL = SystemConstant.getDbURL();
		String user = SystemConstant.getUser();
		String password = SystemConstant.getPassword();
		setSQLCOmmand();

		try (
			Connection conn = DriverManager.getConnection(dbURL, user, password);				
			PreparedStatement stmt1 = conn.prepareStatement(dropString);
			PreparedStatement stmt2 = conn.prepareStatement(createString);
		) {
			System.out.println("現在創建表格......");
		//  執行SQL命令
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			System.out.println("表格創建成功");
		} catch (SQLException e) {
			System.err.print("存取資料庫時發生例外: " + e);
			e.printStackTrace();
			return;
		}
	}
	
	private static void setSQLCOmmand() {
		// 新建Book_JDBC表格
		dropString = " drop table if exists [境外結構型商品發行人/總代理人資訊]; ";
		createString = " create table [境外結構型商品發行人/總代理人資訊] ( "
					+ "	ID int not null primary key identity, "
					+ "	資料日期 date not null, "
					+ "	[發行人/總代理人身分別] nvarchar(50) not null, "
					+ "	境外結構型商品名稱 nvarchar(50) not null, "
					+ "	所屬發行機構 nvarchar(50) not null, "
					+ "	所屬保證機構 nvarchar(50) not null "
					+ "); "; 
	}
}