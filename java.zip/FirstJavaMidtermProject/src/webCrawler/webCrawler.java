package webCrawler;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
 * 	待修改......
 */

public class webCrawler {

	public static void main(String[] args) throws IOException {
		long start_time = System.currentTimeMillis();
		Document doc = Jsoup.connect("https://medium.com/java-magazine-translation/%E7%90%86%E8%A7%A3-java-9-%E7%9A%84%E6%A8%A1%E7%B5%84-4aa30e1c7df9").get();
		System.out.println("網頁標題：\n" + doc.title());
		System.out.println();
//		Elements links = doc.select("a[href]");
//		System.out.println("所有超連結標題：");
//		int i = 1;
//		for (Element el : links) {
//			System.out.println(""+i+". "+el.text()+": "+el.attr("href"));
//			i ++;
//		}
//		System.out.println();
		Elements paragraphs = doc.select("p");
		System.out.println("所有內文");
//		int i = 0;
		for (Element para : paragraphs) {
//			System.out.println((i+1)+".");
//			System.out.println(para.text()+'\n');
//			i ++;
			System.out.println(para.text());
		}
		System.out.println();
		long finish_time = System.currentTimeMillis();
		if(finish_time-start_time >= 1000) {			
			System.out.println("總耗時："+(finish_time-start_time)/1000+"秒又"+(finish_time-start_time)%1000+"毫秒");
		}else {
			System.out.println("總耗時："+(finish_time-start_time)+"毫秒");			
		}
	}

}

