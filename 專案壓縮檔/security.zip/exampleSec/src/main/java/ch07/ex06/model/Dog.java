﻿package ch07.ex06.model;

public class Dog {
	private String breed;
	
	public Dog() {
	}
	public Dog(String breed) {
		this.breed = breed;
	}
	public String getBreed() {
		return breed;
	}
}
