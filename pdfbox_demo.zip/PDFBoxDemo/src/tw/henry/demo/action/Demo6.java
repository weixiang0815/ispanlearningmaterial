package tw.henry.demo.action;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class Demo6 {

	public static void main(String[] args) {
		File file = new File("C:/Users/Student/Desktop/Demo.pdf");
		try (PDDocument doc = PDDocument.load(file);) {
			PDFTextStripper textStripper = new PDFTextStripper();
			String text = textStripper.getText(doc);
			System.out.println("檔案內容：\n---------------------------------------\n" + text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
