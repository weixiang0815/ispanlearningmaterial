package com.tw.henry.controller.search;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Video;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/GetVideoPath.do")
public class GetVideoPath extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		System.out.println(id);
		try (
				ServletOutputStream out = response.getOutputStream();
				) {
			Video video = new VideoDao(ConnectionFactory.getConnection()).getVideoByID(id);
			response.setContentType(getServletContext().getMimeType(video.getFilename()));
			response.setHeader("Content-Disposition", "inline; filename=" + video.getFilename());
//			String filepath = getServletContext().getRealPath(request.getParameter("filepath"));
//			try (FileInputStream fis = new FileInputStream(filepath);
//					BufferedInputStream bis = new BufferedInputStream(fis);) {
//				out.write(bis.readAllBytes());
//			}
			out.write(video.getVideo());
//			response.flushBuffer();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
