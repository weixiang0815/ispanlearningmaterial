package com.tw.henry.controller.search;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Video;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/GetVideos.do")
public class GetVideos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String name = request.getParameter("name");
		List<Video> videos = null;
		String result;
		int size = 0;
		try (Connection conn = ConnectionFactory.getConnection();) {
			if (name == null) {
				videos = new VideoDao(conn).getAllVideos();
			} else {
				videos = new VideoDao(conn).getAllVideosByName(name);
			}
			result = "查詢成功";
			size = videos.size();
			if (size == 0) {
				result = "查無資料";
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "查詢失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("size", size);
		request.setAttribute("videos", videos);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/search/GetVideos.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
