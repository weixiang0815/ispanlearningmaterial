package tw.com.henry.hw.vimy.controller.search;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.Creator;
import tw.com.henry.hw.vimy.model.dao.CreatorDao;

@WebServlet("/GetAllCreatorsByName.do")
public class GetAllCreatorsByName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String name = request.getParameter("nameKeyword");
		List<Creator> crts = null;
		try {
			crts = new CreatorDao(ConnectionFactory.getConnection()).getAllCreatorsByName(name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("crts", crts);
		request.getRequestDispatcher("/page/search/GetMultiCreators.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
