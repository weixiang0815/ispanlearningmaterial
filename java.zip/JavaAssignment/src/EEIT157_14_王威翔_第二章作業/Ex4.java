package EEIT157_14_王威翔_第二章作業;

public class Ex4 {

	public static void main(String[] args) {
		System.out.println((int)('0'));
		System.out.println((int)('A'));
		System.out.println((int)('a'));
		System.out.println((int)('張'));
		System.out.println((int)('君'));
		System.out.println((int)('雅'));

	}

}
