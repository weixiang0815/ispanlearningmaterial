package com.tw.henry.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tw.henry.model.bean.Admin;

public class AdminDao {

	private Connection conn;

	public AdminDao(Connection conn) {
		this.conn = conn;
	}

	/** 
	 * 新增管理員資料
	 */
	public int addNewAdmin(Admin admin) {
		String SQL = "INSERT INTO Admin ("
				+ "name, account, password)"
				+ "VALUES (?, ?, ?)";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, admin.getName());
			stmt.setString(2, admin.getAccount());
			stmt.setString(3, admin.getPassword());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 *  透過 Admin ID 更新管理員資料
	 */
	public int updateAdminByID(Admin admin) {
		String SQL = "UPDATE Admin SET name=?, account=?, password=? WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, admin.getName());
			stmt.setString(2, admin.getAccount());
			stmt.setString(3, admin.getPassword());
			stmt.setString(4, admin.getId());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 	透過 Admin ID 刪除管理員資料
	 */
	public int deleteAdminByID(String id) {
		String SQL = "DELETE * FROM Admin WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 	透過 Admin account 刪除管理員資料
	 */
	public int deleteAdminByAccount(String account) {
		int result = -1;
		deleteAdminByID(getAdminByAccount(account).getId());
		return result;
	}

	/**
	 *  刪除所有管理員資料
	 */
	public int deleteAllAdmins() {
		String SQL = "TRUNCATE TABLE Admin;";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 *  透過 Admin ID 搜尋管理員資料
	 */
	public Admin getAdminByID(int id) {
		String SQL = "SELECT * FROM Admin WHERE id = ?";
		Admin admin = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					admin = new Admin();
					admin.setId(rs.getString("id"));
					admin.setName(rs.getString("name"));
					admin.setAccount(rs.getString("account"));
					admin.setPassword(rs.getString("password"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return admin;
	}

	/**
	 *  透過 Admin account 搜尋管理員資料
	 */
	public Admin getAdminByAccount(String account) {
		String SQL = "SELECT * FROM Admin WHERE account = ?";
		Admin admin = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, account);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					admin = new Admin();
					admin.setId(rs.getString("id"));
					admin.setName(rs.getString("name"));
					admin.setAccount(rs.getString("account"));
					admin.setPassword(rs.getString("password"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return admin;
	}
	
	/**
	 *  搜尋所有管理員資料
	 */
	public List<Admin> getAllAdmins() {
		String SQL = "SELECT * FROM Admin;";
		List<Admin> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while (rs.next()) {
					Admin admin = new Admin();
					admin.setId(rs.getString("id"));
					admin.setName(rs.getString("name"));
					admin.setAccount(rs.getString("account"));
					admin.setPassword(rs.getString("password"));
					list.add(admin);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 *  透過 Admin name 對管理員進行模糊搜尋
	 */
	public List<Admin> getAllAdminsByName(String name) {
		String SQL = "SELECT * FROM Admin WHERE name LIKE '%" + name + "%'";
		List<Admin> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while (rs.next()) {
					Admin admin = new Admin();
					admin.setId(rs.getString("id"));
					admin.setName(rs.getString("name"));
					admin.setAccount(rs.getString("account"));
					admin.setPassword(rs.getString("password"));
					list.add(admin);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
