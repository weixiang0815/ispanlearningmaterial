package com.example.demo.websocket._03.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import com.example.demo.websocket._03.model.Greeting;
import com.example.demo.websocket._03.model.HelloMessage;

@Controller
public class MessageSendingController {

	@Autowired
	private SimpMessagingTemplate template;
	
	@MessageMapping("/queryTime")
	@SendTo("/topic/greetings")
	public void queryTime(HelloMessage message) throws Exception {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for(int n = 0 ; n < 5 ; n++) {
			Date d = new Date();
			template.convertAndSend("/topic/greetings", new Greeting(sdf.format(d)));
			Thread.sleep(1000);
		}
		template.convertAndSend("/topic/greetings", new Greeting("訊息已傳送完畢..."));
	}

}
