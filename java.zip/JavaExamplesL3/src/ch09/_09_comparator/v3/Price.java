package ch09._09_comparator.v3;

public interface Price {
    int getPrice();
}
