package tw.hibernatedemo.action;

import java.util.LinkedHashSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import tw.hibernatedemo.model.Book;
import tw.hibernatedemo.model.BookUser;
import tw.hibernatedemo.util.HibernateUtil;

public class DemoOneToManyActionEx1 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.beginTransaction();

			// new BookUser
			BookUser user1 = new BookUser();
			user1.setUserName("館長");

			// new Book
			Book book1 = new Book();
			book1.setBooktitle("Java 王者歸來");
			book1.setPublicYear("2023-01");

			// new Book
			Book book2 = new Book();
			book2.setBooktitle("SQL 100 種解法");
			book2.setPublicYear("2022-10");

			// book set user
			book1.setBookUser(user1);
			book2.setBookUser(user1);

			// book 裝到 set
			LinkedHashSet<Book> books = new LinkedHashSet<Book>();
			books.add(book1);
			books.add(book2);

			// user set book
			user1.setBooks(books);

			// save 有 cascade 連動的一邊
			session.save(user1);

			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("ROLLBACK!!!");
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			HibernateUtil.closeSessionFactory();
		}
	}

}
