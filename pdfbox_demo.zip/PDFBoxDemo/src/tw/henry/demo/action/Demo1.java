package tw.henry.demo.action;

import org.apache.pdfbox.pdmodel.PDDocument;

public class Demo1 {

	public static void main(String[] args) {
		try (PDDocument doc = new PDDocument();) {
			doc.save("C:/Users/Student/Desktop/demo.pdf");
			System.out.println("產生一個 PDF 檔");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
