package tw.ispan.action;

import tw.ispan.model.Book;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo5BookStaticFactoryAction {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Book book1 = context.getBean("javaBook", Book.class);
		System.out.println("book1 name: " + book1.getBookName());
		
		Book book2 = context.getBean("mathBook", Book.class);
		System.out.println("book2 name: " + book2.getBookName());
		
		context.close();
	}

}
