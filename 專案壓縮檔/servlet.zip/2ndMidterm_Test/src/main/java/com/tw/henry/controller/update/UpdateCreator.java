package com.tw.henry.controller.update;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Creator;
import com.tw.henry.model.dao.CreatorDao;

@WebServlet("/UpdateCreator.do")
@MultipartConfig
public class UpdateCreator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		Part part = request.getPart("thumbnail_update");
		String result;
		Creator crt;
		CreatorDao creatorDao;
		try (Connection conn = ConnectionFactory.getConnection())  {
			crt = new Creator();
			creatorDao = new CreatorDao(conn);
			crt.setId(request.getParameter("id"));
			crt.setName(request.getParameter("name"));
			crt.setAccount(request.getParameter("account"));
			crt.setPassword(request.getParameter("password"));
			if (part == null || part.getSubmittedFileName().contentEquals("")) {
				crt.setThumbnail(creatorDao.getCreatorByID(crt.getId()).getThumbnail());
			} else {
				crt.setThumbnail(part.getInputStream().readAllBytes());
			}
			crt.setGender(request.getParameter("gender"));
			crt.setBirthday(request.getParameter("birthday"));
			crt.setUploadCount(request.getParameter("uploadCount"));
			crt.setCountry(request.getParameter("country"));
			crt.setInfo(request.getParameter("info"));
			crt.setOneSocialAccount("Facebook", request.getParameter("fb_account"));
			crt.setOneSocialAccount("Google", request.getParameter("google_account"));
			crt.setOneSocialAccount("Twitter", request.getParameter("twitter_account"));
			crt.setOneSocialAccount("Instagram", request.getParameter("ig_account"));
			result = creatorDao.updateCreatorByID(crt);
			request.setAttribute("crt", crt);			
		} catch (Exception e) {
			e.printStackTrace();
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/update/UpdateCreator.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
