package tw.hibernatedemo.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class GoodPhotoDao {

	@Autowired
	private SessionFactory factory;

//	public GoodPhotoDao(SessionFactory factory) {
//		this.factory = factory;
//	}

	public GoodPhoto saveGoodPhoto(GoodPhoto gp) {
		Session session = factory.getCurrentSession();
		session.save(gp);
		return gp;
	}

	public GoodPhoto getPhotoById(Integer id) {
		Session session = factory.getCurrentSession();
		return session.get(GoodPhoto.class, id);
	}

	public List<GoodPhoto> getAllPhoto() {
		Session session = factory.getCurrentSession();
		String queryStr = "FROM GoodPhoto";
		return session.createQuery(queryStr, GoodPhoto.class).getResultList();
	}
}