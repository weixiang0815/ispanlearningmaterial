package com.iSpan.springbootdemo2.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.iSpan.springbootdemo2.model.House;
import com.iSpan.springbootdemo2.model.HousePhoto;
import com.iSpan.springbootdemo2.model.HousePhotoRepository;
import com.iSpan.springbootdemo2.model.HouseRepository;

@Controller
public class HouseController {

	@Autowired
	private HouseRepository houseDao;

	@Autowired
	private HousePhotoRepository housePhotoDao;

	@GetMapping("/house/add")
	public String goUploadPage() {
		return "house/uploadPage";
	}

	@ResponseBody
	@PostMapping("/house/api/post")
	public String postHouseImage(@RequestParam("houseName") String houseName,
			@RequestParam("file") MultipartFile[] files) throws IOException {
		House house = new House();
		house.setHouseName(houseName);
		List<HousePhoto> listPhoto = new LinkedList<>();
		for (MultipartFile file : files) {
			HousePhoto housePhoto = new HousePhoto();
			housePhoto.setPhotoFile(file.getBytes());
			housePhoto.setHouse(house); // many set one 這個容易忘記（1 set 多，多也要 set 1）
			listPhoto.add(housePhoto);
		}
		house.setHousePhoto(listPhoto); // one set many
		houseDao.save(house);
		return "OKOK";
	}

	@GetMapping("/house/listPage")
	public String listHouse(Model model) {
		List<House> houseList = houseDao.findAll();
		model.addAttribute("houseList", houseList);
		return "house/listHousePage";
	}

	@ResponseBody
	@GetMapping("/house/api/housePhoto")
	public ResponseEntity<byte[]> getHousePhotoById(@RequestParam Integer id) {
		Optional<HousePhoto> optional = housePhotoDao.findById(id);
		if (optional.isEmpty()) {
			return null;
		}
		HousePhoto housePhoto = optional.get();
		byte[] photoFile = housePhoto.getPhotoFile();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_JPEG);
		return new ResponseEntity<byte[]>(photoFile, headers, HttpStatus.OK);
	}

	@ResponseBody
	@GetMapping("/house/api/house-get-photos")
	public List<Integer> getPhotoIdsByHouseId(@RequestParam Integer houseId) {
		Optional<House> optional = houseDao.findById(houseId);
		if (optional.isEmpty()) {
			return null;
		}
		House house = optional.get();
		List<HousePhoto> listHousePhoto = house.getHousePhoto();
		List<Integer> photoIds = new ArrayList<>();
		listHousePhoto.forEach(hp -> photoIds.add(hp.getId()));
		return photoIds;
	}

}