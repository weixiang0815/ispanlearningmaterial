package EEIT157_14_王威翔_第三章作業;
import java.util.Scanner;

public class Ex4 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String s1 = s.nextLine(), s2 = s.nextLine(), s3 = s.nextLine();
		s.close();
		
		System.out.println("第1個字串長度：" + s1.length());
		System.out.println("第2個字串長度：" + s2.length());
		System.out.println("第3個字串長度：" + s3.length());

	}

}
