package tw.ispan.model;

public interface Teacher {

	public void teach(String content);

}
