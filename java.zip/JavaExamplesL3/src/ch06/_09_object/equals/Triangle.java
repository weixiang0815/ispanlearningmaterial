package ch06._09_object.equals;

public class Triangle {

}
