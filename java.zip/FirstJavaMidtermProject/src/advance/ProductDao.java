package advance;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {

	// 新增單筆產品紀錄
	void save(ProductBean bean) throws SQLException;

	// 依鍵值刪除單筆產品紀錄
	void deleteById(int key) throws SQLException;
	
	// 刪除所有紀錄
	void deleteAll() throws SQLException;
	
	// 修改單筆產品紀錄
	void update(ProductBean bean) throws SQLException;

	// 查詢所有產品紀錄
	List<ProductBean> findAll() throws SQLException;

	// 查詢所有產品紀錄
	List<ProductBean> findAllByTitle(String title, String keyin) throws SQLException;
	
	// 依鍵值查詢單筆產品紀錄
	ProductBean findById(int key) throws SQLException;
	
	// 依表頭查詢單筆產品紀錄
	ProductBean findBytitle(String title, String keyin) throws SQLException;

	// 模糊搜尋
	List<ProductBean> fuzzySearch(String title, String keyword) throws SQLException;
}