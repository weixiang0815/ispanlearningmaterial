package tw.com.henry.hw.vimy.model.bean;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class VideoBean implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String name;
	private String thumbnail;
	private int size;
	private String filepath;
	private String filetype;
	private byte[] video;
	private String info;
	private int creator;

	public VideoBean() {
	}

	public VideoBean(int id, String name, String thumbnail, String filepath, String info, int creator) {
		setId(id);
		setName(name);
		setThumbnail(thumbnail);
		setVideo(filepath);
		setInfo(info);
		setCreator(creator);
	}

	public VideoBean(int id, String name, String thumbnail, byte[] video, String info, int creator) {
		setId(id);
		setName(name);
		setThumbnail(thumbnail);
		setVideo(video);
		setInfo(info);
		setCreator(creator);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFilepath() {
		return filepath;
	}

	private void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getFiletype() {
		return filetype;
	}

	private void setFiletype(String filepath) {
		filetype = filepath.substring(filepath.lastIndexOf(".") + 1);
	}

	public int getCreator() {
		return creator;
	}

	public void setCreator(int creator) {
		this.creator = creator;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public int getSize() {
		return size;
	}

	private void setSize(byte[] video) {
		size = video.length;
	}

	public byte[] getVideo() {
		return video;
	}

	public void setVideo(byte[] video) {
		this.video = video;
		filepath = "unknown";
		filetype = "unknown";
		try (FileInputStream fis = new FileInputStream(filepath);
				BufferedInputStream bis = new BufferedInputStream(fis);) {
			video = bis.readAllBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}
		setSize(video);
	}

	public void setVideo(String filepath) {
		setFilepath(filepath);
		setFiletype(filepath);
		try (FileInputStream fis = new FileInputStream(filepath);
				BufferedInputStream bis = new BufferedInputStream(fis);) {
			video = bis.readAllBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}
		setSize(video);
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	@Override
	public String toString() {
		StringBuilder output = new StringBuilder("這部影片的資訊：\n");
		output.append("片名：" + name + '\n');
		output.append("大小：" + size + " bytes\n");
		output.append("創作者：" + creator + '\n');
		output.append("檔案類型：" + filetype + '\n');
		output.append("影片路徑：" + filepath + '\n');
		output.append("簡介：\n" + info);
		return output.toString();
	}
}