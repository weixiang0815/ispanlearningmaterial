package com.tw.henry.controller.user;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Admin;
import com.tw.henry.model.dao.AdminDao;

@WebServlet("/AdminLogin.do")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		HttpSession session = request.getSession(true);
		String account = request.getParameter("account");
		String password = request.getParameter("password");
		String result;
		Admin admin = null;
		try (Connection conn = ConnectionFactory.getConnection()) {
			admin = new AdminDao(conn).getAdminByAccount(account);
			if (admin == null) {
				result = "查無此帳號：" + account;
			} else {
				if (!password.contentEquals(admin.getPassword())) {
					result = "密碼輸入錯誤：" + password;
					admin = null;
				} else {
					session.setAttribute("user_name", admin.getName());
					result = "管理員登入成功";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = e.getMessage();
		}
//		response.getWriter().write(result);
//		request.setAttribute("result", result);
//		request.setAttribute("admin", admin);
		session.setAttribute("result", result);
		session.setAttribute("admin", admin);
//		response.sendRedirect("/2ndMidterm_Test/page/user/AdminInfo.jsp");
		request.getRequestDispatcher("/page/user/AdminInfo.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
