package ch02.lab01.solution;

public class AnotherProgram {
	public static void main(String[] args) {
		System.out.println("請更正此程式(Ch02Lab01)的錯誤");
	}
}
