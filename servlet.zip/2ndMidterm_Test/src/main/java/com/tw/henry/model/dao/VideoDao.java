package com.tw.henry.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Creator;
import com.tw.henry.model.bean.Video;

public class VideoDao {

	private Connection conn;

	public VideoDao(Connection conn) {
		this.conn = conn;
	}

	/**
	 *  新增影片資料
	 */
	public String addNewVideo(Video video) {
		String SQL = "INSERT INTO Video ("
					+ "name, thumbnail, size, filename,"
					+ "filetype, video, info, creatorID, creatorName)"
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, video.getName());
			String image = video.getThumbnail().substring("data:image/jpeg;base64,".length());
			byte[] decoded_image = Base64.getDecoder().decode(image.getBytes("UTF-8"));
			stmt.setBytes(2, decoded_image);
			stmt.setInt(3, video.getSize());
			stmt.setString(4, video.getFilename());
			stmt.setString(5, video.getFiletype());
			stmt.setBytes(6, video.getVideo());
			stmt.setString(7, video.getInfo());
			stmt.setString(8, video.getCreatorId());
			stmt.setString(9, video.getCreatorName());
			stmt.executeUpdate();
			result = "上傳成功";
			new CreatorDao(ConnectionFactory.getConnection()).updateUploadCountByID(video.getCreatorId());
		} catch (Exception e) {
			e.printStackTrace();
			result = "上傳失敗：" + e.getMessage();
		}
		return result;
	}

	/**
	 *  透過 Video ID 更新影片資料
	 */
	public int updateVideo(Video video) {
		String SQL = "UPDATE Video SET name=?, thumbnail=?, size=?, filename=?,"
					+ "filetype=?, video=?, info=?, creatorID=?, creatorName=? WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, video.getName());
			byte[] decoded_image = Base64.getDecoder()
					.decode(new String(video.getThumbnail()).getBytes("UTF-8"));
			stmt.setBytes(2, decoded_image);
			stmt.setInt(3, video.getSize());
			stmt.setString(4, video.getFilename());
			stmt.setString(5, video.getFiletype());
			stmt.setBytes(6, video.getVideo());
			stmt.setString(7, video.getInfo());
			stmt.setString(8, video.getCreatorId());
			stmt.setString(9, video.getCreatorName());
			stmt.setString(10, video.getId());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 	透過 Video ID 刪除影片資料
	 */
	public String deleteVideoByID(String id, String creatorId) {
		String SQL = "DELETE * FROM Video WHERE id = ?";
		String result;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			stmt.executeUpdate();
			result = "刪除成功";
			new CreatorDao(ConnectionFactory.getConnection()).updateUploadCountByID(creatorId);
		} catch (Exception e) {
			e.printStackTrace();
			result = "刪除失敗：" + e.getMessage();
		}
		return result;
	}

	/**
	 *  刪除所有影片資料
	 */
	public int deleteAllVideos() {
		String SQL = "TRUNCATE TABLE Video;";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 *  透過 Video ID 搜尋影片資料
	 */
	public Video getVideoByID(String id) {
		String SQL = "SELECT * FROM Video WHERE id = ?";
		Video video = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					video = new Video();
					video.setId(rs.getString("id"));
					video.setName(rs.getString("name"));
					video.setThumbnail(rs.getBytes("thumbnail"));
					video.setSize(rs.getInt("size"));
					video.setFilename(rs.getString("filename"));
					video.setFilename(rs.getString("filetype"));
					video.setVideo(rs.getBytes("video"));
					video.setInfo(rs.getString("info"));
					video.setCreatorId(rs.getString("creator"));
					video.setCreatorName(new CreatorDao(ConnectionFactory.getConnection())
							.getCreatorByID(video.getCreatorId()).getName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return video;
	}

	/**
	 *  搜尋所有影片資料
	 */
	public List<Video> getAllVideos() {
		String SQL = "SELECT * FROM Video;";
		List<Video> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				Video video = null;
				while (rs.next()) {
					video = new Video();
					video.setId(rs.getString("id"));
					video.setName(rs.getString("name"));
					video.setThumbnail(rs.getBytes("thumbnail"));
					video.setSize(rs.getInt("size"));
					video.setFilename(rs.getString("filename"));
					video.setFilename(rs.getString("filetype"));
					video.setVideo(rs.getBytes("video"));
					video.setInfo(rs.getString("info"));
					video.setCreatorId(rs.getString("creator"));
					video.setCreatorName(new CreatorDao(ConnectionFactory.getConnection())
							.getCreatorByID(video.getCreatorId()).getName());
					list.add(video);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 *  透過 Video name 進行模糊搜尋
	 */
	public List<Video> getAllVideosByName(String name) {
		String SQL = "SELECT * FROM Video WHERE name LIKE '%" + name + "%'";
		List<Video> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				Video video = null;
				while (rs.next()) {
					video = new Video();
					video.setId(rs.getString("id"));
					video.setName(rs.getString("name"));
					video.setThumbnail(rs.getBytes("thumbnail"));
					video.setSize(rs.getInt("size"));
					video.setFilename(rs.getString("filename"));
					video.setFilename(rs.getString("filetype"));
					video.setVideo(rs.getBytes("video"));
					video.setInfo(rs.getString("info"));
					video.setCreatorId(rs.getString("creator"));
					video.setCreatorName(new CreatorDao(ConnectionFactory.getConnection())
							.getCreatorByID(video.getCreatorId()).getName());
					list.add(video);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 *  透過 Video CreatorId 搜尋創作者資料
	 */
	public Creator getCreatorByCreatorId(String id) {
		String SQL = "SELECT * FROM Creator AS c JOIN Video AS v ON v.creator = c.id AND v.creator = ?";
		Creator crt = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					crt = new Creator();
					crt.setId(rs.getString("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getString("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getString("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setOneSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setOneSocialAccount("Google", rs.getString("google_account"));
					crt.setOneSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setOneSocialAccount("Instagram", rs.getString("ig_account"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return crt;
	}

}
