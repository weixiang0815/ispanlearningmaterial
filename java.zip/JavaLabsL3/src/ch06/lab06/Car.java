package ch06.lab06;

public class Car {

}
