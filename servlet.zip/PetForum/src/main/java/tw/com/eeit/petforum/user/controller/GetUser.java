package tw.com.eeit.petforum.user.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.eeit.petforum.conn.ConnectionFactory;
import tw.com.eeit.petforum.user.model.bean.Users;

@WebServlet("/GetUser.do")
public class GetUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String uID = request.getParameter("uID");
		String sql = "SELECT * FROM [PetForum].[dbo].[Users] WHERE id = ?;";
		try (
				Connection conn = ConnectionFactory.getConnection();
				PreparedStatement preState = conn.prepareStatement(sql);
				PrintWriter out = response.getWriter();
			) {
			Users u = new Users();
			preState.setString(1, uID);
			try (ResultSet rs = preState.executeQuery();) {
				if (rs.next()) {
					u.setAccount(rs.getString("account"));
					u.setId(rs.getString("id"));
					u.setPhoto(rs.getString("photo"));
				}
			}
			request.setAttribute("user", u);
			request.getRequestDispatcher("pages/showUser.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
