package advance;

import java.io.Serializable;

public class ProductBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer Id;
	private String schoolName;
	private String pubOrPriv;
	private String region;
	private String address;
	private String phone;
	private String url;
	private String system;
	
	
	
	public ProductBean(Integer id, String schoolName, String pubOrPriv, String region, String address, String phone,
			String url, String system) {
		super();
		Id = id;
		this.schoolName = schoolName;
		this.pubOrPriv = pubOrPriv;
		this.region = region;
		this.address = address;
		this.phone = phone;
		this.url = url;
		this.system = system;
	}



	public Integer getId() {
		return Id;
	}



	public void setId(Integer id) {
		Id = id;
	}



	public String getSchoolName() {
		return schoolName;
	}



	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}



	public String getPubOrPriv() {
		return pubOrPriv;
	}



	public void setPubOrPriv(String pubOrPriv) {
		this.pubOrPriv = pubOrPriv;
	}



	public String getRegion() {
		return region;
	}



	public void setRegion(String region) {
		this.region = region;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}



	public String getUrl() {
		return url;
	}



	public void setUrl(String url) {
		this.url = url;
	}



	public String getSystem() {
		return system;
	}



	public void setSystem(String system) {
		this.system = system;
	}



	@Override
	public String toString() {
		return "大專院校名錄 [代碼=" + Id + ", 學校名稱=" + schoolName + ", 公/私立=" + pubOrPriv + ", 縣市名稱="
				+ region + ", 地址=" + address + ", 電話=" + phone + ", 網址=" + url + ", 體系別=" + system + "]";
	}
}