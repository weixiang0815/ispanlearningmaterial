package ch06._03_method.rv;

import java.util.Date;

public class Message {
    String msg;
    int code;
    Date now;
}
