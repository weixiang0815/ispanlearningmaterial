package com.iSpan;

import java.io.BufferedReader;
import java.io.FileReader;

import weka.clusterers.EM;
import weka.core.Instances;

public class Clustering {

	public static void main(String[] args) throws Exception {
		Instances data = new Instances(new BufferedReader(new FileReader("data/bank-data.arff")));
		EM model = new EM();
		model.buildClusterer(data);
		System.out.println(model);
	}

}