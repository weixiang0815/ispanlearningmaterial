package EEIT157_14_王威翔_第九章作業;

import java.util.ArrayList;
import java.util.Collections;

public class Ex3 {

	public static void main(String[] args) {
		ArrayList<Double> ad = new ArrayList<>();
		ad.add(98d);
		ad.add(12.345);
		ad.add(97.85);
		ad.add(12d);
		Collections.sort(ad);
		ad.forEach(d -> System.out.print(d + " "));
	}

}
