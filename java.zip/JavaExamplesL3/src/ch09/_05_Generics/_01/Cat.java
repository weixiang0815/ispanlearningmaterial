package ch09._05_Generics._01;

public class Cat {
	@Override
	public String toString() {
		return "我是Cat類別的物件";
	}
	
}
