package tw.com.henry.hw.vimy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import tw.com.henry.hw.vimy.model.bean.CreatorBean;
import tw.com.henry.hw.vimy.model.bean.VideoBean;

public class CreatorDao {

	private Connection conn;

	public CreatorDao(Connection conn) {
		this.conn = conn;
	}

	// 新增創作者資料
	public int addNewCreator(CreatorBean crt) {
		String SQL = "INSERT INTO Creator (id, name, account, password, thumbnail, gender, birthday, uploadCount,"
					+ "country, info, fb_account, google_account, twitter_account, ig_account)"
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, crt.getId());
			stmt.setString(2, crt.getName());
			stmt.setString(3, crt.getAccount());
			stmt.setString(4, crt.getPassword());
			stmt.setString(5, crt.getThumbnail());
			stmt.setString(6, crt.getGender());
			stmt.setString(7, crt.getBirthday());
			stmt.setInt(8, crt.getUploadCount());
			stmt.setString(9, crt.getCountry());
			stmt.setString(10, crt.getInfo());
			stmt.setString(11, crt.getSocialAccount().get("Facebook"));
			stmt.setString(12, crt.getSocialAccount().get("Google"));
			stmt.setString(13, crt.getSocialAccount().get("Twitter"));
			stmt.setString(14, crt.getSocialAccount().get("Instagram"));
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 透過ID更新創作者資料
	public int updateCreatorByID(CreatorBean crt) {
		String SQL = "UPDATE Creator SET"
					+ "name=?, account=?, password=?, thumbnail=?, gender=?, birthday=?, uploadCount=?,"
					+ "country=?, info=?, fb_account=?, google_account=?, twitter_account=?, ig_account=?"
					+ "WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, crt.getName());
			stmt.setString(2, crt.getAccount());
			stmt.setString(3, crt.getPassword());
			stmt.setString(4, crt.getThumbnail());
			stmt.setString(5, crt.getGender());
			stmt.setString(6, crt.getBirthday());
			stmt.setInt(7, crt.getUploadCount());
			stmt.setString(8, crt.getCountry());
			stmt.setString(9, crt.getInfo());
			stmt.setString(10, crt.getSocialAccount().get("Facebook"));
			stmt.setString(11, crt.getSocialAccount().get("Google"));
			stmt.setString(12, crt.getSocialAccount().get("Twitter"));
			stmt.setString(13, crt.getSocialAccount().get("Instagram"));
			stmt.setInt(14, crt.getId());
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 可以寫很長的註解
	 * 
	 * @param crtno 創作者編號
	 * 
	 * @return int 成功或失敗的結果，1為成功
	 */
	public int deleteCreatorByID(int id) {
		String SQL = "DELETE * FROM Creator WHERE id = ?";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	// 刪除所有創作者資料
	public int deleteAllCreators() {
		String SQL = "TRUNCATE TABLE Creator;";
		int result = -1;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 透過ID搜尋創作者資料
	public CreatorBean getCreatorByID(int id) {
		String SQL = "SELECT * FROM Creator WHERE id = ?";
		CreatorBean crt = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					crt = new CreatorBean();
					crt.setId(rs.getInt("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getString("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getInt("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setSocialAccount("Google", rs.getString("google_account"));
					crt.setSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setSocialAccount("Instagram", rs.getString("ig_account"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return crt;
	}

	// 透過account搜尋創作者資料
	public CreatorBean getCreatorByAccount(String account) {
		String SQL = "SELECT * FROM Creator WHERE account = ?";
		CreatorBean crt = null;
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setString(1, account);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					crt = new CreatorBean();
					crt.setId(rs.getInt("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getString("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getInt("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setSocialAccount("Google", rs.getString("google_account"));
					crt.setSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setSocialAccount("Instagram", rs.getString("ig_account"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return crt;
	}
	
	// 搜尋所有創作者資料
	public List<CreatorBean> getAllCreators() {
		String SQL = "SELECT * FROM Creator;";
		List<CreatorBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while(rs.next()) {
					CreatorBean crt = new CreatorBean();
					crt.setId(rs.getInt("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getString("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getInt("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setSocialAccount("Google", rs.getString("google_account"));
					crt.setSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setSocialAccount("Instagram", rs.getString("ig_account"));
					list.add(crt);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// 透過姓名進行模糊搜尋
	public List<CreatorBean> getAllCreatorsByName(String name) {
		String SQL = "SELECT * FROM Creator WHERE name LIKE '%" + name +"%'";
		List<CreatorBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			try (ResultSet rs = stmt.executeQuery();) {
				while(rs.next()) {
					CreatorBean crt = new CreatorBean();
					crt.setId(rs.getInt("id"));
					crt.setName(rs.getString("name"));
					crt.setAccount(rs.getString("account"));
					crt.setPassword(rs.getString("password"));
					crt.setThumbnail(rs.getString("thumbnail"));
					crt.setGender(rs.getString("gender"));
					crt.setBirthday(rs.getString("birthday"));
					crt.setUploadCount(rs.getInt("uploadCount"));
					crt.setCountry(rs.getString("country"));
					crt.setInfo(rs.getString("info"));
					crt.setSocialAccount("Facebook", rs.getString("facebook_account"));
					crt.setSocialAccount("Google", rs.getString("google_account"));
					crt.setSocialAccount("Twitter", rs.getString("twitter_account"));
					crt.setSocialAccount("Instagram", rs.getString("ig_account"));
					list.add(crt);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// 透過創作者ID搜尋作品資料
	public List<VideoBean> getVideoByCreatorID(int id) {
		String SQL = "SELECT * FROM Video AS v JOIN creator AS c ON v.creator = c.id AND v.creator = ?";
		List<VideoBean> list = new ArrayList<>();
		try (PreparedStatement stmt = conn.prepareStatement(SQL);) {
			stmt.setInt(1, id);
			try (ResultSet rs = stmt.executeQuery();) {
				VideoBean video = null;
				if (rs.next()) {
					video = new VideoBean();
					video.setId(rs.getInt("id"));
					video.setName(rs.getString("name"));
					video.setThumbnail(rs.getString("thumbnail"));
					video.setVideo(rs.getBytes("video"));
					video.setInfo(rs.getString("info"));
					video.setCreator(rs.getInt("creator"));
					list.add(video);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}