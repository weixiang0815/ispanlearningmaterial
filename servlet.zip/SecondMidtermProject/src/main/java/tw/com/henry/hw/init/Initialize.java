package tw.com.henry.hw.init;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import tw.com.henry.hw.conn.ConnectionFactory;

@WebListener
public class Initialize implements ServletContextListener {

	private String realPath = "";

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		realPath = sce.getServletContext().getRealPath("");
		try (Connection conn = ConnectionFactory.getConnection()) {
			createDB(conn); // 建立資料庫
			createCreatorTableAndInsertData(conn); // 建立Creator資料表並加入預設值
			createVideoTableAndInsertData(conn); // 建立Video資料表並加入預設值
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createDB(Connection conn) {
		// 如果VideoForum資料庫不存在，則建立VideoForum資料庫
		String SQL = "IF DB_ID('Vimy') IS NULL CREATE DATABASE Vimy";
		try (Statement state = conn.createStatement();) {
			state.execute(SQL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createCreatorTableAndInsertData(Connection conn) throws Exception {
		String SQL = "IF OBJECT_ID('[Vimy].[dbo].[Creator]') IS NULL CREATE TABLE [Vimy].[dbo].[Creator](id nvarchar(10) PRIMARY KEY NOT NULL, account NVARCHAR(50) NOT NULL, password NVARCHAR(50) NOT NULL, photo NVARCHAR(MAX), level NVARCHAR(10) NOT NULL)";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();

		// 如果Creator資料表中有任何一筆資料，則終止此方法。
		if (conn.createStatement().executeQuery("SELECT id FROM [VideoForum].[dbo].[Creator]").next()) {
			return;
		}

		// 使用Gson、JavaIO，讀取webapp/forInit/Creator.json的資料
		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Creator.json"));
		List<Creator> CreatorList = new Gson().fromJson(br, new TyVideooken<List<Creator>>() {
		}.getType());
		br.close();

		SQL = "INSERT INTO [VideoForum].[dbo].[Creator](id, account, password, level, photo) VALUES (?, ?, ?, ?, ?)";

		// 新增資料到資料表
		PreparedStatement preState = conn.prepareStatement(SQL);
		for (Creator u : CreatorList) {
			preState.setString(1, u.getId());
			preState.setString(2, u.getAccount());
			preState.setString(3, u.getPassword());
			preState.setString(4, u.getLevel());
			preState.setString(5, u.getPhoto());
			preState.addBatch();
		}
		preState.executeBatch();
		preState.close();
	}

	private void createVideoTableAndInsertData(Connection conn) throws Exception {
		// 如果Video資料表不存在，則建立Video資料表
		String SQL = "IF OBJECT_ID('[VideoForum].[dbo].[Video]') IS NULL CREATE TABLE [VideoForum].[dbo].[Video](id INT IDENTITY(1,1) PRIMARY KEY NOT NULL, nickName NVARCHAR(50), type NVARCHAR(50) NOT NULL, age INT, photo VARBINARY(MAX), ownerID NVARCHAR(10), FOREIGN KEY (ownerID) REFERENCES [VideoForum].[dbo].[Creator](id))";
		Statement state = conn.createStatement();
		state.execute(SQL);
		state.close();

		// 如果Video資料表中有任何一筆資料，則終止此方法。
		if (conn.createStatement().executeQuery("SELECT id FROM [VideoForum].[dbo].[Video]").next()) {
			return;
		}

		// 使用Gson、JavaIO，讀取webapp/forInit/Video.json的資料
		BufferedReader br = new BufferedReader(new FileReader(realPath + "forInit/Video.json"));
		List<Video> VideoList = new Gson().fromJson(br, new TyVideooken<List<Video>>() {
		}.getType());
		br.close();

		// 新增資料到資料表
		SQL = "INSERT INTO [VideoForum].[dbo].[Video](nickName, type, age, photo, ownerID) VALUES (?, ?, ?, ?, ?)";
		PreparedStatement preState = conn.prepareStatement(SQL);
		for (Video p : VideoList) {
			BufferedInputStream bis = new BufferedInputStream(
					new FileInputStream(realPath + "forInit/VideosIMG/" + p.getNickName() + ".jpg"));
			byte[] bytes = bis.readAllBytes();
			preState.setString(1, p.getNickName());
			preState.setString(2, p.getType());
			preState.setInt(3, p.getAge());
			preState.setBytes(4, bytes);
			preState.setString(5, p.getOwnerID());
			preState.addBatch();
			bis.close();
		}
		preState.executeBatch();
		preState.close();
	}
}
