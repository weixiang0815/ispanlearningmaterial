package EEIT157_14_王威翔_第七章作業;

/*
 *	訊息輸出說明：
 *	執行本類別時，會先由上到下執行每個靜態區塊，接著進入main方法；
 *	main方法中，先宣告本類別的參考函數，因而呼叫本類別建構子，接著輸出println裡的訊息。
 *	
 *	因此，本類別執行後的輸出結果為：
 *	訊息A
 *	訊息B訊息C
 *	建構子訊息
 *	HaHaHa
 */

public class Ex1 {
	static {
		System.out.println("訊息A");
	}
	
	Ex1(){
		System.out.println("建構子訊息");
	}
	
	static {
		System.out.println("訊息B");
	}

	public static void main(String[] args) {
		Ex1 con = new Ex1();
		System.out.println("HaHaHa");
	}
	
	static {
		System.out.println("訊息C");
	}
}
