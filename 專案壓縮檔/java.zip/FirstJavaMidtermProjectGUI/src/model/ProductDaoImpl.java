package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exception.ProductNotFoundException;
import system.SystemConstant;

public class ProductDaoImpl implements ProductDao {
	public ProductDaoImpl() {
	}

	@Override
	public void save(ProductBean productBean) throws SQLException {
		String sql = " insert into [大專校院名錄] " + " (學校名稱, [公/私立] " + ", 縣市名稱, 地址" + ", 電話, 網址, 體系別) " + " values "
				+ " (?, ?, ?, ?, ?, ?, ?); ";

		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.setString(1, productBean.getSchoolName());
			stmt.setString(2, productBean.getPubOrPriv());
			stmt.setString(3, productBean.getRegion());
			stmt.setString(4, productBean.getAddress());
			stmt.setString(5, productBean.getPhone());
			stmt.setString(6, productBean.getUrl());
			stmt.setString(7, productBean.getSystem());
			stmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public void deleteAll() throws SQLException {
		String sql = " truncate table [大專校院名錄]; ";
		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.executeUpdate();
		}
	}

	@Override
	public void deleteById(int key) throws SQLException {
		String sql = " DELETE FROM [大專校院名錄] WHERE 代碼 = ?; ";
		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.setInt(1, key);

			int n = stmt.executeUpdate();
			if (n == 0) {
				throw new ProductNotFoundException("該紀錄不存在，key = " + key);
			}
		}
	}

	@Override
	public void update(ProductBean productBean) throws SQLException {
		String sql = " UPDATE 大專校院名錄 SET 學校名稱 = ?, [公/私立] = ?, 縣市名稱 = ?, 地址 = ?, 電話 = ?, 網址 = ?, 體系別 = ? "
				+ " WHERE 代碼 = ? ";

		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.setInt(8, productBean.getId());
			stmt.setString(1, productBean.getSchoolName());
			stmt.setString(2, productBean.getPubOrPriv());
			stmt.setString(3, productBean.getRegion());
			stmt.setString(4, productBean.getAddress());
			stmt.setString(5, productBean.getPhone());
			stmt.setString(6, productBean.getUrl());
			stmt.setString(7, productBean.getSystem());
			int n = stmt.executeUpdate();
			if (n == 0) {
				throw new RuntimeException("該紀錄不存在，key = " + productBean.getId());
			}
		}
	}

	@Override
	public List<ProductBean> findAll() throws SQLException {
		String sql = " SELECT * FROM [大專校院名錄]; ";
		ProductBean productBean = null;
		List<ProductBean> beans = new ArrayList<>();

		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword());
				PreparedStatement stmt = con.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			while (rs.next()) {
				productBean = new ProductBean(rs.getInt("代碼"), rs.getString("學校名稱"), rs.getString("公/私立"),
						rs.getString("縣市名稱"), rs.getString("地址"), rs.getString("電話"), rs.getString("網址"),
						rs.getString("體系別"));
				beans.add(productBean);
			}
		}

		return beans;
	}

	@Override
	public List<ProductBean> findAllByTitle(String title, String keyin) throws SQLException {
		String sql = " SELECT * FROM [大專校院名錄] where ? = ?; ";
		ProductBean productBean = null;
		List<ProductBean> beans = new ArrayList<>();

		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.setString(1, title);
			stmt.setString(2, keyin);
			try (ResultSet rs = stmt.executeQuery();) {

				while (rs.next()) {
					productBean = new ProductBean(rs.getInt("代碼"), rs.getString("學校名稱"), rs.getString("公/私立"),
							rs.getString("縣市名稱"), rs.getString("地址"), rs.getString("電話"), rs.getString("網址"),
							rs.getString("體系別"));
					beans.add(productBean);
				}
			}
		}

		return beans;
	}

	@Override
	public ProductBean findById(int key) throws SQLException {
		String sql = "SELECT * FROM 大專校院名錄 Where 代碼 = ?; ";
		ProductBean productBean = null;

		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.setInt(1, key);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					productBean = new ProductBean(rs.getInt("代碼"), rs.getString("學校名稱"), rs.getString("公/私立"),
							rs.getString("縣市名稱"), rs.getString("地址"), rs.getString("電話"), rs.getString("網址"),
							rs.getString("體系別"));
				}
			}
		}
		return productBean;
	}

	@Override
	public ProductBean findBytitle(String title, String keyin) throws SQLException {
		String sql = "SELECT * FROM 大專校院名錄 Where ? = ?; ";
		ProductBean productBean = null;

		try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
				SystemConstant.getPassword()); PreparedStatement stmt = con.prepareStatement(sql);) {
			stmt.setString(1, title);
			stmt.setString(2, keyin);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {
					productBean = new ProductBean(rs.getInt("代碼"), rs.getString("學校名稱"), rs.getString("公/私立"),
							rs.getString("縣市名稱"), rs.getString("地址"), rs.getString("電話"), rs.getString("網址"),
							rs.getString("體系別"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return productBean;
	}

	@Override
	public List<ProductBean> fuzzySearch(String title, String keyword) throws SQLException {
		String sql = " SELECT * FROM [大專校院名錄] WHERE " + title + " LIKE \'%" + keyword + "%\'; ";
		ProductBean productBean = null;
		List<ProductBean> beans = new ArrayList<>();

		if (keyword.chars().allMatch(Character::isDigit)) {
			beans.add(findById(Integer.valueOf(keyword)));
		} else {
			try (Connection con = DriverManager.getConnection(SystemConstant.getDbURL(), SystemConstant.getUser(),
					SystemConstant.getPassword());
					PreparedStatement stmt = con.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery();) {
				while (rs.next()) {
					productBean = new ProductBean(rs.getInt("代碼"), rs.getString("學校名稱"), rs.getString("公/私立"),
							rs.getString("縣市名稱"), rs.getString("地址"), rs.getString("電話"), rs.getString("網址"),
							rs.getString("體系別"));
					beans.add(productBean);
				}
			}
		}
		return beans;
	}

}