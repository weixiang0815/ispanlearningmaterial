package tw.ispan.action;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import tw.ispan.service.LoginService;

public class Demo3ServiceAction {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
//		LoginService service = context.getBean("loginService", LoginService.class);
//		System.out.println("result 1: " + service.checkLogin("jerry", "pwdd"));
//		System.out.println("result 2: " + service.checkLogin("jerry", "pwd"));
		
		LoginService service2 = context.getBean("loginService2", LoginService.class);
		System.out.println("result 1: " + service2.checkLogin("jerry", "pwdd"));
		System.out.println("result 2: " + service2.checkLogin("jerry", "pwd"));
		
		context.close();
	}

}
