package _01.service;

import java.util.List;

import _01.model.CustomerBean;

public interface CustomerService {
	CustomerBean findById(Integer id);

	List<CustomerBean> findAll();

	Object save(CustomerBean bean);

	void update(CustomerBean bean);

	void deleteById(Integer key);

}
