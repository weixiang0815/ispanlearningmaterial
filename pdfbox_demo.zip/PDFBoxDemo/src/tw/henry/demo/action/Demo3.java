package tw.henry.demo.action;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

public class Demo3 {

	public static void main(String[] args) {
		File file = new File("C:/Users/Student/Desktop/Demo.pdf");
		try (PDDocument doc = PDDocument.load(file);) {
			PDPage page = doc.getPage(3);
			try (PDPageContentStream stream = new PDPageContentStream(doc, page);) {
				stream.beginText();
//				stream.setFont(PDType1Font.HELVETICA_BOLD, 16);
				stream.setFont(PDType0Font.load(doc, new File("C:/Windows/Fonts/kaiu.ttf")), 16);
				stream.newLineAtOffset(50, 50);
//				String text = "Wei-Yi-Fang Coporation";
				String text_chinese = "鮪一繙有限公司";
				stream.showText(text_chinese);
				stream.endText();
			}
			System.out.println("寫了一行字");
			doc.save(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
