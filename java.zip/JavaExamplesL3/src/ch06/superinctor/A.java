package ch06.superinctor;

public class A {
   int x = (int)(Math.random() * 100) + 1000;
   
   public A() {
	  
   }
   
   public A(int x) {
	   this.x = x;
   }
}
