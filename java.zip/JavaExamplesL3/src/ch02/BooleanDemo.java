package ch02;
public class BooleanDemo {
	public static void main(String args[]) {
	     int age = 20 ; 
	     
	     System.out.println(age < 60);  
	     System.out.println(age == 60); 
	     System.out.println(age > 60);  
	}
}
