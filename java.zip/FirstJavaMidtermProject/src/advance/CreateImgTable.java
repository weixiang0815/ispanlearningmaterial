package advance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import system.SystemConstant;

public class CreateImgTable {
	static String dropString = "";
	static String createString = "";
	
	public static void createImgTable() {
		String dbURL = SystemConstant.getDbURL();
		String user = SystemConstant.getUser();
		String password = SystemConstant.getPassword();
		setSQLCOmmand();

		try (
			Connection conn = DriverManager.getConnection(dbURL, user, password);				
			PreparedStatement stmt1 = conn.prepareStatement(dropString);
			PreparedStatement stmt2 = conn.prepareStatement(createString);
		) {
			System.out.println("現在創建表格......");
		//  執行SQL命令
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			System.out.println("表格創建成功");
		} catch (SQLException e) {
			System.err.print("存取資料庫時發生例外: " + e);
			e.printStackTrace();
			return;
		}
	}
	
	private static void setSQLCOmmand() {
		// 新建Book_JDBC表格
		dropString = " drop table if exists [圖片]; ";
		createString = " create table [圖片] ( "
					+ " 代碼 int not null primary key identity, "
					+ " 檔名 nvarchar(20) not null, "
					+ " 圖片 blob not null, "
					+ " 副檔名 nvarchar(10) not null "
					+ " ); "; 
	}
}