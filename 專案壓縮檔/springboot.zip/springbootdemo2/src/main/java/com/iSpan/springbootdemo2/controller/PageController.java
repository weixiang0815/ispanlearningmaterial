package com.iSpan.springbootdemo2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PageController {

	@GetMapping("/")
	public String goToIndex() {
		return "index";
	}

	@GetMapping("/test1")
	@ResponseBody
	public String test() {
		return "6666";
	}

}