package com.lcpan.m11;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@WebServlet("/InsertEmp.do")
public class InsertEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String sql = "INSERT INTO [servdb].[dbo].[employee] " + "VALUES (?, ?, ?, ?, ?, ?);";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String result = null;
		try {
			Context context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:comp/env/jdbc/servdb");
			try (Connection conn = ds.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql);) {
				stmt.setString(1, request.getParameter("empno"));
				stmt.setString(2, request.getParameter("ename"));
				stmt.setString(3, request.getParameter("hiredate"));
				stmt.setString(4, request.getParameter("salary"));
				stmt.setString(5, request.getParameter("deptno"));
				stmt.setString(6, request.getParameter("title"));
				stmt.executeUpdate();
				result = "新增成功";
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = "更新失敗";
		}
		response.getWriter().write(result);
//		request.setAttribute("result", result);
//		request.getRequestDispatcher("/m11/InsertEmp.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
