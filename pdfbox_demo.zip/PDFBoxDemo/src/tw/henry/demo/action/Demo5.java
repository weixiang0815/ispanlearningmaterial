package tw.henry.demo.action;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;

public class Demo5 {

	public static void main(String[] args) {
		File file = new File("C:/Users/Student/Desktop/Demo.pdf");
		try (PDDocument doc = PDDocument.load(file);) {
			int noOfPage = doc.getNumberOfPages();
			System.out.println("總共有 " + noOfPage + " 頁");
			doc.removePage(1);
			System.out.println("刪除第 2 頁");
			doc.save(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
