package crm.repository.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import crm.model.Member;
import crm.repository.MemberRepository;
import crm.ude.NoSuchMemberException;

@Repository
public class MemberRepositoryImpl implements MemberRepository {

	SessionFactory factory;

	@Autowired
	public MemberRepositoryImpl(SessionFactory factory) {
		this.factory = factory;
	}

	@Override
	public void save(Member member) {
		Session session = getSession();
		session.save(member);
	}

	@Override
	public void deleteById(Integer id) {
		Session session = getSession();
		Member member = findById(id);
		if (member != null) {
			member.setCategory(null);
			member.setHobby(null);
			session.delete(member);
		} else {
			throw new NoSuchMemberException(id);
		}
	}

	@Override
	public void update(Member member) {
		if (member != null && member.getId() != null) 	{
			Session session = getSession();
			session.saveOrUpdate(member);
		}
	}

	@Override
	public List<Member> findAll() {
		String hql = "FROM Member";
		Session session = getSession();
		List<Member> list = session.createQuery(hql, Member.class)
				                   .getResultList();
		return list;
	}

	public Session getSession() {
        return factory.getCurrentSession();			
	}

	@Override
	public Member findById(Integer id) {
		return factory.getCurrentSession().get(Member.class, id);
	}
}
