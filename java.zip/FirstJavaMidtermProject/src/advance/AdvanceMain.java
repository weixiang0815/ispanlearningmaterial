package advance;

public class AdvanceMain {

	public static void main(String[] args) {
		// 1. 把檔案爬下來
		//	  1.1. 爬網址 (網址：https://data.gov.tw/dataset/) (亂數範圍：8864~89990)
		//	  1.2. 分析下載連結的位置
		//	  1.3. 將下載連結的檔案下載到特定位置
		// 2. 把檔案資料讀進SQL Server
		//	  2.0. 將SQL Server資料庫建好
		// 	  2.1. 讀取下載好的檔案中的第一列文字當作表頭
		//	  2.2. 將讀到的表頭送進SQL Server創建資料表
		//	  2.3. 將檔案剩餘的每列資料分割成Bean送進資料表insert
		// 3. 提取SQL Server資料並秀出來
		//	  3.1. 使用executeQuery()將資料表內容提取出來
		for(int i = 0; i < ((int)(Math.random()*20)+1); i ++)
			System.out.println((int)(Math.random()*(89990-8864+1))+1);
	}

}
