package ch03.lab14.solution;

public class ProgramCh03Lab14 {
    public static void main(String[] args) {
        //  產生 1 - 49 的亂數
        int n = (int)(Math.random() * 49) + 1 ;   // 在這裡編寫程式碼
        System.out.println("n=" + n);
    }
}
