package com.iSpan.springbootdemo2.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO Data Transfer Object<br>
 * 傳遞資料的物件 request、response 都可以做
 * <ol>
 * 特性：
 * <li>跟資料庫無關，只是傳遞資料
 * <li>不只 restful api 可以做，spring form 也可以做
 * </ol>
 */
public class MessageUpdateDto implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("msg-id")
	private Integer id;

	@JsonProperty("edit-Text")
	private String newMessage;

	public MessageUpdateDto() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNewMessage() {
		return newMessage;
	}

	public void setNewMessage(String newMessage) {
		this.newMessage = newMessage;
	}

}