package main;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import img.CreateImgTable;
import img.InsertImg;
import model.ProductBean;
import model.ProductDao;
import model.ProductDaoImpl;
import others.GetCSVDownload;
import others.webCrawler;
import query.FuzzySearch;
import query.FuzzySearchAndOpenWebsite;
import query.QueryMultipleProductsById;
import query.QueryOutputFile;
import query.QueryProductByKey;
import system.SystemConstant;
import update.CreateCSVTable;
import update.InsertAllTable;

public class MainFrame {

	private JFrame frmjava;
	private JTextField textField_圖片搜尋關鍵字;
	private JTextField textField_下載圖片張數;
	private JTextArea textArea_Google圖片爬蟲;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JLabel lblNewLabel_請輸入圖檔位址;
	private JButton btnNewButton_1_上傳圖檔;
	private JTextField textField;
	private JTextArea textArea_圖片存入資料庫;
	private JButton btnNewButton_建立圖片資料庫;
	private JButton btnNewButton_預覽;
	private JButton btnNewButton_匯出;
	private JTextArea textArea_圖片存入資料庫_1;
	private JTextField textField_1;
	private JButton btnNewButton_預覽_1;
	private JTextArea textArea_圖片存入資料庫_2;
	private JButton btnNewButton_匯出_2;
	private JTextField txtHttps;
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private JTextField textField_新增整份檔案;
	private JTextField textField_校名;
	private JTextField textField_地址;
	private JTextField textField_電話;
	private JTextField textField_網址;
	private JTextField textField_區碼;
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private final ButtonGroup buttonGroup_3 = new ButtonGroup();
	private JRadioButton rdbtn_私立;
	private JRadioButton rdbtn_公立;
	private JComboBox comboBox_縣市;
	private JRadioButton rdbtn_一般;
	private JRadioButton rdbtn_師範;
	private JRadioButton rdbtn_技職;
	private JButton btn_新增資料;
	private JLabel lblNewLabel_校名;
	private JLabel lblNewLabel_公私立;
	private JLabel lblNewLabel_縣市;
	private JLabel lblNewLabel_地址;
	private JLabel lblNewLabel_電話;
	private JLabel lblNewLabel_網址;
	private JLabel lblNewLabel_體系;

	private String imagepath_upload;
	private String imagepath_download;
	private Integer Id;
	private String schoolName;
	private String pubOrPriv;
	private String region;
	private String address;
	private String phone;
	private String regionNumber;
	private String url;
	private String system;
	private final ButtonGroup buttonGroup_4 = new ButtonGroup();
	private JTextField textField_根據代碼查詢單筆資料;
	private JTextField textField_模糊搜尋;
	private JTextField textField_根據代碼查詢多筆資料;
	private JButton btn_查詢資料;
	private final ButtonGroup buttonGroup_5 = new ButtonGroup();
	private JTextField textField_2;
	private JButton btn_開啟學校網站;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frmjava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmjava = new JFrame();
		frmjava.setResizable(false);
		frmjava.setTitle("資展Java班157期第一次期中專題");
		frmjava.setBounds(100, 100, 1080, 720);
		frmjava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmjava.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		frmjava.getContentPane().add(tabbedPane);

		JPanel panel_大專校院名冊 = new JPanel();
		tabbedPane.addTab("大專校院名冊", null, panel_大專校院名冊, null);
		panel_大專校院名冊.setLayout(new GridLayout(0, 1, 0, 0));

		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
		panel_大專校院名冊.add(tabbedPane_1);

		JPanel panel_建立 = new JPanel();
		tabbedPane_1.addTab("建立", null, panel_建立, null);
		panel_建立.setLayout(null);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(634, 10, 411, 511);
		panel_建立.add(scrollPane_2);

		textArea_圖片存入資料庫_2 = new JTextArea();
		textArea_圖片存入資料庫_2.setLineWrap(true);
		textArea_圖片存入資料庫_2.setWrapStyleWord(true);
		scrollPane_2.setViewportView(textArea_圖片存入資料庫_2);
		textArea_圖片存入資料庫_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_圖片存入資料庫_2.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_2 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_2.setText("");
				txtHttps.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲_1_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_2.setBounds(920, 532, 126, 41);
		panel_建立.add(btnNewButton_Google圖片爬蟲_1_2);

		JLabel lblNewLabel_3 = new JLabel("請輸入要下載的檔案網址：");
		lblNewLabel_3.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(57, 114, 221, 42);
		panel_建立.add(lblNewLabel_3);

		txtHttps = new JTextField();
		txtHttps.setText("https://stats.moe.gov.tw/files/school/110/u1_new.csv");
		txtHttps.setToolTipText("\"https://\"開頭的這個東東～");
		txtHttps.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		txtHttps.setColumns(10);
		txtHttps.setBounds(57, 180, 513, 42);
		panel_建立.add(txtHttps);

		JButton btnNewButton_匯出_1 = new JButton("下載檔案");
		btnNewButton_匯出_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_2.setText("");
				if (txtHttps.getText().trim().equals("")) {
					textArea_圖片存入資料庫_2.append("網址不可為空值喔！\n");
					btnNewButton_匯出_2.setEnabled(false);
				} else {
					textArea_圖片存入資料庫_2.append("現在開始下載檔案\n");
					btnNewButton_匯出_2.setEnabled(true);
					String url = txtHttps.getText().trim();
					String getDownload = GetCSVDownload.getCSVDownload(url);
					textArea_圖片存入資料庫_2.append(getDownload + '\n');
					if (!getDownload.equals("檔案已經下載好囉！")) {
						btnNewButton_匯出_2.setEnabled(false);
					}
				}
			}
		});
		btnNewButton_匯出_1.setForeground(Color.BLACK);
		btnNewButton_匯出_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_匯出_1.setBounds(444, 260, 126, 41);
		panel_建立.add(btnNewButton_匯出_1);

		btnNewButton_匯出_2 = new JButton("建立資料庫");
		btnNewButton_匯出_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btnNewButton_匯出_2.isEnabled()) {
					textArea_圖片存入資料庫_2.setText("現在創建表格......\n");
					textArea_圖片存入資料庫_2.append(CreateCSVTable.createCSVTable());
				}
			}
		});
		btnNewButton_匯出_2.setEnabled(false);
		btnNewButton_匯出_2.setForeground(Color.BLACK);
		btnNewButton_匯出_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_匯出_2.setBounds(291, 260, 126, 41);
		panel_建立.add(btnNewButton_匯出_2);

		JPanel panel_新增 = new JPanel();
		tabbedPane_1.addTab("新增", null, panel_新增, null);
		panel_新增.setLayout(null);

		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(634, 10, 411, 511);
		panel_新增.add(scrollPane_3);

		JTextArea textArea_新增 = new JTextArea();
		textArea_新增.setWrapStyleWord(true);
		textArea_新增.setLineWrap(true);
		scrollPane_3.setViewportView(textArea_新增);
		textArea_新增.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_新增.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_3 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				schoolName = "";
				pubOrPriv = "";
				region = "";
				address = "";
				phone = "";
				regionNumber = "";
				url = "";
				system = "";
				textArea_新增.setText("");
				btn_新增資料.setEnabled(false);
				textField_新增整份檔案.setEnabled(false);
				textField_新增整份檔案.setText("");
				textField_校名.setEnabled(false);
				textField_校名.setText("");
				textField_電話.setEnabled(false);
				textField_電話.setText("");
				textField_地址.setEnabled(false);
				textField_地址.setText("");
				textField_網址.setEnabled(false);
				textField_網址.setText("");
				textField_區碼.setEnabled(false);
				textField_區碼.setText("");
				rdbtn_公立.setEnabled(false);
				rdbtn_私立.setEnabled(false);
				comboBox_縣市.setEnabled(false);
				rdbtn_一般.setEnabled(false);
				rdbtn_師範.setEnabled(false);
				rdbtn_技職.setEnabled(false);
				lblNewLabel_校名.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_公私立.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_縣市.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_地址.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_電話.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_網址.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_體系.setForeground(Color.LIGHT_GRAY);
			}
		});
		btnNewButton_Google圖片爬蟲_1_3.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_3.setBounds(920, 532, 126, 41);
		panel_新增.add(btnNewButton_Google圖片爬蟲_1_3);

		JRadioButton rdbtn_新增單筆資料 = new JRadioButton("新增單筆資料");
		rdbtn_新增單筆資料.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				textField_新增整份檔案.setEnabled(false);
				textField_校名.setEnabled(true);
				textField_地址.setEnabled(true);
				textField_電話.setEnabled(true);
				textField_網址.setEnabled(true);
				textField_區碼.setEnabled(true);
				rdbtn_公立.setEnabled(true);
				rdbtn_私立.setEnabled(true);
				comboBox_縣市.setEnabled(true);
				rdbtn_一般.setEnabled(true);
				rdbtn_師範.setEnabled(true);
				rdbtn_技職.setEnabled(true);
				btn_新增資料.setEnabled(true);
				lblNewLabel_校名.setForeground(Color.BLACK);
				lblNewLabel_公私立.setForeground(Color.BLACK);
				lblNewLabel_縣市.setForeground(Color.BLACK);
				lblNewLabel_地址.setForeground(Color.BLACK);
				lblNewLabel_電話.setForeground(Color.BLACK);
				lblNewLabel_網址.setForeground(Color.BLACK);
				lblNewLabel_體系.setForeground(Color.BLACK);
			}
		});
		rdbtn_新增單筆資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		buttonGroup_1.add(rdbtn_新增單筆資料);
		rdbtn_新增單筆資料.setBounds(45, 31, 191, 23);
		panel_新增.add(rdbtn_新增單筆資料);

		JRadioButton rdbtn_新增整份檔案資料 = new JRadioButton("新增整份檔案資料");
		rdbtn_新增整份檔案資料.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				textField_新增整份檔案.setEnabled(true);
				textField_校名.setEnabled(false);
				textField_地址.setEnabled(false);
				textField_電話.setEnabled(false);
				textField_網址.setEnabled(false);
				textField_區碼.setEnabled(false);
				rdbtn_公立.setEnabled(false);
				rdbtn_私立.setEnabled(false);
				comboBox_縣市.setEnabled(false);
				rdbtn_一般.setEnabled(false);
				rdbtn_師範.setEnabled(false);
				rdbtn_技職.setEnabled(false);
				btn_新增資料.setEnabled(true);
				lblNewLabel_校名.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_公私立.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_縣市.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_地址.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_電話.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_網址.setForeground(Color.LIGHT_GRAY);
				lblNewLabel_體系.setForeground(Color.LIGHT_GRAY);
			}
		});
		rdbtn_新增整份檔案資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		buttonGroup_1.add(rdbtn_新增整份檔案資料);
		rdbtn_新增整份檔案資料.setBounds(45, 359, 191, 23);
		panel_新增.add(rdbtn_新增整份檔案資料);

		textField_新增整份檔案 = new JTextField();
		textField_新增整份檔案.setText("C:/Users/Student/Desktop/專題下載檔案/u1_new.csv");
		textField_新增整份檔案.setEnabled(false);
		textField_新增整份檔案.setToolTipText("圖檔的絕對路徑");
		textField_新增整份檔案.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_新增整份檔案.setColumns(10);
		textField_新增整份檔案.setBounds(45, 398, 543, 42);
		panel_新增.add(textField_新增整份檔案);

		btn_新增資料 = new JButton("新增資料");
		btn_新增資料.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btn_新增資料.isEnabled()) {
					textArea_新增.setText("");
					if (textField_新增整份檔案.isEnabled()) {
						if (textField_新增整份檔案.getText().trim().equals("")) {
							textArea_新增.append("檔案位址不得為空喔！\n");
						} else {
							textArea_新增.append("現在開始新增紀錄......\n");
							String datafile = textField_新增整份檔案.getText().trim();
							String outcome = InsertAllTable.insertAllTable(datafile);
							textArea_新增.append(outcome + '\n');
						}
					} else if (textField_校名.isEnabled()) {
						schoolName = textField_校名.getText().trim();
						address = textField_地址.getText().trim();
						regionNumber = textField_區碼.getText().trim();
						phone = textField_電話.getText().trim();
						url = textField_網址.getText().trim();
						if (schoolName.equals("") | address.equals("") | regionNumber.equals("") | phone.equals("")
								| url.equals("")) {
							if (schoolName.equals("")) {
								textArea_新增.append("校名不得為空值喔！\n");
							}
							if (address.equals("")) {
								textArea_新增.append("地址不得為空值喔！\n");
							}
							if (regionNumber.equals("")) {
								textArea_新增.append("區碼不得為空值喔！\n");
							}
							if (phone.equals("")) {
								textArea_新增.append("電話不得為空值喔！\n");
							}
							if (url.equals("")) {
								textArea_新增.append("網址不得為空值喔！\n");
							}
						} else {
							phone = "(" + regionNumber + ")" + phone;
							region = comboBox_縣市.getSelectedItem().toString();
							ProductDao productDao = new ProductDaoImpl();
							ProductBean bean = new ProductBean(null, schoolName, pubOrPriv, region, address, phone, url,
									system);
							try {
								textArea_新增.append("現在開始新增一筆資料......\n");
								productDao.save(bean);
								textArea_新增.append("新增一筆資料成功\n");
							} catch (SQLException e1) {
								textArea_新增.append("新增資料出現問題：" + e1.getMessage() + '\n');
							}
						}
					}
				}
			}
		});
		btn_新增資料.setEnabled(false);
		btn_新增資料.setForeground(Color.BLACK);
		btn_新增資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btn_新增資料.setBounds(462, 480, 126, 41);
		panel_新增.add(btn_新增資料);

		lblNewLabel_校名 = new JLabel("校名");
		lblNewLabel_校名.setForeground(new Color(192, 192, 192));
		lblNewLabel_校名.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_校名.setBounds(45, 74, 53, 25);
		panel_新增.add(lblNewLabel_校名);

		lblNewLabel_公私立 = new JLabel("公/私立");
		lblNewLabel_公私立.setForeground(new Color(192, 192, 192));
		lblNewLabel_公私立.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_公私立.setBounds(45, 112, 69, 25);
		panel_新增.add(lblNewLabel_公私立);

		lblNewLabel_縣市 = new JLabel("縣市");
		lblNewLabel_縣市.setForeground(new Color(192, 192, 192));
		lblNewLabel_縣市.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_縣市.setBounds(45, 147, 53, 25);
		panel_新增.add(lblNewLabel_縣市);

		lblNewLabel_地址 = new JLabel("地址");
		lblNewLabel_地址.setForeground(new Color(192, 192, 192));
		lblNewLabel_地址.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_地址.setBounds(45, 184, 53, 25);
		panel_新增.add(lblNewLabel_地址);

		lblNewLabel_電話 = new JLabel("電話");
		lblNewLabel_電話.setForeground(new Color(192, 192, 192));
		lblNewLabel_電話.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_電話.setBounds(45, 222, 53, 25);
		panel_新增.add(lblNewLabel_電話);

		lblNewLabel_網址 = new JLabel("網址");
		lblNewLabel_網址.setForeground(new Color(192, 192, 192));
		lblNewLabel_網址.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_網址.setBounds(45, 260, 53, 25);
		panel_新增.add(lblNewLabel_網址);

		lblNewLabel_體系 = new JLabel("體系");
		lblNewLabel_體系.setForeground(new Color(192, 192, 192));
		lblNewLabel_體系.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_體系.setBounds(45, 298, 53, 25);
		panel_新增.add(lblNewLabel_體系);

		textField_校名 = new JTextField();
		textField_校名.setToolTipText("給你的學校起個名吧～");
		textField_校名.setEnabled(false);
		textField_校名.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_校名.setBounds(122, 74, 466, 28);
		panel_新增.add(textField_校名);
		textField_校名.setColumns(10);

		textField_地址 = new JTextField();
		textField_地址.setToolTipText("應該不會有人住無人島上吧？！");
		textField_地址.setEnabled(false);
		textField_地址.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_地址.setColumns(10);
		textField_地址.setBounds(122, 184, 466, 28);
		panel_新增.add(textField_地址);

		textField_電話 = new JTextField();
		textField_電話.setToolTipText("你家的電話有幾位數呢？");
		textField_電話.setEnabled(false);
		textField_電話.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_電話.setColumns(10);
		textField_電話.setBounds(219, 222, 369, 28);
		panel_新增.add(textField_電話);

		textField_網址 = new JTextField();
		textField_網址.setToolTipText("\"https://\"開頭的那個東東～");
		textField_網址.setEnabled(false);
		textField_網址.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_網址.setColumns(10);
		textField_網址.setBounds(122, 260, 466, 28);
		panel_新增.add(textField_網址);

		rdbtn_公立 = new JRadioButton("公立");
		rdbtn_公立.setToolTipText("資源多，能跟政府要很多好處");
		rdbtn_公立.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				pubOrPriv = "公立";
			}
		});
		rdbtn_公立.setEnabled(false);
		buttonGroup_2.add(rdbtn_公立);
		rdbtn_公立.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_公立.setBounds(120, 113, 69, 23);
		panel_新增.add(rdbtn_公立);

		rdbtn_私立 = new JRadioButton("私立");
		rdbtn_私立.setToolTipText("學費貴到爆，但同學家裡更有錢");
		rdbtn_私立.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				pubOrPriv = "私立";
			}
		});
		rdbtn_私立.setEnabled(false);
		buttonGroup_2.add(rdbtn_私立);
		rdbtn_私立.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_私立.setBounds(191, 113, 75, 23);
		panel_新增.add(rdbtn_私立);

		JLabel lblNewLabel_電話_1 = new JLabel("(");
		lblNewLabel_電話_1.setForeground(new Color(192, 192, 192));
		lblNewLabel_電話_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_電話_1.setBounds(122, 222, 14, 25);
		panel_新增.add(lblNewLabel_電話_1);

		JLabel lblNewLabel_電話_2 = new JLabel(")");
		lblNewLabel_電話_2.setForeground(new Color(192, 192, 192));
		lblNewLabel_電話_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_電話_2.setBounds(209, 222, 14, 25);
		panel_新增.add(lblNewLabel_電話_2);

		textField_區碼 = new JTextField();
		textField_區碼.setToolTipText("就是手機打市話要撥的東西");
		textField_區碼.setEnabled(false);
		textField_區碼.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_區碼.setColumns(10);
		textField_區碼.setBounds(131, 222, 75, 28);
		panel_新增.add(textField_區碼);

		comboBox_縣市 = new JComboBox();
		comboBox_縣市.setToolTipText("注意是臺灣的縣市喔！");
		comboBox_縣市.setEnabled(false);
		comboBox_縣市.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		comboBox_縣市.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		comboBox_縣市.setModel(
				new DefaultComboBoxModel(new String[] { "基隆市", "臺北市", "新北市", "桃園市", "新竹縣", "新竹市", "苗栗縣", "臺中市", "南投縣",
						"彰化縣", "雲林縣", "嘉義縣", "嘉義市", "臺南市", "高雄市", "屏東縣", "臺東縣", "花蓮縣", "宜蘭縣", "澎湖縣", "金門縣", "連江縣" }));
		comboBox_縣市.setSelectedIndex(0);
		comboBox_縣市.setBounds(122, 145, 84, 28);
		panel_新增.add(comboBox_縣市);

		rdbtn_一般 = new JRadioButton("一般");
		rdbtn_一般.setToolTipText("什麼都教，包山包海");
		rdbtn_一般.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				system = "一般";
			}
		});
		rdbtn_一般.setEnabled(false);
		buttonGroup_3.add(rdbtn_一般);
		rdbtn_一般.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_一般.setBounds(120, 300, 69, 23);
		panel_新增.add(rdbtn_一般);

		rdbtn_師範 = new JRadioButton("師範");
		rdbtn_師範.setToolTipText("未來國家棟樑的頂梁柱");
		rdbtn_師範.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				system = "師範";
			}
		});
		rdbtn_師範.setEnabled(false);
		buttonGroup_3.add(rdbtn_師範);
		rdbtn_師範.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_師範.setBounds(191, 299, 75, 23);
		panel_新增.add(rdbtn_師範);

		rdbtn_技職 = new JRadioButton("技職");
		rdbtn_技職.setToolTipText("其實薪水超高......");
		rdbtn_技職.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				system = "技職";
			}
		});
		rdbtn_技職.setEnabled(false);
		buttonGroup_3.add(rdbtn_技職);
		rdbtn_技職.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_技職.setBounds(268, 300, 75, 23);
		panel_新增.add(rdbtn_技職);

		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(192, 192, 192));
		separator.setForeground(new Color(192, 192, 192));
		separator.setBounds(38, 344, 550, 2);
		panel_新增.add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.LIGHT_GRAY);
		separator_1.setBackground(Color.LIGHT_GRAY);
		separator_1.setBounds(38, 465, 550, 2);
		panel_新增.add(separator_1);

		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.LIGHT_GRAY);
		separator_2.setBackground(Color.LIGHT_GRAY);
		separator_2.setBounds(38, 18, 550, 2);
		panel_新增.add(separator_2);

		JPanel panel_修改 = new JPanel();
		tabbedPane_1.addTab("修改", null, panel_修改, null);
		panel_修改.setLayout(null);

		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(634, 10, 411, 511);
		panel_修改.add(scrollPane_4);

		JTextArea textArea_圖片存入資料庫_4 = new JTextArea();
		textArea_圖片存入資料庫_4.setLineWrap(true);
		textArea_圖片存入資料庫_4.setWrapStyleWord(true);
		scrollPane_4.setViewportView(textArea_圖片存入資料庫_4);
		textArea_圖片存入資料庫_4.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_圖片存入資料庫_4.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_4 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_4.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_4.setBounds(920, 532, 126, 41);
		panel_修改.add(btnNewButton_Google圖片爬蟲_1_4);

		JPanel panel_刪除 = new JPanel();
		tabbedPane_1.addTab("刪除", null, panel_刪除, null);
		panel_刪除.setLayout(null);

		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(634, 10, 411, 511);
		panel_刪除.add(scrollPane_5);

		JTextArea textArea_圖片存入資料庫_5 = new JTextArea();
		textArea_圖片存入資料庫_5.setWrapStyleWord(true);
		textArea_圖片存入資料庫_5.setLineWrap(true);
		scrollPane_5.setViewportView(textArea_圖片存入資料庫_5);
		textArea_圖片存入資料庫_5.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_圖片存入資料庫_5.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_5 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_5.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_5.setBounds(920, 532, 126, 41);
		panel_刪除.add(btnNewButton_Google圖片爬蟲_1_5);

		JPanel panel_查詢 = new JPanel();
		tabbedPane_1.addTab("查詢", null, panel_查詢, null);
		panel_查詢.setLayout(null);

		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(634, 10, 411, 511);
		panel_查詢.add(scrollPane_6);

		JTextArea textArea_查詢 = new JTextArea();
		textArea_查詢.setWrapStyleWord(true);
		textArea_查詢.setLineWrap(true);
		scrollPane_6.setViewportView(textArea_查詢);
		textArea_查詢.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_查詢.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_6 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_查詢.setText("");
				textField_根據代碼查詢單筆資料.setText("");
				textField_根據代碼查詢單筆資料.setEnabled(false);
				textField_根據代碼查詢多筆資料.setText("");
				textField_根據代碼查詢多筆資料.setEnabled(false);
				textField_模糊搜尋.setText("");
				textField_模糊搜尋.setEnabled(false);
				btn_查詢資料.setEnabled(false);
				btn_開啟學校網站.setEnabled(false);
			}
		});
		btnNewButton_Google圖片爬蟲_1_6.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_6.setBounds(920, 532, 126, 41);
		panel_查詢.add(btnNewButton_Google圖片爬蟲_1_6);

		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setForeground(Color.LIGHT_GRAY);
		separator_2_1.setBackground(Color.LIGHT_GRAY);
		separator_2_1.setBounds(42, 21, 550, 2);
		panel_查詢.add(separator_2_1);

		JRadioButton rdbtn_根據代碼查詢單筆資料 = new JRadioButton("根據代碼查詢單筆資料");
		buttonGroup_5.add(rdbtn_根據代碼查詢單筆資料);
		rdbtn_根據代碼查詢單筆資料.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				btn_查詢資料.setEnabled(true);
				textField_根據代碼查詢單筆資料.setEnabled(true);
				textField_根據代碼查詢多筆資料.setEnabled(false);
				textField_模糊搜尋.setEnabled(false);
				btn_開啟學校網站.setEnabled(true);
			}
		});
		rdbtn_根據代碼查詢單筆資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_根據代碼查詢單筆資料.setBounds(49, 46, 225, 23);
		panel_查詢.add(rdbtn_根據代碼查詢單筆資料);

		JRadioButton rdbtn_模糊搜尋 = new JRadioButton("模糊搜尋");
		rdbtn_模糊搜尋.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				btn_查詢資料.setEnabled(true);
				textField_根據代碼查詢單筆資料.setEnabled(false);
				textField_根據代碼查詢多筆資料.setEnabled(false);
				textField_模糊搜尋.setEnabled(true);
				btn_開啟學校網站.setEnabled(true);
			}
		});
		buttonGroup_5.add(rdbtn_模糊搜尋);
		rdbtn_模糊搜尋.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_模糊搜尋.setBounds(49, 335, 107, 23);
		panel_查詢.add(rdbtn_模糊搜尋);

		textField_根據代碼查詢單筆資料 = new JTextField();
		textField_根據代碼查詢單筆資料.setToolTipText("一個正整數");
		textField_根據代碼查詢單筆資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_根據代碼查詢單筆資料.setEnabled(false);
		textField_根據代碼查詢單筆資料.setColumns(10);
		textField_根據代碼查詢單筆資料.setBounds(59, 95, 533, 46);
		panel_查詢.add(textField_根據代碼查詢單筆資料);

		textField_模糊搜尋 = new JTextField();
		textField_模糊搜尋.setToolTipText("打個關鍵字，接下來就見證奇蹟吧！");
		textField_模糊搜尋.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_模糊搜尋.setEnabled(false);
		textField_模糊搜尋.setColumns(10);
		textField_模糊搜尋.setBounds(59, 384, 533, 46);
		panel_查詢.add(textField_模糊搜尋);

		JRadioButton rdbtn_根據代碼查詢多筆資料 = new JRadioButton("根據代碼查詢多筆資料");
		rdbtn_根據代碼查詢多筆資料.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				btn_查詢資料.setEnabled(true);
				textField_根據代碼查詢單筆資料.setEnabled(false);
				textField_根據代碼查詢多筆資料.setEnabled(true);
				textField_模糊搜尋.setEnabled(false);
				btn_開啟學校網站.setEnabled(true);
			}
		});
		buttonGroup_5.add(rdbtn_根據代碼查詢多筆資料);
		rdbtn_根據代碼查詢多筆資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtn_根據代碼查詢多筆資料.setBounds(49, 187, 225, 23);
		panel_查詢.add(rdbtn_根據代碼查詢多筆資料);

		textField_根據代碼查詢多筆資料 = new JTextField();
		textField_根據代碼查詢多筆資料.setToolTipText("多個正整數並用 \",\" 隔開");
		textField_根據代碼查詢多筆資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_根據代碼查詢多筆資料.setEnabled(false);
		textField_根據代碼查詢多筆資料.setColumns(10);
		textField_根據代碼查詢多筆資料.setBounds(59, 241, 533, 46);
		panel_查詢.add(textField_根據代碼查詢多筆資料);

		btn_查詢資料 = new JButton("查詢資料");
		btn_查詢資料.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btn_查詢資料.isEnabled()) {
					textArea_查詢.setText("");
					if (textField_根據代碼查詢單筆資料.isEnabled()) {
						if (textField_根據代碼查詢單筆資料.getText().trim().equals("")) {
							textArea_查詢.append("代碼不能為空值喔～\n");
						} else {
							Id = Integer.valueOf(textField_根據代碼查詢單筆資料.getText().trim());
							textArea_查詢.append(QueryProductByKey.queryProductByKey(Id) + '\n');
						}
					} else if (textField_根據代碼查詢多筆資料.isEnabled()) {
						if (textField_根據代碼查詢多筆資料.getText().trim().equals("")) {
							textArea_查詢.append("代碼不能為空值喔～\n");
						} else {
							String[] input = textField_根據代碼查詢多筆資料.getText().split(",");
							int[] ids = new int[input.length];
							for (int i = 0; i < ids.length; i++) {
								ids[i] = Integer.valueOf(input[i].trim());
							}
							Arrays.sort(ids);
							textArea_查詢.append(QueryMultipleProductsById.queryMultipleProductsById(ids) + '\n');
						}
					} else if (textField_模糊搜尋.isEnabled()) {
						textArea_查詢.append(FuzzySearch.fuzzySearch(textField_模糊搜尋.getText().trim()) + '\n');
					}
				}
			}
		});
		btn_查詢資料.setForeground(Color.BLACK);
		btn_查詢資料.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btn_查詢資料.setEnabled(false);
		btn_查詢資料.setBounds(466, 480, 126, 41);
		panel_查詢.add(btn_查詢資料);

		JSeparator separator_3_1 = new JSeparator();
		separator_3_1.setForeground(Color.LIGHT_GRAY);
		separator_3_1.setBackground(Color.LIGHT_GRAY);
		separator_3_1.setBounds(42, 457, 550, 2);
		panel_查詢.add(separator_3_1);

		btn_開啟學校網站 = new JButton("開啟學校網站");
		btn_開啟學校網站.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btn_開啟學校網站.isEnabled()) {
					textArea_查詢.setText("");
					if (textField_根據代碼查詢單筆資料.isEnabled()) {
						if (textField_根據代碼查詢單筆資料.getText().trim().equals("")) {
							textArea_查詢.append("代碼不能為空值喔～\n");
						} else {
							Id = Integer.valueOf(textField_根據代碼查詢單筆資料.getText().trim());
							try {
								ProductBean productBean = new ProductDaoImpl().findById(Id);
								if (productBean == null) {
									textArea_查詢.append("查無此資料:Key = " + Id + '\n');
								} else {
									textArea_查詢.append(productBean.getUrl() + '\n');
									java.awt.Desktop.getDesktop().browse(new URI(productBean.getUrl()));
									textArea_查詢.append("已開啟" + productBean.getSchoolName() + "的網站\n");
								}
							} catch (Exception ex) {
								textArea_查詢.append("查詢記錄時發生例外: " + ex.getMessage() + '\n');
							}
						}
					} else if (textField_根據代碼查詢多筆資料.isEnabled()) {
						if (textField_根據代碼查詢多筆資料.getText().trim().equals("")) {
							textArea_查詢.append("代碼不能為空值喔～\n");
						} else {
							String[] input = textField_根據代碼查詢多筆資料.getText().split(",");
							int[] ids = new int[input.length];
							for (int i = 0; i < ids.length; i++) {
								ids[i] = Integer.valueOf(input[i].trim());
							}
							Arrays.sort(ids);
							try {
								for (int i = 0; i < ids.length; i++) {
									ProductBean productBean = new ProductDaoImpl().findById(ids[i]);
									if (productBean == null) {
										textArea_查詢.append("查無此資料:Key = " + Id + '\n');
									} else {
										textArea_查詢.append(productBean.getUrl() + '\n');
										java.awt.Desktop.getDesktop().browse(new URI(productBean.getUrl()));
										textArea_查詢.append("已開啟" + productBean.getSchoolName() + "的網站\n");
									}
								}
								textArea_查詢.append("多筆紀錄查詢完畢\n");
							} catch (Exception ex) {
								textArea_查詢.append("查詢記錄時發生例外: " + ex.getMessage() + '\n');
							}
						}
					} else if (textField_模糊搜尋.isEnabled()) {
						textArea_查詢.append(FuzzySearchAndOpenWebsite.fuzzySearch(textField_模糊搜尋.getText().trim()) + '\n');
					}

				}
			}
		});
		btn_開啟學校網站.setForeground(Color.BLACK);
		btn_開啟學校網站.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btn_開啟學校網站.setEnabled(false);
		btn_開啟學校網站.setBounds(269, 480, 156, 41);
		panel_查詢.add(btn_開啟學校網站);

		JPanel panel = new JPanel();
		tabbedPane_1.addTab("匯出", null, panel, null);
		panel.setLayout(null);

		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(635, 10, 409, 509);
		panel.add(scrollPane_7);

		JTextArea textArea_查詢_1 = new JTextArea();
		scrollPane_7.setViewportView(textArea_查詢_1);
		textArea_查詢_1.setWrapStyleWord(true);
		textArea_查詢_1.setLineWrap(true);
		textArea_查詢_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_查詢_1.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_6_1 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_6_1.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_查詢_1.setText("");
				textField_2.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲_1_6_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_6_1.setBounds(920, 531, 126, 41);
		panel.add(btnNewButton_Google圖片爬蟲_1_6_1);

		JLabel lblNewLabel_4 = new JLabel("請輸入多個代碼並用 \",\" 隔開：");
		lblNewLabel_4.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_4.setBounds(37, 156, 246, 42);
		panel.add(lblNewLabel_4);

		textField_2 = new JTextField();
		textField_2.setToolTipText("全都要是正整數喔～");
		textField_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_2.setColumns(10);
		textField_2.setBounds(37, 210, 559, 42);
		panel.add(textField_2);

		JButton btnNewButton_1 = new JButton("匯出檔案");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_查詢_1.setText("");
				if (textField_2.getText().trim().equals("")) {
					textArea_查詢_1.append("代碼不能為空值喔～\n");
				} else {
					String[] input = textField_2.getText().trim().split(",");
					int[] ids = new int[input.length];
					for (int i = 0; i < ids.length; i++) {
						ids[i] = Integer.valueOf(input[i].trim());
					}
					Arrays.sort(ids);
					QueryOutputFile.queryOutputFile(ids);
				}
			}
		});
		btnNewButton_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_1.setBounds(456, 273, 140, 53);
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("查詢");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_查詢_1.setText("");
				if (textField_2.getText().trim().equals("")) {
					textArea_查詢_1.append("代碼不能為空值喔～\n");
				} else {
					String[] input = textField_2.getText().split(",");
					int[] ids = new int[input.length];
					for (int i = 0; i < ids.length; i++) {
						ids[i] = Integer.valueOf(input[i].trim());
					}
					Arrays.sort(ids);
					textArea_查詢_1.append(QueryMultipleProductsById.queryMultipleProductsById(ids) + '\n');
				}
			}
		});
		btnNewButton_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_2.setBounds(281, 273, 140, 53);
		panel.add(btnNewButton_2);

		JPanel panel_圖片資料庫 = new JPanel();
		tabbedPane.addTab("圖片資料庫", null, panel_圖片資料庫, null);
		panel_圖片資料庫.setLayout(null);

		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_2.setBounds(0, 0, 1061, 618);
		tabbedPane_2.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
		panel_圖片資料庫.add(tabbedPane_2);

		JPanel panel_圖片存入資料庫 = new JPanel();
		tabbedPane_2.addTab("圖片存入資料庫", null, panel_圖片存入資料庫, null);
		panel_圖片存入資料庫.setLayout(null);

		JButton btnNewButton_Google圖片爬蟲_1 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫.setText("");
				textField.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1.setBounds(920, 533, 126, 41);
		panel_圖片存入資料庫.add(btnNewButton_Google圖片爬蟲_1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(633, 10, 413, 513);
		panel_圖片存入資料庫.add(scrollPane);

		textArea_圖片存入資料庫 = new JTextArea();
		textArea_圖片存入資料庫.setWrapStyleWord(true);
		textArea_圖片存入資料庫.setLineWrap(true);
		scrollPane.setViewportView(textArea_圖片存入資料庫);
		textArea_圖片存入資料庫.setEditable(false);
		textArea_圖片存入資料庫.setFont(new Font("微軟正黑體", Font.PLAIN, 18));

		JLabel lblNewLabel_2 = new JLabel("1.　建好圖片資料庫了嗎：");
		lblNewLabel_2.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(30, 149, 221, 41);
		panel_圖片存入資料庫.add(lblNewLabel_2);

		JRadioButton rdbtnNewRadioButton = new JRadioButton("是的");
		rdbtnNewRadioButton.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				lblNewLabel_請輸入圖檔位址.setForeground(new Color(0, 0, 0));
				textField.setEnabled(true);
				btnNewButton_1_上傳圖檔.setEnabled(true);
				btnNewButton_建立圖片資料庫.setEnabled(false);
				btnNewButton_預覽_1.setEnabled(true);
			}
		});
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtnNewRadioButton.setBounds(276, 149, 68, 41);
		panel_圖片存入資料庫.add(rdbtnNewRadioButton);

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("還沒");
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				lblNewLabel_請輸入圖檔位址.setForeground(new Color(192, 192, 192));
				textField.setEnabled(false);
				btnNewButton_1_上傳圖檔.setEnabled(false);
				btnNewButton_建立圖片資料庫.setEnabled(true);
				btnNewButton_預覽_1.setEnabled(false);
			}
		});
		rdbtnNewRadioButton_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		rdbtnNewRadioButton_1.setBounds(346, 149, 68, 41);
		panel_圖片存入資料庫.add(rdbtnNewRadioButton_1);

		btnNewButton_建立圖片資料庫 = new JButton("建立圖片資料庫");
		btnNewButton_建立圖片資料庫.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btnNewButton_建立圖片資料庫.isEnabled()) {
					textArea_圖片存入資料庫.setText("");
					textArea_圖片存入資料庫.append(CreateImgTable.createImgTable() + '\n');
					rdbtnNewRadioButton.setSelected(true);
					lblNewLabel_請輸入圖檔位址.setForeground(new Color(0, 0, 0));
					textField.setEnabled(true);
					btnNewButton_1_上傳圖檔.setEnabled(true);
					btnNewButton_建立圖片資料庫.setEnabled(false);
					rdbtnNewRadioButton_1.setSelected(false);
					btnNewButton_預覽_1.setEnabled(true);
				}
			}
		});
		btnNewButton_建立圖片資料庫.setEnabled(false);
		btnNewButton_建立圖片資料庫.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_建立圖片資料庫.setBounds(430, 149, 177, 41);
		panel_圖片存入資料庫.add(btnNewButton_建立圖片資料庫);

		lblNewLabel_請輸入圖檔位址 = new JLabel("2.　請輸入圖檔位址：");
		lblNewLabel_請輸入圖檔位址.setForeground(new Color(192, 192, 192));
		lblNewLabel_請輸入圖檔位址.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_請輸入圖檔位址.setBounds(30, 226, 189, 41);
		panel_圖片存入資料庫.add(lblNewLabel_請輸入圖檔位址);

		textField = new JTextField();
		textField.setToolTipText("圖檔的絕對路徑");
		textField.setForeground(new Color(0, 0, 0));
		textField.setEnabled(false);
		textField.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField.setBounds(30, 277, 577, 41);
		panel_圖片存入資料庫.add(textField);
		textField.setColumns(10);

		btnNewButton_1_上傳圖檔 = new JButton("上傳圖檔");
		btnNewButton_1_上傳圖檔.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btnNewButton_1_上傳圖檔.isEnabled()) {
					textArea_圖片存入資料庫.setText("");
					if (textField.getText().trim().equals("")) {
						textArea_圖片存入資料庫.append("圖片位址不得為空喔！\n");
					} else {
						btnNewButton_預覽.setEnabled(true);
						imagepath_upload = textField.getText().trim();
						textArea_圖片存入資料庫.append("現在開始新增圖檔......\n");
						textArea_圖片存入資料庫.append(InsertImg.insertImg(textField.getText().trim()));
					}
				}
			}
		});
		btnNewButton_1_上傳圖檔.setForeground(new Color(0, 0, 0));
		btnNewButton_1_上傳圖檔.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_1_上傳圖檔.setEnabled(false);
		btnNewButton_1_上傳圖檔.setBounds(448, 349, 159, 41);
		panel_圖片存入資料庫.add(btnNewButton_1_上傳圖檔);

		btnNewButton_預覽_1 = new JButton("預覽");
		btnNewButton_預覽_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btnNewButton_預覽_1.isEnabled()) {
					try {
						imagepath_upload = textField.getText().trim();
						BufferedImage img = ImageIO.read(new File(imagepath_upload));
						ImageIcon icon = new ImageIcon(img);
						JLabel label = new JLabel(icon);
						JOptionPane.showMessageDialog(null, label);
					} catch (IOException ex) {
						textArea_圖片存入資料庫_1.append("預覽出現錯誤：" + ex.getMessage() + '\n');
					}
				}
			}
		});
		btnNewButton_預覽_1.setEnabled(false);
		btnNewButton_預覽_1.setForeground(Color.BLACK);
		btnNewButton_預覽_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_預覽_1.setBounds(288, 349, 126, 41);
		panel_圖片存入資料庫.add(btnNewButton_預覽_1);

		JPanel panel_讀取圖片並建立檔案 = new JPanel();
		tabbedPane_2.addTab("讀取圖片並建立檔案", null, panel_讀取圖片並建立檔案, null);
		panel_讀取圖片並建立檔案.setLayout(null);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(633, 10, 413, 513);
		panel_讀取圖片並建立檔案.add(scrollPane_1);

		textArea_圖片存入資料庫_1 = new JTextArea();
		textArea_圖片存入資料庫_1.setWrapStyleWord(true);
		textArea_圖片存入資料庫_1.setLineWrap(true);
		scrollPane_1.setViewportView(textArea_圖片存入資料庫_1);
		textArea_圖片存入資料庫_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textArea_圖片存入資料庫_1.setEditable(false);

		JButton btnNewButton_Google圖片爬蟲_1_1 = new JButton("清空");
		btnNewButton_Google圖片爬蟲_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_1.setText("");
				textField_1.setText("");
				btnNewButton_預覽.setEnabled(false);
			}
		});
		btnNewButton_Google圖片爬蟲_1_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲_1_1.setBounds(920, 533, 126, 41);
		panel_讀取圖片並建立檔案.add(btnNewButton_Google圖片爬蟲_1_1);

		JLabel lblNewLabel_2_1 = new JLabel("請輸入要匯出的圖片代碼：");
		lblNewLabel_2_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_2_1.setBounds(26, 212, 222, 41);
		panel_讀取圖片並建立檔案.add(lblNewLabel_2_1);

		textField_1 = new JTextField();
		textField_1.setToolTipText("一個正整數");
		textField_1.setForeground(Color.BLACK);
		textField_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_1.setColumns(10);
		textField_1.setBounds(249, 212, 356, 41);
		panel_讀取圖片並建立檔案.add(textField_1);

		btnNewButton_匯出 = new JButton("匯出");
		btnNewButton_匯出.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_圖片存入資料庫_1.setText("");
				if (textField_1.getText().trim().equals("")) {
					textArea_圖片存入資料庫_1.append("圖片代碼不得為空喔！\n");
				} else {
					int i = Integer.valueOf(textField_1.getText().trim());
					btnNewButton_預覽.setEnabled(true);
					String path = "C:/Users/Student/Desktop/專題下載檔案";
					File file = new File(path);
					if (!file.exists()) {
						file.mkdir();
					}
					String sql = " SELECT * FROM [圖片] WHERE [代碼] = ?; ";
					String dbURL = SystemConstant.getDbURL();
					String user = SystemConstant.getUser();
					String password = SystemConstant.getPassword();
					try (Connection conn = DriverManager.getConnection(dbURL, user, password);
							PreparedStatement stmt = conn.prepareStatement(sql);) {
						stmt.setInt(1, i);
						textArea_圖片存入資料庫_1.append("正在尋找圖片......\n");
						try (ResultSet rs = stmt.executeQuery();) {
							if (rs.next()) {
								imagepath_download = path + "/" + rs.getString("檔名") + "." + rs.getString("副檔名");
								try (FileOutputStream fos = new FileOutputStream(imagepath_download);
										BufferedOutputStream bos = new BufferedOutputStream(fos);) {
									bos.write(rs.getBytes("圖片"));
								}
							}
						}
						textArea_圖片存入資料庫_1.append("找到圖片囉！\n");
					} catch (Exception ex) {
						textArea_圖片存入資料庫_1.append("查詢記錄時發生例外: " + ex.getMessage() + '\n');
						btnNewButton_預覽.setEnabled(false);
					}
				}
			}
		});
		btnNewButton_匯出.setForeground(Color.BLACK);
		btnNewButton_匯出.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_匯出.setBounds(479, 275, 126, 41);
		panel_讀取圖片並建立檔案.add(btnNewButton_匯出);

		btnNewButton_預覽 = new JButton("預覽");
		btnNewButton_預覽.setEnabled(false);
		btnNewButton_預覽.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (btnNewButton_預覽.isEnabled()) {
					textArea_圖片存入資料庫_1.setText("");
					try {
						BufferedImage img = ImageIO.read(new File(imagepath_download));
						ImageIcon icon = new ImageIcon(img);
						JLabel label = new JLabel(icon);
						JOptionPane.showMessageDialog(null, label);
					} catch (IOException ex) {
						textArea_圖片存入資料庫_1.append("預覽出現錯誤：" + ex.getMessage() + '\n');
					}
				}
			}
		});
		btnNewButton_預覽.setForeground(Color.BLACK);
		btnNewButton_預覽.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_預覽.setBounds(343, 275, 126, 41);
		panel_讀取圖片並建立檔案.add(btnNewButton_預覽);

		JPanel panel_Google圖片爬蟲 = new JPanel();
		tabbedPane.addTab("Google圖片爬蟲", null, panel_Google圖片爬蟲, null);
		panel_Google圖片爬蟲.setLayout(null);

		JButton btnNewButton_Google圖片爬蟲 = new JButton("清空");
		btnNewButton_Google圖片爬蟲.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_圖片搜尋關鍵字.setText("");
				textField_下載圖片張數.setText("");
				textArea_Google圖片爬蟲.setText("");
			}
		});
		btnNewButton_Google圖片爬蟲.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton_Google圖片爬蟲.setBounds(911, 555, 140, 53);
		panel_Google圖片爬蟲.add(btnNewButton_Google圖片爬蟲);

		JScrollPane scrollPane_Google圖片爬蟲 = new JScrollPane();
		scrollPane_Google圖片爬蟲.setBounds(522, 10, 529, 535);
		panel_Google圖片爬蟲.add(scrollPane_Google圖片爬蟲);

		textArea_Google圖片爬蟲 = new JTextArea();
		textArea_Google圖片爬蟲.setLineWrap(true);
		textArea_Google圖片爬蟲.setWrapStyleWord(true);
		textArea_Google圖片爬蟲.setEditable(false);
		textArea_Google圖片爬蟲.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		scrollPane_Google圖片爬蟲.setViewportView(textArea_Google圖片爬蟲);

		JLabel lblNewLabel = new JLabel("請輸入圖片搜尋關鍵字：");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel.setBounds(53, 126, 204, 42);
		panel_Google圖片爬蟲.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("請問要爬幾張圖片（最多20張）：");
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(53, 271, 278, 42);
		panel_Google圖片爬蟲.add(lblNewLabel_1);

		textField_圖片搜尋關鍵字 = new JTextField();
		textField_圖片搜尋關鍵字.setToolTipText("任何關鍵字都可以呦～");
		textField_圖片搜尋關鍵字.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_圖片搜尋關鍵字.setBounds(53, 178, 397, 42);
		panel_Google圖片爬蟲.add(textField_圖片搜尋關鍵字);
		textField_圖片搜尋關鍵字.setColumns(10);

		textField_下載圖片張數 = new JTextField();
		textField_下載圖片張數.setToolTipText("真的最多只能20張呦～");
		textField_下載圖片張數.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		textField_下載圖片張數.setColumns(10);
		textField_下載圖片張數.setBounds(53, 323, 397, 42);
		panel_Google圖片爬蟲.add(textField_下載圖片張數);

		JButton btnNewButton = new JButton("開始爬蟲");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textArea_Google圖片爬蟲.setText("");
				if (textField_圖片搜尋關鍵字.getText().trim().equals("") | textField_下載圖片張數.getText().trim().equals("")) {
					if (textField_圖片搜尋關鍵字.getText().trim().equals("")) {
						textArea_Google圖片爬蟲.append("搜尋關鍵字不能是空白\n");
					}
					if (textField_下載圖片張數.getText().trim().equals("")) {
						textArea_Google圖片爬蟲.append("下載張數不能是空白\n");
					}
				} else {
					if (Integer.valueOf(textField_下載圖片張數.getText().trim()) > 20) {
						textArea_Google圖片爬蟲.append("下載張數沒辦法一次超過20張喔！\n");
					} else {
						textArea_Google圖片爬蟲.append("開始爬蟲！！！\n");
						String keyword = textField_圖片搜尋關鍵字.getText();
						int i = Integer.valueOf(textField_下載圖片張數.getText().trim());
						Elements imgs = webCrawler.crawl(keyword, i);

						int j = 0;
						File file = new File("C:/Users/henry/Desktop/爬下來的照片");
						if (!file.exists()) {
							file.mkdir();
						}
						try {
							for (Element img : imgs) {
								if (j + 1 > i)
									break;
								if (!img.attr("src").contains("https:"))
									continue;
								URL img_url = new URL(img.attr("src"));
								String img_name = j + 1 + ".jpg";
								try (FileOutputStream fos = new FileOutputStream(
										file.getAbsoluteFile() + "/" + img_name);
										BufferedOutputStream bos = new BufferedOutputStream(fos);) {
									bos.write(img_url.openStream().readAllBytes());
								}
								j++;
								textArea_Google圖片爬蟲.append("印好了第" + j + "張圖\n");
							}
							textArea_Google圖片爬蟲.append("圖片爬完囉！\n");
						} catch (IOException e1) {
							textArea_Google圖片爬蟲.append("出現錯誤：" + e1.getMessage());
						}
					}
				}
			}
		});
		btnNewButton.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		btnNewButton.setBounds(310, 492, 140, 53);
		panel_Google圖片爬蟲.add(btnNewButton);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("微軟正黑體", Font.PLAIN, 18));
		frmjava.setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("檔案");
		mnNewMenu.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("關閉");
		mntmNewMenuItem_1.addActionListener((event) -> System.exit(0));
		mntmNewMenuItem_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenu mnNewMenu_1 = new JMenu("其它");
		mnNewMenu_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("關於");
		mntmNewMenuItem_1_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 16));
		mnNewMenu_1.add(mntmNewMenuItem_1_1);
	}
}
