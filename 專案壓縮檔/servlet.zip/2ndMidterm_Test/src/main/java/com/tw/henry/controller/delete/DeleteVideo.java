package com.tw.henry.controller.delete;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.dao.VideoDao;

@WebServlet("/DeleteVideo.do")
public class DeleteVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String videoId = request.getParameter("videoId");
		String result;
		try (Connection conn = ConnectionFactory.getConnection();
				) {
			VideoDao videoDao = new VideoDao(conn);
			String creatorId = videoDao.getVideoByID(videoId).getCreatorId();
			result = videoDao.deleteVideoByID(videoId, creatorId);
		} catch (Exception e) {
			result = "連線失敗：" + e.getMessage();
		}
//		response.getWriter().write(result);
//		request.setAttribute("result", result);
		out.write(result);
		out.write("<meta http-equiv=\"refresh\" content=\"2; url=/2ndMidterm_Test/page/index.html\">");
		out.close();
//		request.getRequestDispatcher("/page/delete/DeleteVideo.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
