package com.tw.henry.model.bean;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.Serializable;
import java.util.Base64;

public class Video implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String name;
	private String thumbnail;
	private int size;
	private String filename;
	private String filetype;
	private byte[] video;
	private String info;
	private String creatorId;
	private String creatorName;

	public Video() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(byte[] pic) {
		thumbnail = "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(pic);
	}

	public void setThumbnail(String base64) {
		thumbnail =  base64;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFiletype() {
		return filetype;
	}

	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}

	public byte[] getVideo() {
		return video;
	}

	/**
	 * 同時設定 size
	 */
	public void setVideo(byte[] video) {
		this.video = video;
		setSize(video.length);
	}

	/**
	 * 同時設定 filename 、 filetype 和 size
	 */
	public void setVideo(String filepath) {
		if (filepath.contains("\\")) {
			setFilename(filepath.substring(filepath.lastIndexOf("\\") + 1));
		} else if (filepath.contains("/")) {
			setFilename(filepath.substring(filepath.lastIndexOf("/") + 1));
		}
		filetype = filename.substring(filename.lastIndexOf(".") + 1);
		try (FileInputStream fis = new FileInputStream(filepath);
				BufferedInputStream bis = new BufferedInputStream(fis);) {
			video = bis.readAllBytes();
			setSize(video.length);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	@Override
	public String toString() {
		StringBuffer str = new StringBuffer("影片：\n");
		str.append("編號：" + id + "\n");
		str.append("名稱：" + name + "\n");
		str.append("影片大小：" + size + "\n");
		str.append("檔案名稱：" + filename + "\n");
		str.append("檔案類型：" + filetype + "\n");
		str.append("簡介：" + info + "\n");
		str.append("創作者編號：" + creatorId + "\n");
		str.append("創作者名稱：" + creatorName + "\n");
		return str.toString();
	}

}
