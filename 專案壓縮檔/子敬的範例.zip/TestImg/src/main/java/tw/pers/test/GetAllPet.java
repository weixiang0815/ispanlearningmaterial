package tw.pers.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.pers.test.bean.Pet;

@WebServlet("/GetAllPet.do")
public class GetAllPet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String SQL = "SELECT * FROM [PetForum].[dbo].[Pet]";

		try {
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement preState = conn.prepareStatement(SQL);
			ResultSet rs = preState.executeQuery();

			ArrayList<Pet> pList = new ArrayList<Pet>();
			while (rs.next()) {
				Pet p = new Pet();
				p.setId(rs.getInt("id"));
				p.setNickName(rs.getString("nickName"));
				p.setType(rs.getString("type"));
				pList.add(p);
			}

			request.setAttribute("pList", pList);
			
			rs.close();
			preState.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		request.getRequestDispatcher("ShowAllPet.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
