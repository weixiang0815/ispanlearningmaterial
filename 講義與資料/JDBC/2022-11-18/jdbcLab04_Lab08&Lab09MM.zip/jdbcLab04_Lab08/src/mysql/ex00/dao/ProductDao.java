package mysql.ex00.dao;

import java.sql.SQLException;
import java.util.List;

import mysql.ex00.model.ProductBean;

public interface ProductDao {

	// 新增單筆產品紀錄
	void save(ProductBean bean) throws SQLException;

	// 依鍵值刪除單筆產品紀錄
	void deleteById(int key) throws SQLException;
	
	// 修改單筆產品紀錄
	void update(ProductBean bean) throws SQLException;

	// 查詢所有(或多筆)產品紀錄
	List<ProductBean> findAll() throws SQLException;

	// 依鍵值查詢單筆產品紀錄
	ProductBean findById(int key) throws SQLException;

}