package advance;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

public class GetJSONDownload {
	public static void getJSONDownload(String url) throws IOException {

		// 電影："https://data.gov.tw/dataset/6010" 
		String sURL = url;
		URL aURL = new URL(sURL);
		String fileName = sURL.substring(sURL.lastIndexOf("/") + 1);
		System.out.println("檔名:" + fileName);
		fileName = "C:/Users/Student/Desktop" + fileName;
		try (OutputStream fos = new FileOutputStream(fileName); InputStream is = aURL.openStream();) {
			int total = 0, count = 0;
			int i = 0;
			byte[] ba = new byte[8192];
			while ((count = is.read(ba)) != -1) {
				fos.write(ba, 0, count);
				total += count;
				i++;
				if (i % 1000 == 0) {
					System.out.println("total = " + total);
				}
			}
			System.out.println("檔案已下載到桌面囉！");
		}
	}
}
