package ch06.superinctor;

public class MainClass {

	public static void main(String[] args) {
		C c = new C(10);
		c.displayData();
	}

}
