package delete;

import java.sql.SQLException;

import exception.ProductNotFoundException;
import model.ProductDao;
import model.ProductDaoImpl;


public class DeleteProductById {
	public static String deleteProductById(int key) {
		ProductDao productDao = new ProductDaoImpl();
		try {
			productDao.deleteById(key);
			return "刪除記錄:Key=" + key + "成功";
		} catch (ProductNotFoundException e) {
			e.setProductID(key);
			return "紀錄不存在，無法刪除:Key=" + e.getProductID();
		} catch (SQLException e) {
			return "執行時出現問題："+e.getMessage();
		}
	}
}
