package ch02.lab05.solution;

// 練習目的：了解如何定義整數(long)變數

public class ProgramCh02Lab05 {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		// 定義一個整數(long)型態的變數 var1, 初值為 50;
        long var1 = 50;
		// 定義一個整數(long)型態的變數 var2, 初值為 214748364700;
        long var2 = 214748364700L;
	}
}
