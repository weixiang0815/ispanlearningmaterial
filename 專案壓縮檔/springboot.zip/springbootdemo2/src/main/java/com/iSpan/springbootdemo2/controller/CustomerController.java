package com.iSpan.springbootdemo2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iSpan.springbootdemo2.model.Customer;
import com.iSpan.springbootdemo2.model.CustomerRepository;
import com.iSpan.springbootdemo2.model.TestCustomerDao;

@RestController
public class CustomerController {

	@Autowired
	private CustomerRepository customerDao;

	@Autowired
	private TestCustomerDao ccDao;

	@PostMapping("/customer/add")
	public Customer insert1() {
		Customer cus1 = new Customer();
		cus1.setName("阿文");
		cus1.setLevel(2);

		Customer response = customerDao.save(cus1);
		return response;
	}

	@PostMapping("/customer/add2")
	public Customer insert2(@RequestBody Customer cus) {
		return customerDao.save(cus);
	}

	@PostMapping("/customer/addd")
	public List<Customer> addManyCustomer(@RequestBody List<Customer> customers) {
		return customerDao.saveAll(customers);
	}

	@GetMapping("/customer/{id}")
	public Customer getCustomerById(@PathVariable Integer id) {
		Optional<Customer> op = customerDao.findById(id);

		if (op.isPresent()) {
			return op.get();
		}

		Customer responsecus = new Customer();
		responsecus.setName("沒有這筆資料");
		return responsecus;
	}

	@GetMapping("/customer")
	public List<Customer> findAllCustomer() {
		return customerDao.findAll();
	}

	@DeleteMapping("/customer/delete")
	public String deleteById(@RequestParam Integer id) {
		try {
			customerDao.deleteById(id);
		} catch (EmptyResultDataAccessException e) {
			return "沒有這筆資料";
		}
		return "成功刪除";
	}

	@PutMapping("/customer/update")
	@Transactional // 用 @Transactional 蓋掉預設的 @Transactional(readOnly = true)
	public String updateLevelById(@RequestParam Integer id, @RequestParam Integer level) {
		Optional<Customer> op = customerDao.findById(id);

		if (op.isPresent()) {
			Customer cus = op.get();
			cus.setLevel(level);
//			customerDao.save(cus);	//	Spring Data JPA 的 save 是 saveOrUpdate
			return "修改 ok";
		}

		return "沒有這筆資料";
	}

	@GetMapping("/customer/page")
	public List<Customer> findByPage(@RequestParam Integer pageNumber) {
		Pageable pgb = PageRequest.of(pageNumber - 1, 2, Sort.Direction.ASC, "id");
		Page<Customer> page = customerDao.findAll(pgb);
		return page.getContent();
	}

	@GetMapping("/customer/name")
	public Customer findCustomerByName(@RequestParam String name) {
		return customerDao.findCustomerByName(name);
	}

	@GetMapping("/customer/name2")
	public Customer findCustomerByName2(@RequestParam String name) {
		return customerDao.findCustomerByName2(name);
	}

	@GetMapping("/customer/namelike")
	public List<Customer> findCustomerLike(@RequestParam String name) {
		return customerDao.findCustomerLike(name);
	}

	@GetMapping("/customer/level")
	public List<Customer> findCustomerByLevel(@RequestParam Integer level) {
		return customerDao.findCustomerByLevel(level);
	}

	@GetMapping("/customer/name_native")
	public Customer findCustomerByNameNativeQuery(@RequestParam String name) {
		return customerDao.findCustomerByNameNativeQuery(name);
	}

	@DeleteMapping("/customer/delete2")
	public boolean deleteCustomer(@RequestParam Integer id) {
		customerDao.deleteAccount(id);
		return true;
	}

	@GetMapping("/customer/level_orderby_id")
	public List<Customer> findByLevelOrderId(@RequestParam Integer level) {
		return customerDao.findByLevelOrderByIdDesc(level);
	}

	@GetMapping("/customer/name3")
	public List<Customer> findByNameContaining(@RequestParam(name = "n") String name) {
		return customerDao.findByNameContaining(name);
	}

	@GetMapping("/customer/other")
	public List<Customer> someSQL() {
		return ccDao.someSQL();
	}

}