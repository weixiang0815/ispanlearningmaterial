package ch06._09_object.hashCode;

public class Dog {
	@Override
	public int hashCode() {
		return 123456789;
	}
}
