package EEIT157_14_王威翔_第三章作業;

public class Ex1 {

	public static void main(String[] args) {
		System.out.println("59個雞蛋是" + (59 / 12) + "打又" + (59 % 12) + "個");

	}

}
