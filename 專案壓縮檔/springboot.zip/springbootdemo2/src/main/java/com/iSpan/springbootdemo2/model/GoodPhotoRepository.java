package com.iSpan.springbootdemo2.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GoodPhotoRepository extends JpaRepository<GoodPhoto, Integer> {

}