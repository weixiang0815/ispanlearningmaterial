package com.tw.henry.controller.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.tw.henry.conn.ConnectionFactory;
import com.tw.henry.model.bean.Creator;
import com.tw.henry.model.dao.CreatorDao;

@WebServlet("/CreatorRegister.do")
@MultipartConfig
public class CreatorRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain;charset=UTF-8");
		String result;
		try {
		Creator crt = new Creator();
		crt.setName(request.getParameter("name"));
		crt.setAccount(request.getParameter("account"));
		crt.setPassword(request.getParameter("password"));
		Part part = request.getPart("thumbnail");
		crt.setThumbnail(part.getInputStream().readAllBytes());
		crt.setGender(request.getParameter("gender"));
		crt.setBirthday(request.getParameter("birthday"));
		crt.setCountry(request.getParameter("country"));
		result = new CreatorDao(ConnectionFactory.getConnection()).addNewCreator(crt);
		} catch (Exception e) {
			e.printStackTrace();
			result = e.getMessage();
		}
//		response.getWriter().write(result);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/user/CreatorInfo.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
