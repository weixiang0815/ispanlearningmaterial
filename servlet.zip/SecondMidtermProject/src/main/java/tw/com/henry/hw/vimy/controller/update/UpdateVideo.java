package tw.com.henry.hw.vimy.controller.update;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.henry.hw.conn.ConnectionFactory;
import tw.com.henry.hw.vimy.model.bean.VideoBean;
import tw.com.henry.hw.vimy.model.dao.VideoDao;

@WebServlet("/UpdateVideo.do")
public class UpdateVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String result = null;
		VideoBean video = null;
		try {
			video = new VideoBean();
			video.setId(Integer.valueOf(request.getParameter("video_id")));
			video.setName(request.getParameter("video_name"));
			video.setThumbnail(request.getParameter("video_thumbnail"));
			video.setVideo(request.getParameter("filepath"));
			video.setInfo(request.getParameter("video_info"));
			video.setCreator(Integer.valueOf(request.getParameter("creator_id")));
			int update = new VideoDao(ConnectionFactory.getConnection()).updateVideo(video);
			result = update < 0 ? "更新失敗" : "更新成功";
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("result", result);
		request.getRequestDispatcher("/page/update/UpdateVideo.jsp")
				.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
