package tw.ispan.model;

import org.springframework.stereotype.Component;

//	<bean id="student" class=".................."></bean>
@Component("student") // 若沒寫 id，預設值為 Class 名稱小寫開頭
public class Student {

	private Integer id;

	private String name;

	private String nickName;

	public Student() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

}
