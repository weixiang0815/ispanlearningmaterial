﻿package ch08.ex05.authentication.model;

import java.sql.Timestamp;
import java.util.Collection;

import javax.management.relation.Role;

public class UserBean {
    private String user;
    private Collection<Role> roles; 
    private Timestamp loginTime;
	public UserBean(Timestamp loginTime, Collection<Role> roles, String user) {
		this.loginTime = loginTime;
		this.roles = roles;
		this.user = user;
	}	
	public UserBean() {
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public Collection<Role> getRoles() {
		return roles;
	}
	public void setRoles(Collection<Role> roles) {
		this.roles = roles;
	}
	public Timestamp getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Timestamp loginTime) {
		this.loginTime = loginTime;
	}
}
