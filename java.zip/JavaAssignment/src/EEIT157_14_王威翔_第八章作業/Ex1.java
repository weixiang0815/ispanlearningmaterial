package EEIT157_14_王威翔_第八章作業;

public class Ex1 {
	static void subroutine(String[] ar) {
		int sum = 0;
		for(int i = 0; i < ar.length; i ++) {
			try {				
				sum += Integer.parseInt(ar[i]);
			} catch (NumberFormatException e) {
				continue;
			}
		}
		System.out.println("sum=" + sum);
	}

	public static void main(String[] args) {
		subroutine(args);
	}
}
